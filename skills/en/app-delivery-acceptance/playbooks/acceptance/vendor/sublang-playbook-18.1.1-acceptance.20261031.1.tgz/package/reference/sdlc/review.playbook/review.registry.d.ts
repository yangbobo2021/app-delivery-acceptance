import { type PlaybookHostCapabilities, type PlaybookRuntime } from './review.playbook.js';
import type { PlaybookHostConstructionCapabilities } from '../code.playbook/playbook-captain.js';
export interface PlaybookSummaryPolicy {
    stateCountLabels: Readonly<Record<string, string>>;
    copyPasteGuardNames: readonly string[];
    savedCountsLine(counts: {
        interruptions: number;
        copyPastes: number;
    }, rounds: number): string;
}
export type ReviewOptions = Readonly<Record<string, never>>;
export interface ReviewPlaybookRegistryEntry {
    id: 'review';
    command: 'review';
    intent: string;
    artifactSchema: 3;
    runtimeProfile: {
        readonly kind: 'shared-factory';
        readonly compat: {
            readonly artifactSchema: 3;
            readonly runtimeAbi: number;
        };
    };
    requiredRoleIds: readonly ['coder', 'reviewer'];
    concurrentRoleSets: readonly [];
    summaryPolicy: PlaybookSummaryPolicy;
    validateOptions(optionSlice: unknown): ReviewOptions;
    createRuntime(options: ReviewOptions, hostCapabilities: PlaybookHostConstructionCapabilities & PlaybookHostCapabilities): PlaybookRuntime;
}
export declare const reviewStateCountLabels: {
    readonly firstReview: "review round";
    readonly reviewAfterFix: "review round";
    readonly reviewAfterRejection: "rebuttal";
};
export declare const reviewCopyPasteGuardNames: readonly ["hasFindings", "committed", "rejectedAll"];
export declare function reviewSavedCountsLine(counts: {
    interruptions: number;
    copyPastes: number;
}, rounds: number): string;
export declare const reviewSummaryPolicy: PlaybookSummaryPolicy;
export declare function validateReviewOptions(optionSlice: unknown): ReviewOptions;
export declare const reviewPlaybookRegistryEntry: ReviewPlaybookRegistryEntry;
export default reviewPlaybookRegistryEntry;
