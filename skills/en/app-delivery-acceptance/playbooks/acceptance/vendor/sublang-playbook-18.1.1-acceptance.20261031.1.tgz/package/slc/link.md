<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: 2026 SubLang International <https://sublang.ai> -->

# FSM-to-Runtime Linking

Third phase of a playbook (a state-machine agent orchestrating other agents).
Compiles the [gears2fsm](gears2fsm.md) artifact into a **`PlaybookRuntime`**: a host-agnostic runner that:

- Drives the FSM.
- Classifies Boss input into typed events.
- Runs direct-Captain, delegated-player, and nested-playbook actors.
- Executes deterministic script actors locally, without any agent.
- Adjudicates Captain and player output into FSM guards.
- Surfaces transitions as status/telemetry.

The runtime is invoked through the stable `PlaybookPorts` contract.
Presentation layers (tmux-play, web, CLI, tests) implement the six ports once
and inherit every playbook.

- Source: an XState v5 machine artifact (`.fsm.ts`) produced by gears2fsm.
- Target: a `PlaybookRuntime` factory module — TypeScript, host-agnostic.

Hosts are out of scope for this phase.
Each host has an adapter that loads a `PlaybookRuntime` module and supplies the host's primitives as `PlaybookPorts`.
The adapter shall speak only `PlaybookPorts` to the runtime and shall not leak host types back into it.

At construction, the shared factory validates linked metadata and the shared construction shape; the Captain host owns registry-manifest and live authority-envelope validation at its construction boundary.
Do not audit the bare shared factory as if it owned that Captain-host boundary or synthesize host capabilities in the emitted artifact.

The link compiler shall not modify the FSM artifact and shall not re-derive Captain prompts, result keys, or guard semantics — those are fixed by the FSM.

## Formats

| Role   | Format   | Extension |
| ------ | -------- | --------- |
| source | fsm      | .ts       |
| target | playbook | .ts       |

## Optional deterministic materialization

For an ordinary workflow using only `player` and `script` actors — flat, or
with root parallel groups of the [Parallel groups](gears2fsm.md#parallel-groups)
shape — the supported prompt profile below, shared remaining strategies, and primitive configured options, the linker may
use the adjacent `materialize-link.mjs` tool to emit the thin module.
The complete definition below remains binding; the tool replaces repetitive
module generation, not semantic analysis or emitted conformance verification.
Read the actual FSM and supply every erased or authored contract exactly.
Do not use `flat-defaults` or `flat-quoted-relays` when another custom composer, classifier, required-field
extractor, session-derived input mapping, controller strategy, nested call,
or compound state other than such a parallel group is needed.
Despite their names, every profile accepts those parallel groups: the tool
takes each region working leaf's role and label under its stable state id
like any other player state, declares nothing further, and leaves the
compiled shape to the factory preflight, which rejects any other form.

Invoke the tool with the actual definition directory, source FSM, and declared
target; supply a JSON descriptor on standard input:

```sh
node "<definition-directory>/materialize-link.mjs" --fsm "<source.fsm.ts>" --out "<target.playbook.ts>" <<'JSON'
{
  "schema": "sublang.playbook.link.v1",
  "profile": "flat-defaults",
  "machineExport": "exampleMachine",
  "label": "EXAMPLE",
  "options": {},
  "inputMapping": {},
  "entryEvent": { "type": "BOSS_TASK", "textField": "bossIntent" },
  "bossEvents": [],
  "outcomeAuthority": {
    "governedPlayerStates": {
      "work": {
        "done": { "fields": {}, "repositoryDisposition": "one-descendant-commit" },
        "needsBossReply": { "fields": { "question": "presentation" }, "repositoryDisposition": "deferred" }
      }
    }
  },
  "placeholderFields": {},
  "transitionEventFields": ["bossIntent", "answer", "questionId"],
  "verbatimPayloadFields": [],
  "resumableStateIds": ["work"],
  "unfinishedFinalStateIds": [],
  "controlContextFields": []
}
JSON
```

This descriptor is an example shape, not default workflow semantics.
Select `flat-defaults` for the unchanged shared player composer, or
`flat-quoted-relays` when the source requires standalone `> <token>` relay lines.
The latter uses the same descriptor keys and `placeholderFields` mappings;
ordinary string tokens substitute literally, while standalone relay values
quote each nonempty line with `> ` and preserve LF/CRLF and blank lines.
An empty relay value omits its complete template line; missing or non-string
values retain the token. Inserted values are never substituted again.
The emitted composer preserves the installed shared fresh/resumed Q&A prefix
and does not modify the original input. Labelled relays, identity-specific
composition, structured renderers, and other custom strategies require
ordinary linking; do not select either profile for those requirements.
Every top-level member is required; unknown members are errors.
`options` maps each configured option to `{ "type": "string" | "number" |
"boolean", "required": true | false }`; `inputMapping` maps each FSM input
field to its supplying option name.
Option unions, closed values, range constraints, nested structures, and
session-derived input values are outside this profile; do not widen their
contracts to an unconstrained primitive.
The tool adds optional string `cwd` for script-bearing machines; it does not
put `cwd` in FSM input unless the descriptor explicitly maps it.
When the linked module is part of a package that compiles and ships
JavaScript siblings, supply the optional `fsmSpecifier` — the `.js` sibling
the build emits for the source FSM, such as `./code.fsm.js`, in the same
directory and with the same basename — so the emitted import satisfies the
NodeNext rule under Output; omit it for a source-only host, where the tool
derives the specifier from the `--fsm` path.
An explicit `entryEvent: null` selects the shared classifier only where this
definition permits no deterministic entry; it does not relax entry rules.
`bossEvents` retains the exact additional erased event fields, source ownership,
requiredness, and closed values specified under Output.
The state/outcome/field authority map, placeholder exceptions, transition and
verbatim fields, resumable states, unfinished finals, and safe ordered context
projection retain their exact obligations under Output.
The tool copies role labels and identities from the machine and never guesses
result semantics by executing an invocation against invented context.

The helper resolves the installed shared engine from the source and target
locations and refuses differing engine resolutions.
Its factory preflight checks linked metadata.
It accepts `.fsm.js` on supported Node versions; `.fsm.ts` requires native
type stripping (Node 23.6+, or Node 22.18+).
On success it atomically writes only the declared target after factory
preflight; run all existing conformance checks afterward.
Exit 2 reports `unsupported` without changing the target: continue ordinary
linking under this complete definition.
Exit 1 reports invalid metadata, loading, preflight, or output failure:
correct the identified problem before treating linking as successful.

### Experimental labelled-string and nested-call profile

`flat-labelled-relays` is an unmeasured candidate for machines with flat
root states or root parallel groups of that shape, whose delegated players,
scripts, and nested `playbook` calls it supports. It
requires the installed shared `composePlayerContinuation` API. It leaves
nested input composition, child targets, result guards, recovery, and terminal
semantics in the unchanged FSM; the shared factory provides the nested bridge.
It does not authorize generating or importing maintained workflow artifacts.

Select it only for literal string substitution in unchanged player templates,
including labelled `> Label: <token>` lines and source-declared role-identity
tokens. In addition to every descriptor member above, supply:

- `playerInputExport`: the exact exported FSM player-input type name.
- `omitEmptyRelayLines`: exact complete source lines to omit only when their
  mapped string value is empty, for example
  `["> Run results: <run-results>"]`. Each line starts with `> ` and ends in
  one placeholder; any preceding label is literal. Use an explicit empty
  array when no line is optional; never infer optionality from a missing value.
- `identityPlaceholders`: an explicit token-to-canonical-local-role map, such
  as `{ "coder-llm": "coder" }` only where Source requires that identity.
  These values come solely from the invocation-scoped identity lookup, never
  from options, FSM context, or model prose. Use `{}` when none is authored.

The composer replaces original tokens once, prefixes each continuation line
of a value inserted into a quoted source line with `> `, preserves line
separators and literal inserted text, and leaves missing/non-string values as
source tokens. Undeclared empty relay lines retain their authored text.
The emitted verification composer has the same identity and optional third
resume arguments as the runtime; the shared helper owns fresh/resumed Q&A.
Structured rendering, custom classifiers/extractors/controllers, direct
Captain actors, compound topology other than such a parallel group, and
constrained/nonprimitive options remain unsupported. Source-derived metadata and all existing
conformance checks remain mandatory. This profile changes no runtime bridge,
workflow semantics, or measured performance claim.

For an FSM that satisfies one of the materializer profiles above, derive its
complete source-owned descriptor and run `materialize-link.mjs` before writing
an ordinary linked module by hand. Use the supported profile whose composer
matches the actual source. An unsupported-profile exit continues ordinary
linking under this definition; invalid metadata must be corrected. Never
widen an option, omit a required custom strategy, change the FSM, or relax a
verification check to make a profile fit.


## PlaybookRuntime contract

The emitted module shall default-export a factory of the following shape:

```typescript
interface PlaybookRuntime {
  readonly retainedGenerationMetadata?: PlaybookRetainedGenerationMetadata;
  init(session: PlaybookSession): Promise<void>;
  adopt?(
    session: PlaybookSession,
    snapshot: PlaybookRuntimeSnapshot,
    context: PlaybookAdoptionContext,
  ): Promise<void>;
  handleBossInput(turn: {
    text: string;
    signal: AbortSignal;
    /** Called synchronously just before accepting the event, at most once. */
    onAccepted?: () => void;
  }): Promise<PlaybookRunResult>;
  resumePlaybookCall(input: {
    callId: string;
    result: PlaybookCallResult;
    signal: AbortSignal;
  }): Promise<PlaybookRunResult>;
  unresolvedEffectEnvelopes?(): readonly (
    | { readonly kind: 'boundary'; readonly boundaryId: string }
    | { readonly kind: 'logical-operation'; readonly operationId: string }
  )[];
  dispose(): Promise<void>;
}

interface PlaybookRetainedGenerationMetadata {
  readonly unfinishedFinalStateIds: readonly string[];
}

interface PlaybookAdoptionContext {
  readonly sourceSessionId: string;
  readonly sourceGenerationId: string;
  readonly targetChildSessionId?: string;
}

interface PlaybookSession {
  sessionId: string;
  playbookId: string;
  rootSessionId: string;
  parentSessionId?: string;
  parentCallId?: string;
  depth: number;
  roleBindings?: Readonly<Record<string, PlaybookRoleBinding>>;
  playerSessions?: PlayerSessionStore;
  ports: PlaybookPorts;
}

interface PlaybookRoleBinding {
  readonly playerId: string;
  readonly promptIdentity: string;
  readonly agent?: { readonly adapter: string; readonly model?: unknown; readonly effort?: unknown };
}

interface PlaybookPendingBossQuestion {
  questionId: string;
  asker: { kind: 'captain' } | { kind: 'role'; roleId: string };
  question: string;
  sourceItem?: string;
}

interface PlayerSessionStore {
  select(roleId: string): string | false;
  // Called only for a replacement token or an authorized ok-status clear.
  update(roleId: string, resumeToken?: string): void;
  snapshot(): Readonly<Record<string, string>>;
  restore(tokens: Readonly<Record<string, string>>): void;
}

type JsonValue =
  | null
  | boolean
  | number
  | string
  | readonly JsonValue[]
  | { readonly [key: string]: JsonValue };

// DR-063: the closed failure-cause contract. `code` is one of
// PLAYBOOK_FAILURE_CODES and `evidence` holds exactly the members that code
// names — repository paths, dispositions, classifications, and revisions, never
// content or internal identity.
type PlaybookFailureCode =
  | 'commit-missing'
  | 'commit-residual'
  | 'pre-existing-lost'
  | 'commits-more-than-one'
  | 'history-rewritten'
  | 'foreign-change'
  | 'observation-unstable'
  | 'attribution-ambiguous'
  | 'receipt-missing'
  | 'judge-failed'
  | 'player-failed'
  | 'aborted'
  | 'child-failed'
  | 'runtime-defect';

interface PlaybookFailureCause {
  readonly code: PlaybookFailureCode;
  readonly evidence: PlaybookFailureEvidence;
}

interface NormalizedError {
  name: string;
  message: string;
  stack?: string;
  cause?: PlaybookFailureCause;   // present when the error carried a valid one
}

type PlaybookStateValue =
  | string
  | { readonly [key: string]: PlaybookStateValue };

interface PlaybookState {
  value: PlaybookStateValue;
  activeStateIds: readonly string[];
  tags: readonly string[];
  status: 'active' | 'done' | 'error' | 'stopped';
  quiescent: boolean;
  stateId?: string;
}

interface PlaybookPendingCall {
  callId: string;
  playbookId: string;
  childSessionId: string;
}

interface PlaybookSuspendedCall extends PlaybookPendingCall {
  stateId: string;
  text: string;
  turnId?: number;
  effectBoundaryPrefixSequence?: number | null;
}

type PlaybookRepositoryReceiptClassification =
  | 'unchanged'
  | 'one-descendant-commit'
  | 'multiple-commits'
  | 'rewritten-or-non-descendant'
  | 'worktree-only-change'
  | 'concurrent-or-foreign-change'
  | 'observation-ambiguous';

interface PlaybookRepositoryObservation {
  readonly worktree: string;
  readonly gitDir: string;
  readonly head: string;
  readonly branch?: string;
  readonly projection: Readonly<Record<string, JsonValue>>;
  readonly projectionDigest: string;
}

interface PlaybookRepositoryReceipt {
  readonly classification: PlaybookRepositoryReceiptClassification;
  readonly baseline: PlaybookRepositoryObservation;
  readonly after?: PlaybookRepositoryObservation;
  readonly commitOid?: string;
  readonly commits?: readonly string[];
}

type PlaybookRepositoryDisposition =
  | 'unchanged'
  | 'one-descendant-commit'
  | 'deferred';

interface PlaybookEffectBoundary {
  readonly sequence: number;
  readonly boundaryId: string;
  readonly attemptId: string;
  readonly attemptNumber: number;
  readonly playbookId: string;
  readonly runtimeSessionId: string;
  readonly turnId: number;
  readonly callId: string;
  readonly roleId: string;
  readonly sourceStateId: string;
  readonly sourceOutcomeSchema: JsonValue;
  readonly dispositions: readonly PlaybookRepositoryDisposition[];
  readonly canonicalWorktree: {
    readonly worktree: string;
    readonly gitDir: string;
  };
  readonly baseline: PlaybookRepositoryObservation;
  readonly after?: PlaybookRepositoryObservation;
  readonly physicalReceipt?: PlaybookRepositoryReceipt;
  readonly restored?: PlaybookRepositoryObservation;
  readonly finalText?: string;
  readonly semanticCandidate?: JsonValue;
  readonly initialSemanticCandidate?: JsonValue;
  readonly correctionBudget: { readonly limit: 1; readonly spent: boolean };
  readonly cohortId?: string;
  readonly logicalOperationId?: string;
}

interface PlaybookEffectLogicalOperation {
  readonly sequence: number;
  readonly operationId: string;
  readonly playbookId: string;
  readonly runtimeSessionId: string;
  readonly boundaryIds: readonly string[];
  readonly originalBaseline: PlaybookRepositoryObservation;
  readonly checkpoint?: PlaybookRepositoryObservation;
  readonly pendingQuestion?: PlaybookPendingBossQuestion;
  readonly playerContinuation?: JsonValue;
  readonly checkpointRestorationEligible: boolean;
  readonly logicalReceipt?: PlaybookRepositoryReceipt;
}

interface PlaybookEffectLedger {
  readonly schemaVersion: 1;
  readonly revision: number;
  readonly boundaries: readonly PlaybookEffectBoundary[];
  readonly logicalOperations: readonly PlaybookEffectLogicalOperation[];
}

type PlaybookEffectBoundaryStart = Omit<
  PlaybookEffectBoundary,
  | 'sequence'
  | 'attemptId'
  | 'attemptNumber'
  | 'after'
  | 'physicalReceipt'
  | 'finalText'
  | 'semanticCandidate'
  | 'initialSemanticCandidate'
  | 'restored'
>;

type PlaybookEffectLogicalOperationStart = Omit<
  PlaybookEffectLogicalOperation,
  'sequence'
>;

type PlaybookEffectLedgerCommand =
  | {
      readonly kind: 'start-boundaries';
      readonly boundaries: readonly [
        PlaybookEffectBoundaryStart,
        ...PlaybookEffectBoundaryStart[],
      ];
    }
  | {
      readonly kind: 'replace-boundaries';
      readonly replacements: readonly [
        {
          readonly expected: PlaybookEffectBoundary;
          readonly next: PlaybookEffectBoundary;
        },
        ...{
          readonly expected: PlaybookEffectBoundary;
          readonly next: PlaybookEffectBoundary;
        }[],
      ];
    }
  | {
      readonly kind: 'append-logical-operations';
      readonly operations: readonly [
        PlaybookEffectLogicalOperationStart,
        ...PlaybookEffectLogicalOperationStart[],
      ];
    }
  | {
      readonly kind: 'replace-logical-operations';
      readonly replacements: readonly [
        {
          readonly expected: PlaybookEffectLogicalOperation;
          readonly next: PlaybookEffectLogicalOperation;
        },
        ...{
          readonly expected: PlaybookEffectLogicalOperation;
          readonly next: PlaybookEffectLogicalOperation;
        }[],
      ];
    };

type PlaybookEffectLedgerCommandBatch = readonly [
  PlaybookEffectLedgerCommand,
  ...PlaybookEffectLedgerCommand[],
];

interface PlaybookEffectLedgerCapability {
  snapshot(): PlaybookEffectLedger;
  writeAhead(
    commands: PlaybookEffectLedgerCommandBatch,
  ): Promise<PlaybookEffectLedger>;
}

interface PlaybookRecoveryCheckpoint {
  readonly id?: string;
  readonly stateId: string;
  readonly prompt: string;
  readonly machine: JsonValue;
  readonly boundaryPrefix: number;
  readonly result?: JsonValue;
  readonly delivered?: true;
}

interface PlaybookStepRecord {
  readonly id: string;
  readonly kind: 'player' | 'captain' | 'script';
  readonly stateId: string;
  readonly result?: JsonValue;
}

interface PlaybookRuntimeSnapshot {
  schemaVersion: 4;
  playbookId: string;
  machine: JsonValue;
  roleResumeTokens: { readonly [roleId: string]: string };
  sequences: {
    trace: number;
    turn: number;
    judgeCall: number;
    playerCall: number;
    playbookCall: number;
    captainCall?: number;
  };
  state: PlaybookState;
  pendingBossQuestions: readonly PlaybookPendingBossQuestion[];
  effectLedger: PlaybookEffectLedger;
  /** Original runtime identity retained across schema-3 adoption lineage. */
  retainedEffectSourceSessionId?: string;
  /**
   * Unsafe retained-adoption checkpoint. The marker remains durable until
   * authoritative reconciliation proves its complete suffix replay-safe.
   */
  retainedEffectReconciliation?: {
    readonly sourceSessionId: string;
    readonly checkpoint: PlaybookEffectLedger;
  };
  failedEffectAttempt?: {
    readonly boundaryPrefix: number;
    readonly attemptId: string | null;
  };
  /** Interrupted invocation, captured before its external call (DR-069). */
  recoveryCheckpoint?: PlaybookRecoveryCheckpoint;
  suspendedCall?: PlaybookSuspendedCall;
  /** The run's Boss exchanges so far, in order (DR-090). */
  bossExchanges?: readonly PlaybookBossExchange[];
}

interface PlaybookBossExchange {
  readonly question: string;
  readonly reply: string;
}

type PlaybookRunResult =
  | { outcome: 'quiescent' | 'no-action'; state: PlaybookState }
  | { outcome: 'unresolved-effect'; state: PlaybookState }
  | {
      outcome: 'failed' | 'aborted';
      state: PlaybookState;
      error?: NormalizedError;
    }
  | {
      outcome: 'terminal';
      state: PlaybookState;
      stateDescription?: string;
      terminal?: PlaybookTerminalOutcome;
      output?: JsonValue;
    }
  | {
      outcome: 'suspended';
      state: PlaybookState;
      pendingCall: PlaybookPendingCall;
    };

type PlaybookRuntimeFactory<Options = unknown> = (
  options: Options,
) => PlaybookRuntime;

export default function createPlaybookRuntime(
  construction: XStatePlaybookRuntimeConstruction<
    PlaybookRuntimeOptions,
    HostCapabilities
  >,
): PlaybookRuntime;
```

For a Captain-hosted linked workflow, the default export conforms to `PlaybookRuntimeFactory<XStatePlaybookRuntimeConstruction<PlaybookRuntimeOptions, HostCapabilities>>`, where `HostCapabilities` is the artifact's exact live schema-3 capability type and `PlaybookRuntimeFactory` is the generic factory type the shared contract module exposes (§Output).
The roleless session-Captain is the sole signature exception: its public options-only `PlaybookRuntimeFactory<PlaybookRuntimeOptions>` wrapper supplies its fixed empty-ledger, fail-closed schema-3 capabilities internally because no Captain host exists above it.

Artifact schema `3` shall require `outcomeAuthority` as an own plain-JSON data property and shall instantiate the shared factory with exactly `{ configuredOptions, hostCapabilities }`, where `configuredOptions` is the registry-validated plain-JSON workflow slice and `hostCapabilities` is a non-null live current-host object.
For schema `3`, the `Options` argument of the one-argument shared `PlaybookRuntimeFactory<Options>` shall be `XStatePlaybookRuntimeConstruction<ConfiguredOptions, HostCapabilities>`; the registry's public entry receives the two members separately and composes that one internal argument only at the artifact boundary.
For a Captain-hosted schema-3 artifact, `hostCapabilities` shall contain exactly `authority`, `repository`, and `effectLedger`: authority binds that artifact's id, schema, detached role and cohort declarations, current configured working directory, logical session and lease-owner identities, and canonical worktree; repository exposes that same canonical identity plus host-bound observation, acquisition, exclusive-call, and cohort operations, whose optional live completion mapper may return only detached `finalText`, `semanticCandidate`, `logicalOperationId`, additional typed ledger commands for the same atomic completion, one `deferred` binding carrying optional UUID `operationId` plus exact `pendingQuestion` and `playerContinuation`, or literal `unresolved: true`, where `deferred` shall be mutually exclusive with `unresolved`, `logicalOperationId`, and commands; and the ledger exposes its synchronous detached `snapshot(): PlaybookEffectLedger` mirror plus `writeAhead(commands: PlaybookEffectLedgerCommandBatch): Promise<PlaybookEffectLedger>` against the current host's atomic writer.
Only `configuredOptions` may reach option snapshotting and FSM input.
The capability object, its callbacks, lease token, and live claim or store handles shall enter neither `PlaybookPorts`, machine input or context, runtime snapshots, launch or durable projections, retained generations, nor continuation identity; the detached ledger data and canonical identities returned by its ledger channel shall instead persist only through the versioned effect-ledger members defined below.

```typescript
type XStateOutcomeFieldAuthority =
  | 'presentation'
  | 'semantic'
  | 'effect'
  | 'runtime';

type XStateRepositoryDisposition =
  | 'unchanged'
  | 'one-descendant-commit'
  | 'deferred';

interface XStateGovernedOutcomeSpec {
  readonly fields: Readonly<Record<string, XStateOutcomeFieldAuthority>>;
  readonly repositoryDisposition: XStateRepositoryDisposition;
}

interface XStateOutcomeAuthoritySpec {
  readonly governedPlayerStates: Readonly<
    Record<
      string,
      Readonly<Record<string, XStateGovernedOutcomeSpec>>
    >
  >;
}

interface XStatePlaybookRuntimeConstruction<
  ConfiguredOptions,
  HostCapabilities extends object,
> {
  readonly configuredOptions: ConfiguredOptions;
  readonly hostCapabilities: HostCapabilities & {
    readonly effectLedger: PlaybookEffectLedgerCapability;
  };
}
```

The shared type-only contract module shall export `PlaybookRepositoryDisposition`, `PlaybookRepositoryObservation`, `PlaybookRepositoryReceipt`, `PlaybookEffectBoundary`, `PlaybookEffectBoundaryStart`, `PlaybookEffectLogicalOperation`, `PlaybookEffectLedger`, `PlaybookEffectLedgerCommand`, `PlaybookEffectLedgerCommandBatch`, and `PlaybookEffectLedgerCapability`; the executable `@sublang/playbook/xstate-runtime` module shall export `assertPlaybookEffectLedger`, `emptyPlaybookEffectLedger`, and `isPlaybookEffectLedgerMonotonicExtension` over those types.
That executable module shall also export the centralized schema-3 semantic surface: `PlaybookSemanticFieldAuthority`, `PlaybookSemanticOutcomeSpec`, `PlaybookSemanticEvidenceInput`, `PlaybookReconciledSemanticOutput`, `PlaybookRetainedSemanticEvidence`, `PlaybookSemanticReconciliationReason`, `PlaybookSemanticReconciliation`, `PlaybookSemanticCandidateStructureError`, and `reconcilePlaybookSemanticEvidence`.
The pure reconciler shall accept the declared state-local outcomes, an unknown semantic candidate, and optional unknown `finalText`, repository receipt, and runtime-field evidence; shall return a detached frozen `resolved` or `deferred` decision with exact output and retained evidence, or an `unresolved` decision with retained evidence and one closed reason from `no-matching-outcome`, `missing-presentation-evidence`, `missing-repository-receipt`, `invalid-repository-receipt`, `repository-disposition-mismatch`, `missing-effect-evidence`, `missing-runtime-evidence`, and `inconsistent-runtime-evidence`; and shall reserve `PlaybookSemanticCandidateStructureError` for candidate defects eligible for the bounded correction path rather than effect-evidence disagreement.
The empty ledger shall be exactly `{ schemaVersion: 1, revision: 0, boundaries: [], logicalOperations: [] }`, and revision shall be zero if and only if both ordered ledgers are empty.
The validator shall capture the complete supplied ledger once as detached frozen JSON and enforce every closed member, identity, ordering, receipt, cross-reference, correction-budget, and logical-operation invariant represented above.
One optional host-owned UUID `cohortId` shall identify every member of exactly one contiguous, distinct-role, all-`unchanged` physical cohort in declared role order; every member shall share attempt, playbook, runtime-session, turn, canonical-worktree, and baseline identity and shall be uniformly started or uniformly complete, complete members shall carry the identical after observation and receipt, and the id shall never be reused by another group.
Within a logical operation, `checkpoint`, `pendingQuestion`, and `playerContinuation` shall be all present or all absent; the pending question shall preserve its exact nonempty authored identity and nonblank content, and `checkpointRestorationEligible: true` shall require that complete bound group.
Each logical operation shall reciprocally name every and only boundary carrying its operation id, share those boundaries' playbook and runtime-session identity, and use its first boundary's exact baseline as `originalBaseline`; every linked boundary shall use that baseline's canonical worktree and, after the first, start from the preceding boundary's complete after checkpoint, while a logical receipt shall require every linked physical receipt.
`isPlaybookEffectLedgerMonotonicExtension(checkpoint, current)` shall accept exact equality and only a ledger reachable through the typed append-or-replace transitions without boundary or operation deletion, identity or original-baseline reassignment, correction-budget replenishment, completed-receipt or evidence loss, or removal or reordering of an earlier boundary-id prefix. A spent correction may replace `semanticCandidate` exactly once only while adding `initialSemanticCandidate` equal to the prior candidate; that initial candidate then remains immutable. A replacement may append boundary ids and replace or clear the complete current checkpoint, pending-question, and player-continuation group together with its eligibility, while an existing logical receipt remains immutable ([DR-040](../specs/decisions/040-outcome-authority-effect-reconciliation.md)).
Every accepted non-idempotent command batch shall increment revision once; an exact start or append replay under the same boundary or operation identities and payload shall return the same acknowledged ledger, while conflicting identity reuse shall reject without mutation.
The host shall assign each started boundary's sequence, current uncertain-attempt UUID, and positive attempt number, and shall assign each appended logical operation's sequence.
Every command batch and every command's entry list shall be nonempty; the host shall apply its commands in order as one ledger transition, perform final cross-reference validation after the complete batch, and acknowledge only one atomic persistence and revision increment.
Every replace command's exact `{ expected, next }` pair shall compare-and-swap one present boundary or operation, preserve its identity and immutable fields, reject a stale expected value, and move optional evidence, the one-way correction budget, or the current logical binding and eligibility only as permitted by DR-040.
After a governed operation settles, the host shall retain any exact proposed completion batch only in live memory until it is acknowledged and the cooperative claim retires; an indeterminate same-process write shall retry or recognize that batch under the still-owned claim, while recovery after process death shall reconstruct only evidence provable from the durable baseline and current repository observation before source restoration.

`governedPlayerStates` shall name every delegated-player state declared by `roleStates`, or shall be exactly empty for an artifact with no delegated-player state; it shall name no other state.
Each state shall name exactly the outcomes in that state's `invoke.input.result`, and each outcome shall contain exactly `fields` and `repositoryDisposition`.
The outcome key owns the semantic discriminator, so `guard` shall not appear in `fields`; the `fields` keys shall equal every additional payload field named by that outcome's result description.
Each field shall have exactly one authority from `presentation`, `semantic`, `effect`, or `runtime`; every linker-declared verbatim payload field and `question` shall be `presentation`, `latestCommit` shall be `effect`, and the payload fields `irNumber` and `irTask` shall be `semantic`, while outcome keys such as `moreTasks` and `finalTask` remain semantic discriminators.
Each repository disposition shall be exactly `unchanged`, `one-descendant-commit`, or `deferred`; an effect-owned field is valid on `one-descendant-commit` and `unchanged` and never on `deferred`, and `deferred` is valid only on `needsBossReply` with presentation-owned `question` and another outcome in that state declaring `one-descendant-commit`.
The linker shall derive each disposition from the source-derived operation and the outcome's required repository effect, independently of whether its result description declares an effect-owned payload field.
A completion that requires committing the result to Git shall declare `one-descendant-commit` even when its outcome is simply `done` with `fields: {}`; its eligible `needsBossReply` arm shall declare `deferred` under the rule above.
The absence of `latestCommit` or any other effect-owned field shall never justify defaulting that completion to `unchanged`.
The shared factory shall reject every legacy artifact schema and reject schema-3 missing, extra, unknown, wrongly owned, or inconsistent metadata before the affected player call.

`init` receives the host-owned playbook session identity and ports, constructs the XState actor with FSM `input` derived from `options`, and starts the actor.
The runtime owns the actor for its lifetime; `handleBossInput` runs one turn, and `dispose` stops the actor and drains pending port emissions.
The host shall generate a non-empty, globally unique `sessionId` for each init-to-dispose lifecycle and shall supply the stable registry or authored playbook id as `playbookId`.
The runtime shall validate non-empty session, playbook, and root ids, a safe
non-negative integer depth, root identity (`depth === 0` and
`rootSessionId === sessionId` with no parent fields), and child identity
(`depth > 0` with non-empty parent session and call ids). It shall copy those
identity scalars and the port references into its own immutable record rather
than retaining the caller's mutable session object. A child `sessionId` shall
differ from both its `rootSessionId` and `parentSessionId`.

Run outcomes are exact: `no-action` means no FSM event was sent;
`quiescent` means a non-failure parked/idle state; `failed` means the FSM is in
a recoverable failure state; `terminal` means top-level final with optional
JSON output and the exact authored `stateDescription` of the reached final
state when one is declared; `aborted` means the turn signal ended work; and `suspended` means
exactly one `pendingCall` is active.
Only the terminal variant may carry `stateDescription`; the runtime shall omit it when the final state declares none and shall never substitute a state id or derive it from opaque output ([DR-037](../specs/decisions/037-terminal-result-meaning.md)).
Control-plane exceptions reject the runtime method rather than masquerade as a
recoverable workflow `failed` result.

Configured options shall be plain JSON and live host seams shall enter only through `hostCapabilities` in the disjoint schema-3 construction input above.
The link compiler emits a typed options interface per playbook based on the FSM's `CodingInput` (or equivalent).
The CLI's absence of `--link-option` values does not mean that
`PlaybookRuntimeOptions` is empty. CLI link options are compile-time inputs;
the runtime options interface is independently derived from every required FSM
input field that is not supplied by `PlaybookSession` or another linker-owned
source. In particular, a required immutable `enabledPlaybooks` catalog shall
remain a required readonly runtime option passed through to machine input; the
linker shall neither invent an empty catalog nor require it to be baked into a
CLI link option.

The linked module shall export public synchronous pure `validateOptions(value: unknown): PlaybookRuntimeOptions` and bind that same function as the shared spec's `snapshotOptions`.
The validator shall first capture `value === undefined ? {} : value` with the public `snapshotJsonValue` exported by `@sublang/playbook/xstate-runtime`, before reading option members, applying defaults, or constructing a replacement record; only top-level `undefined` is normalized, and non-JSON input rejects through that shared boundary.
It shall then validate the artifact's actual option shape, requiredness, source-authored defaults, unknown keys, and declared values against the detached snapshot, reject null and invalid options, and return a detached immutable plain-JSON option record without runtime construction or live host capabilities.
Boss text supplied by the entry event is not a required startup option unless Source independently requires it before the first Boss turn; a generated required type annotation alone is not that evidence.
A generated entry guard that requires the text already in context is likewise
not independent Source evidence; it is a producer defect when the entry action
has yet to copy the event's text. Do not compensate with a required option or
invented startup task. Entry metadata does not populate fresh context before
FSM guards execute. Interrupted-step checkpoints retain accepted input.
A source-appropriate optional seed may remain, and genuine required bootstrap catalogs or other options shall not be erased or filled with invented defaults.

Concrete player binding and prompt identity are host policy and shall not enter `PlaybookRuntimeOptions`, machine input, or the emitted artifact.
For a shell-hosted runtime, `PlaybookSession.roleBindings` shall carry exactly the runtime's local roles, map each to its resolved player id and current prompt identity, and be the sole source for call targeting, player-facing prompt identity, concurrency keys, and trace player ids.
The host shall derive `promptIdentity` from the current effective model when present and the established adapter otherwise; a standalone runtime may omit the map and retain only its local role identity.

## PlaybookPorts contract

```typescript
interface PlaybookPorts {
  recordStep?(step: PlaybookStepRecord, position?: PlaybookRuntimeSnapshot): Promise<void>;
  callPlayer(
    roleId: string,
    prompt: string,
    signal: AbortSignal,
    options: PlayerCallOptions,
  ): Promise<PlayerResult>;
  callCaptain(
    prompt: string,
    signal: AbortSignal,
    options: CaptainCallOptions,
  ): Promise<CaptainResult>;
  callJudge(prompt: string, signal: AbortSignal): Promise<string>;
  callPlaybook(
    request: PlaybookCallRequest,
    signal: AbortSignal,
  ): Promise<PlaybookCallStart>;
  emitStatus(message: string, data?: unknown): Promise<void>;
  emitTelemetry(event: { topic: string; payload: unknown }): Promise<void>;
}

interface PlayerCallOptions {
  freshSession?: boolean;
  resume: string | false;
  /** Complete task and clarification context if the host must start fresh. */
  freshPrompt?: string;
  cwd?: string;
  attachments?: readonly { readonly path: string; readonly mimeType?: string }[];
  permissions?: { mode?: 'auto' | 'bypass'; fileWrite?: 'allow' | 'ask' | 'deny'; shellExecute?: 'allow' | 'ask' | 'deny'; networkAccess?: 'allow' | 'ask' | 'deny'; writablePaths?: string[] };
  nativeSkills?: boolean;
  allowedTools?: readonly string[];
  outputSchema?: Record<string, unknown>;
  onEvent?: (event: { type: string; payload: unknown }) => void | Promise<void>;
}

interface CaptainCallOptions {
  visibility: 'visible' | 'hidden';
  resume: string | false;
  allowedTools?: readonly string[];
}

interface PlayerResult {
  status: 'ok' | 'aborted' | 'error';
  resumeToken?: string;
  finalText?: string;
  error?: string;
}

interface CaptainResult {
  status: 'ok' | 'aborted' | 'error';
  finalText?: string;
  error?: string;
}

interface PlaybookCallRequest {
  callId: string;
  playbookId: string;
  text: string;
}

interface PlaybookTerminalOutcome {
  stateId: string;
  kind: 'success' | 'failure';
  description?: string;
}

type PlaybookCallResult =
  | {
      status: 'ok';
      playbookId: string;
      childSessionId: string;
      state?: PlaybookState;
      output?: JsonValue;
      terminal?: PlaybookTerminalOutcome;
    }
  | {
      status: 'aborted';
      playbookId: string;
      childSessionId?: string;
      state?: PlaybookState;
      error?: NormalizedError;
    }
  | {
      status: 'error';
      playbookId: string;
      childSessionId?: string;
      state?: PlaybookState;
      error: NormalizedError;
    };

type PlaybookCallStart =
  | { state: 'settled'; result: PlaybookCallResult }
  | { state: 'suspended'; childSessionId: string };
```

A runtime's `{ outcome: 'unresolved-effect', state }` abandonment result is not a `PlaybookCallResult`: a host shall not translate it into child output or error, resume a parent FSM with it, or treat it as authored completion.

`PlayerResult` mirrors the status, resume token, final text, and error fields of cligent's `PlayerRunResult` ([TMUX-033](https://github.com/sublang-ai/cligent/blob/main/specs/user/tmux-play.md#tmux-033)).
The runtime treats `status !== 'ok'` as a player failure and routes it through the FSM's error path (§Abort).
An `ok` player result whose `finalText` is missing, empty, or whitespace-only
earns exactly one corrective re-ask: the same player call repeated under the
stored resume selection, traced as its own player-call pair, before a second
such result routes through the same error path.

`callCaptain` runs a direct-Captain FSM actor against the host's Captain
agent. The linked runtime shall pass
`{ visibility: 'visible', resume: false }` for authored workflow calls so
XState context, rather than an agent conversation, owns workflow continuity.
The tool restriction is source-owned: the runtime shall additionally pass
`allowedTools: []` exactly when the GEARS source itself restricts the acting
Captain from tools (a routing-only Captain policy such as the default generic
Captain). A transformation-performing Captain — e.g. a compiler phase compiled
from a transformation-spec source, whose behavior writes a declared target
artifact — works through the host Captain's own tools, so its calls shall
carry no `allowedTools` restriction.
Accordingly, `CaptainCallOptions.allowedTools` is optional: an explicit empty
array requests a tool-free call, while omission preserves the host Captain's
configured tools.
`CaptainResult` carries no resume token or player-continuation selection.
A non-`ok`
result, or an `ok` result whose `finalText` is missing, empty, or
whitespace-only, shall record that failure on the call's single finish trace.
A non-`ok` result shall then reject the actor through the FSM's error path
with no corrective re-ask; an empty `ok` result shall first earn exactly one
corrective re-ask — the same call repeated, traced as its own
started/finished pair — and only a second such result shall reject the actor
the same way. These structured host-result failures are recoverable
workflow failures, not control-plane failures: the runtime shall let the actor
take `onError`, drive it to quiescence, drain ordered emissions, and resolve
the public method with `{ outcome: 'failed' }` carrying the failure state's
error. This matches the delegated-player result boundary.
A non-abort thrown `callCaptain` port, a malformed host result, and a rejecting
trace sink remain control-plane failures that reject the public method. If the
required finish sink rejects after a structured host-result failure, the
actor's error and failure-state evidence shall remain the host-result failure,
while the public method rejects with the sink failure surfaced by the turn's
emission drain. Absent such a control-plane failure, if the combined signal
has aborted, ordinary abort settlement remains authoritative after the actor
reaches its error path.

Every standalone linked runtime owns a private continuation map keyed by resolved player id when `roleBindings` is supplied and by local role id otherwise.
Before reading a resolved direct-Captain or delegated-player result, the
runtime shall validate, detach, and freeze it through the shared
`validateCaptainResult` or `validatePlayerResult` helper. The accepted object
shape is exact: only the declared status and optional string fields are
allowed, JSON-unsafe members reject, and caller mutation after resolution
cannot change trace evidence or player continuity. Validation happens before
adopting a resume token or reading final text.
The first call to each private continuation key in a standalone playbook session shall pass `{ resume: false }`; later calls shall pass the exact stored token, so two sequential roles explicitly bound to one player id share one token even without a supplied `PlayerSessionStore`.
After a validated resolved call, the runtime shall replace the token when the result carries one, clear it only for an `ok` result that omits one, and preserve it for an `aborted` or `error` result that omits one; a rejected call with no result likewise leaves the prior token unchanged.
After awaiting a host Captain or player promise, the runtime shall re-check the
combined invocation/public-boundary signal before validating the result,
adopting a resume token, or emitting a successful finish. A host promise that
ignores cancellation and resolves late shall be paired as aborted and shall
not mutate continuity or masquerade as success.
The map survives actor reconstruction inside the same runtime and is discarded at `dispose`.
The runtime shall keep an in-flight set keyed by resolved player id when the
host supplies binding metadata, otherwise by local role id, and reject a
second concurrent call to the same key before crossing the host port.
Calls to distinct keys may overlap.

`callJudge` returns free-form text.
The runtime parses it per the state's adjudication strategy (§Captain adjudication).
One port serves both classifier and adjudicator — they vary only in prompt.
Concurrent `callJudge` attempts within one linked runtime shall pass through
one abort-aware local FIFO. After the host promise resolves, the runtime shall
require a string reply and re-check the combined signal before tracing or
parsing success, so a non-cooperative late judge cannot outlive cancellation.
The host shall serialize `callCaptain` and `callJudge` together through one
shared abort-aware concurrency-one FIFO because both use the same single-flight
Captain lane, even when distinct player ports overlap [[4]]. A direct Captain
call's subsequent adjudication shall enter that same queue only after the
visible call has settled; the linked runtime shall not hold one queue lease
while requesting the other port.
Use one shared `PQueue({ concurrency: 1 })` for the individual host
`callCaptain` and `callJudge` promises. Do not pass an invocation or public
boundary signal as `PQueue.add(..., { signal })`: PQueue may release a running
slot as soon as that signal aborts even though a non-cooperative host promise
is still executing, which permits overlap. Instead check the combined signal
inside the queued task before crossing the host port, await the host promise
without releasing the queue lease, and check the signal again afterward.

`callPlaybook` starts a function-style child call.
The caller runtime supplies its stable call id and the XState invocation's
lifetime signal.
The host drives the child's initial text before resolving the port with either
an immediate settled result or a suspended child session.
Suspension is resumed later through `PlaybookRuntime.resumePlaybookCall`; the
port promise itself shall not remain pending across Boss turns.

`emitStatus` is human-readable; `emitTelemetry` is structured.
Both are async and shall be ordered, awaited, and never-dropped; the runtime awaits each emission before issuing the next.

The runtime never speaks to LLMs directly and never touches host types beyond `PlaybookPorts`.

## Playbook trace

Every linked runtime shall emit a boundary-complete, ordered trace through `emitTelemetry` topic `playbook.trace`.
Each payload shall carry `schemaVersion: 4`, the immutable session identity and
causality, a contiguous one-based `sequence`, a Unix-millisecond `timestamp`, a
trace `type`, event `payload`, and the runtime-local `turnId` / paired `callId`
where applicable.

```typescript
type PlaybookTraceType =
  | 'session.started'
  | 'boss.input.received'
  | 'judge.call.started'
  | 'judge.call.finished'
  | 'player.call.started'
  | 'player.call.finished'
  | 'captain.call.started'
  | 'captain.call.finished'
  | 'playbook.call.started'
  | 'playbook.call.finished'
  | 'apply.started'
  | 'apply.finished'
  | 'fsm.transition'
  | 'outcome.accepted'
  | 'status.emitted'
  | 'boss.input.settled'
  | 'session.disposed';

interface PlaybookTraceEvent {
  schemaVersion: 4;
  sessionId: string;
  playbookId: string;
  rootSessionId: string;
  parentSessionId?: string;
  parentCallId?: string;
  depth: number;
  sequence: number;
  timestamp: number;
  type: PlaybookTraceType;
  turnId?: number;
  callId?: string;
  payload: JsonValue;
}
```

A composing host may supply `playerSessions` as a frame-local view of player continuation owned by the logical Captain session.
The runtime shall select through that view before allocating or tracing a player call and shall update or clear it from a validated player result before emitting the matching finish trace.
Snapshot export and restore shall use the same view, failed restore shall leave its prior contents unchanged, and child disposal shall not clear host-owned continuation.
A host that omits the view retains the runtime's private per-session continuation behavior.

The trace types are `session.started`, `boss.input.received`,
`judge.call.started`, `judge.call.finished`, `player.call.started`,
`player.call.finished`, `captain.call.started`, `captain.call.finished`,
`playbook.call.started`,
`playbook.call.finished`, `apply.started`, `apply.finished`,
`fsm.transition`, `outcome.accepted`, `status.emitted`,
`boss.input.settled`, and `session.disposed`.
No trace event whose `schemaVersion` is below `4` is authority-bearing accepted-outcome evidence.
Call pairs carry exact prompts and replies, normalized failures, actor and state
identity, and their boundary-specific options.
`apply.started` and `apply.finished` are the paired apply boundary of a
executed `apply()` call on a runtime implementing the optional control surface
(§Control surface): both carry the action id and idempotency `key` (plus the
singular `stateId` on start when one exists), the pair shares one
session-unique `apply-<n>` call id and the boundary's turn id, and the finish
adds the receipt `disposition` with its `reason`, normalized `error`, or
projected `run` result, all JSON-safe. A repeated idempotency key returns the
recorded receipt without a new pair.
Direct-Captain start and finish payloads shall carry `allowedTools` exactly when
the originating `CaptainCallOptions` selects it and shall omit the member when
the call preserves the host Captain's configured tools.
`session.started` and `session.disposed` carry their descriptor as top-level
`state` and its singular `stateId` when present. An adopted runtime begins its
fresh target trace with `session.started` at sequence `1`; that event also
carries an exact nested `adoption` object with `sourceSessionId` and
`sourceGenerationId`, plus the source/target call and child-session identities
when a suspended edge was rebased. The suspended form carries the fresh target
call id as top-level `callId` and carries no source `turnId`. Every judge start
and finish carries the working snapshot's singular `stateId` when one exists;
classification uses the current descriptor and adjudication uses the invoking
actor input. The default Captain always has such a singular id, while a
parallel snapshot may omit it. Every judge finish also carries
`status: 'ok' | 'aborted' | 'error'`. Every `status.emitted` carries the
described top-level `state` and its singular `stateId` when present, as well as
its message and optional data; consumers shall not have to recover state
identity from a nested ad hoc object.
Judge results use `reply`; player start and finish payloads both carry the
local `roleId`, the resolved `playerId` when host binding metadata is
available, and the selected `resume`; Captain start and finish payloads both carry
the exact composed prompt, the boundary's selected `visibility`, the direct
invocation's `stateId` and `sourceItem`, and no player resume selection or
resume token — a visible workflow call carries its runtime-owned
`resume: false` selection, while a hidden controller call
(§Captain adjudication) omits the `resume` member altogether, its
durable-conversation selection being host-owned;
judge `purpose` is
`boss-input-classification`, `player-output-adjudication`, or
`captain-output-adjudication`; and every error uses
`{ name, message, stack? }` rather than a raw string or `Error` instance.
The Captain finish payload shall preserve the exact `CaptainResult` status and
final text when present, while carrying any failure in normalized form.
An `ok` result without non-empty `finalText` therefore retains status `ok` but
also carries the normalized missing-text failure; the corrective re-ask that
follows (§PlaybookPorts contract) traces as its own started/finished pair, and,
when that corrective call happens, only a second such finish makes the actor
reject.
If the Captain port rejects before returning a result, the finish instead
carries explicit `status: 'aborted'` when the combined signal has aborted or
`status: 'error'` otherwise. A finish boundary never omits status merely
because there was no structured host result.
The pair obligation also applies when a port promise rejects or throws: the
linked runtime shall emit and drain one normalized finish boundary before it
propagates the failure. No started call boundary may be left without its
matching finished boundary.
If a started-boundary sink records the event and then rejects, the runtime
shall make one best-effort normalized error-finish attempt with the same call
id and then reject the original start error. It shall not retry either event or
let a failure of that finish attempt replace the start error.
A start-sink rejection causally identical to the applicable signal reason is
the cancellation itself, not a control error: no host call begins, the
best-effort paired finish carries the boundary's canonical aborted evidence —
`status: 'aborted'` for a host call, or the rejected-before-effect disposition
and reason for apply — and nothing is latched. An ordinary run boundary settles
as §Abort prescribes. At the apply boundary the same event remains
pre-acceptance: `apply` rejects with that exact reason, records no receipt, and
leaves the key reusable
([DR-036](../specs/decisions/036-coherent-abort-settlement.md)).
When a call boundary carries `callId`, that id shall be unique within the
runtime session. A stable FSM `stateId` is identity metadata in the payload,
not a call id and shall not be reused as one across repeated invocations.
Optional trace and run-result members shall be omitted when absent; the runtime
shall not create own `turnId`, `callId`, parent identity, output, or error
properties with value `undefined` and then rely on JSON serialization to drop
them.
A `boss.input.settled` payload shall project the complete structured run
result: its outcome must be one of the `PlaybookRunResult` discriminants (never
an invented `error` outcome), and it shall include `state`, singular
`stateId`, `pendingCall`, `output`, and normalized `error` whenever the matching
result arm carries them.
The `unresolved-effect` arm shall carry only `state`; bounded repository-effect evidence remains host-owned and shall enter neither that result nor its trace projection.
One runtime-owned concurrency-one emission queue shall serialize every trace,
human status, and state telemetry call. Sequence allocation and enqueueing
shall occur atomically, and every public method shall drain that queue before
resolving or rejecting. A state transition emission queued on entry shall be
observed before the invoked boundary's `*.started` event, even when a host
delays `emitTelemetry`.
The linked module shall use `PQueue({ concurrency: 1 })` from `p-queue` for
this ordering and drain it with `onIdle()` rather than recreate a promise-queue
implementation in every generated artifact.
An XState inspection callback shall synchronously enqueue the transition
trace, state telemetry, status trace, and human status in that order before it
returns. `emitStatus` likewise enqueues its trace and port emission in the same
synchronous call. Do not enqueue state telemetry or the status port from a
`trace(...).then(...)` continuation: the queue can become momentarily idle,
letting an invoked actor's `await drain()` overtake those dependent enqueues.
All validation happens before these synchronous enqueues; later sink failures
are caught into the appropriate latch without changing their queue position.
FSM trace events carry the same transition, pending-question, and normalized-error fields as state telemetry.
Trace emissions are awaited and sequenced before the boundary operation or human status/state telemetry they describe.
Every event in one session carries the same root/parent/depth identity.
A parent call start precedes its child `session.started`; the child's
`session.disposed` precedes the parent call finish.
Parallel call finishes may occur in either order, so consumers shall use call
ids for pairing and sequence for the observed total order.

This trace covers everything observable through `PlaybookRuntime`; host-specific adapter streaming remains in the host record stream.
Trace payloads never become Boss-visible status or prompt text.

## Linker inputs

The link compiler shall accept:

- The FSM artifact (path to a `.fsm.ts`).
- An **adjudication strategy** (default: LLM-judge per state) and a
  **Boss-event mapping** (default: free-text judge classification).
  Both strategies are host-agnostic.

The host's identity does not enter compilation; the linked module runs unchanged under any host that implements `PlaybookPorts`.

## Role identity

Each delegated GEARS state names exactly one canonical local role id (`player` actor `invoke.input.role`).
The linker shall retain that id in `PlaybookPorts.callPlayer(roleId, …)` without selecting a concrete player.
The host shall bind that local role id explicitly when it constructs the runtime.
Every direct-Captain and delegated-player invocation shall also carry its
working leaf's explicit
`stateId`; a linked runtime shall use that field for call identity and shall
not infer one leaf from a structured root snapshot.
Direct `captain` actor states call `PlaybookPorts.callCaptain`; the linker shall not synthesize a local role or concrete player id named `captain` for them.
The linker shall reject an alias-shaped role declaration rather than choose a runtime identity.

## Player prompt composition

The runtime shall compose the actual player prompt from the state's
`PlayerInput`.
The shared-factory `composePlayerPrompt` seam shall receive an
invocation-scoped `promptIdentity(roleId)` lookup as its second argument.
The lookup shall return the current detached session binding's prompt identity,
or the canonical local role id when bindings are absent, and shall reject an
undeclared role.
It shall expose neither the resolved player id nor the binding map, and the
runtime shall not place the lookup or any value read through it in options,
machine input, FSM context, or a persisted snapshot.
`input.prompt` is the GEARS-derived domain prompt body and shall not be mutated, re-flowed, or treated as a place to store framework control instructions.
A leading `>` inside that body is authored quoted-context content and shall reach the player unchanged.

The composer may prepend structured labelled blocks from typed `PlayerInput`
fields the FSM exposes (for example `Boss intent:`, `Review items:`,
`Rebuttals:`, or `Task description:`).
Those blocks are outside the domain prompt body.

The composer shall not inject a player-visible Boss-question instruction.
Boss-question detection is adjudicator-facing: it comes from the state's `needsBossReply` result description, not from extra prompt text.

When `PlayerInput` carries both `pendingBossQuestion` and `bossReply`, the composer receives an optional third `resuming` boolean after `promptIdentity`; absent means fresh.
The shared `composePlayerContinuation(input, body, resuming)` helper prefixes the verbatim Boss reply and, only for a fresh conversation, the pending question labeled `Your previous question:`.
A resumed call omits that question; a fresh call includes it before `Boss reply:`.
Both retain the authored task body exactly once, with two newlines between blocks.
These framework blocks never enter `invoke.input.prompt` or persisted FSM context.

The shared runtime hands a composer the call's input without `pendingBossQuestion` and `bossReply` and builds the continuation itself, so a player of any language reads it as structure (DR-090).
Before the composer's result it places, in order:

- `Role: <roleId> · Model: <promptIdentity>`, naming the call's local role and its current binding's prompt identity, or `Role: <roleId>` alone without bindings;
- once the run has heard a Boss reply, the run's Boss exchanges so far, each a `? ⟶` line and the verbatim question, then a `Boss ⟶` line and the verbatim reply, whatever the role and whether or not the Source retains them, leaving out the one exchange the call's own continuation carries;
- for a call after a Boss reply, the marked verbatim question, only for a fresh conversation, and the marked verbatim reply.

A run begins at a deterministic entry or an event declared on the initial parked state itself, including a classified entry from recoverable failure, or at a finished machine's restart; a reply, global interrupt alone, or refused event starts no run. Its exchanges travel in the runtime snapshot as `bossExchanges`.

The runtime chooses the compact prompt only after selecting a conversation token and carries the complete prompt as optional `PlayerCallOptions.freshPrompt`.
A host starting fresh after a definite pre-execution token rejection uses `freshPrompt`, when supplied, instead of the compact prompt.
Without that option, the given prompt remains complete.
Traces and host observations record the respective prompts actually sent.
Old composers may ignore the optional argument and retain their full prompt.

## Captain prompt composition

The runtime shall compose a direct Captain prompt from the state's
`CaptainInput` under the same prompt-integrity rules: `input.prompt` remains the
verbatim GEARS domain body, while specific typed fields may be supplied as
labelled blocks and substituted for their declared placeholders.
It shall not introduce a player binding or player resume instruction.
String fields substitute verbatim. Arrays and objects such as the sanitized
enabled-playbook catalog, remaining plan, and completed child results shall be
validated as JSON-safe and rendered as deterministic JSON; they shall never be
coerced through default JavaScript string conversion or expose untyped context.
Deterministic rendering shall sort object keys lexicographically at every
depth while preserving array order, so equivalent JSON values produce the same
prompt independent of host property insertion order.
At construction, a structured host-owned catalog shall be validated against its
declared exact entry shape, copied, and frozen recursively so later caller
mutation or extra properties cannot alter a prompt or machine decision.
For the default Captain catalog, every entry has exactly the own enumerable
data keys `id`, `command`, and `intent`; all three values are non-empty strings,
and `id` values are unique. Empty values, duplicate ids, extra keys, accessors,
non-plain objects, and non-JSON data reject runtime construction rather than
being silently repaired or discarded.

When a direct Captain task resumes from its own Boss question, the composer
shall prepend the same continuation preamble and labelled Q&A blocks defined in
§Player prompt composition. The runtime shall pass the complete composed prompt
once to `callCaptain` with `{ visibility: 'visible', resume: false }` and the
same source-owned tool restriction as the originating call; it shall not
expose the
subsequent adjudicator prompt or structured judge reply through that visible
call.
The composed prompt shall contain only the GEARS blockquote, typed runtime
evidence blocks, and the continuation preamble.
It shall not append the state's result map, guard names, result-property
schema, adjudication request, workspace context, or tool instructions.
The shared Captain composer shall replace every known placeholder whose
matching typed field is present in the supplied input. It shall not choose one
exclusive replacement set from `stateId`, source-item identity, or another
variant discriminator. Verification may deliberately combine catalog,
intent, plan, result, question, and reply fields in one synthetic input; every
matching placeholder in that template still has to be rendered.
Construct the replacement table from field presence alone. In particular,
populate `<remaining-plan>` when `remainingPlan` is supplied and
`<completed-call-results>` when `completedCallResults` is supplied, regardless
of the input's `stateId` or `sourceItem`. An implementation branch such as
`if (input.stateId === 'reassessment')` around either replacement is
nonconformant.

## Boss-event mapping

The FSM's `events` union enumerates every Boss-originated event.
The runtime receives Boss input as a free-form string
(`handleBossInput.text`).
Where the current ready, recoverable-failure (`failed`), or reconstructed
terminal machine accepts exactly one
ordinary textual entry event and no Boss question is pending, the runtime
shall send that event deterministically and attach the exact original text to
its declared textual payload field without invoking `callJudge`: each of the
three is an entry awaiting a fresh intent, so delivered text has exactly one
meaning there and a judge call could only spend budget or settle the restart
as no action.
The default Captain — the controller playbook of
[gears2fsm "Setup"](gears2fsm.md#setup) — is deterministic at every parked
entry: the runtime maps each Boss turn from the exact text and the host's
deterministic command-parse resolution, supplied through the linked options'
controller port, to the rewritten machine's hub entry union —
`{ type: 'BOSS_TURN', bossText: turn.text }` for an undecided turn,
`{ type: 'PARSED_RESPOND', bossText: turn.text }` for a parse-resolved
`respond`, `{ type: 'PARSED_ACTION', bossText: turn.text, decision }` carrying
the injected parse-resolved decision object, and `{ type: 'SHUTDOWN' }` for the
host's teardown resolution — and invokes no classifier judge call; the exact
original text still rides only the runtime-owned textual payload field.
All other non-empty turns shall use `callJudge` only to choose one of the FSM's
event kinds and non-text routing fields, or no FSM action.
An entry requiring a judge-selected routing field therefore omits deterministic
`entryEvent` metadata and declares its exact fields through `bossEvents`.
The shared engine derives that entry from the initial parked state's own
transitions and resets the run's exchanges when it dispatches the entry.
At a terminal state, the classifier uses those initial entry transitions and
their guards under detached bound machine input. This evaluates pure context
and assignment initialization under the supported FSM contract; it does not
run returned executable actions or start actors. Global interrupts and reply
events are not terminal entries.
The classifier prompt shall include the exact, unmodified `turn.text` in a
clearly labelled Boss-message block so the judge can make that choice. Omitting
the message makes a parked-state classifier unable to distinguish an answer,
a fresh directive, and no action; including it does not authorize the judge to
rewrite the runtime-owned textual payload fields.
For `BOSS_INTENT` and `BOSS_INTERRUPT`, the runtime shall attach the exact
original text as `bossIntent`; for `BOSS_REPLY`, it shall attach the exact
original text as `answer`.
The classifier prompt shall neither request nor accept a copy of those fields,
and classifier-authored paraphrases shall never become machine context.
Empty or whitespace-only text produces no event, judge call, Captain call,
player call, status emission, or FSM transition; its received and settled
session-trace events are still emitted.

The classifier prompt shall demand JSON against the FSM's typed event union and any state-specific Boss input contract, including non-text routing payload fields required for each event but excluding the runtime-owned textual fields above.
Fields the FSM's event union declares optional shall stay optional in the classifier contract and the reply parser; the classifier shall not promote them to required.
The runtime shall parse the judge reply tolerantly before validating the
event. It shall recover the intended JSON object from surrounding prose or a
Markdown fence, ignore earlier non-JSON bracketed prose, remove a trailing
comma before a closing brace or bracket, and complete a truncated
unterminated string or unclosed object/array. When several values are
recoverable, it shall choose the first object in document order, preferring a
strict parse at each candidate position before repairing that same candidate.
For each opening-brace position, first scan strings and nesting to find that
candidate's earliest balanced closing boundary. Both the strict parse and the
trailing-comma repair shall operate on only that bounded substring. If no
closing boundary exists, repair may complete the unterminated suffix. The
implementation shall never repair the entire remaining document after a
balanced candidate, because later prose or a later clean object would make the
earlier repair fail. Advance to the next opening brace only after strict and
repaired parsing of the current bounded candidate both fail; an earlier
repairable object therefore wins over every later strict object.
When no object is recoverable or the recovered event/payload is invalid, the
runtime shall emit exactly one status and send no FSM event; a malformed
classification is recoverable control input, not a public boundary rejection.
If a recovered `BOSS_REPLY` names no question that is currently pending, it is
such a malformed classification: emit the one recovery status, send no event,
leave the actor unchanged, and return `no-action` after emissions drain.
Host-owned runtime options, role-to-player bindings, and enabled-playbook catalogs are
not Boss-event payload. The classifier schema and parser shall not invite or
accept them, and classified prose shall never overwrite their machine context.
Every recovered classifier object shall have exactly `type` plus the declared
non-text routing keys for its selected event arm. Extra own keys, including a
classifier-authored `bossIntent` or `answer`, reject the classification; the
parser shall not accept and discard injected catalog, option, state, or
routing fields.
`NO_ACTION` in particular is exactly `{ type: 'NO_ACTION' }`.
A valid `NO_ACTION` returns `no-action` without an invalid-classification
status and leaves the actor untouched. It is a successful classifier choice,
not the same parser result as malformed or unrecoverable classifier output.
After any successful classifier call drains, re-check the active Boss signal
before reconstructing a terminal actor or sending the selected event. If it
aborted while the classifier finish emission was pending, return and trace the
same structured `aborted` result against the unchanged actor.
When the FSM supports a Boss-reply suspension state, the prompt shall inspect
the actor snapshot context and include each exact pending Boss question,
question id, and discriminated Captain-or-role asker so the judge can distinguish a reply from a fresh directive.
With one pending question, a classified `BOSS_REPLY` that omits its optional id shall be filled with that sole id.
With several pending questions, the classifier shall require a known id.
A reply shall re-enter only
its recorded resume state and preserve the original intent, plan, prior child
results, and Q+A continuation context.
The classifier-facing pending-question block contains only `questionId`, `asker`, and `question`.
Internal `resumeStateId`, source-item identity, and
other machine-routing fields remain authoritative in snapshot context and
shall not be serialized into the judge prompt.
The allowed fresh directives while parked include every applicable root entry
event and `BOSS_INTERRUPT`; accepting one shall abandon and clear the pending
question and reply context before new work begins.

A playbook runtime shall not define slash-prefix commands for states or features inside that playbook.
The `/command` namespace is reserved for host-level or playbook-selection UX before a turn reaches `handleBossInput`.
If a host forwards text beginning with `/` to `handleBossInput`, the runtime treats it as ordinary Boss text and maps it through the same deterministic-or-classified Boss-event rules.

Hosts that receive structured control input shall resolve host-level concerns before choosing a playbook runtime.
Once they call `handleBossInput`, they shall pass the Boss content as text and shall not pre-classify in-playbook FSM events or rely on slash forms as a runtime protocol.

Within `handleBossInput` classification, `BOSS_INTERRUPT` (or the FSM's equivalent explicit-state-jump event) is reached only by the judge choosing it and supplying its required target payload; `apply()` of a runtime-advertised action (§Control surface) is the second, runtime-validated path to the same events, and on neither path does the host fabricate an FSM event itself.
It is _not_ an abort surface; aborts go through the abort signal and the strategies in §Abort.
Hosts where the abort signal is terminal (e.g., SIGINT runs shutdown) shall not route abort to `BOSS_INTERRUPT`.

## Captain adjudication

After a direct Captain or delegated player call returns, the runtime shall
coerce `result.finalText` into one of the **per-state**
`invoke.input.result` keys.
It shall also extract any payload fields the state's `result` description names as required.
Required-field extraction shall recognize both an exact backticked property
name such as `` `question` `` and the standard annotated form
`` `question: <verbatim question text>` ``; in either form only `question` is
the JSON property name.
Extraction is limited to the description's explicit `Output shall include`
clause (or equivalent typed output metadata). Backticked prose before that
clause can name statuses, guards, or concepts such as `ok`, `aborted`, and
`error`; those names are not output properties and shall never become required
judge fields.
For a nongoverned delegated-player field annotated exactly `` `<field>: <verbatim final text>` ``, the judge shall select the guard but the runtime shall replace any judge-supplied value with the player's canonical non-empty final text before returning the actor output.
For an artifact-schema-3 governed field, that annotation instead declares presentation authority and any judge-supplied value is a structural error under the authority rule below.
The linker shall derive the complete `verbatimPayloadFields` set from those annotations across the FSM result maps.
A field name that is annotated in one result map and unannotated in another is a link error because the shared adjudication strategy cannot give one property both ownership policies.
For a direct Captain result, `question` and `response` are human-presentation
fields owned by the visible call rather than fields authored by the hidden
judge.
The adjudicator shall select the guard and supply only other structural fields
required by that guard.
After validating that selection, the runtime shall inject the exact non-empty
`CaptainResult.finalText` as the selected output's `question` or `response`.
It shall reject a judge reply that supplies either presentation field as an
undeclared extra key, so hidden adjudication cannot replace, paraphrase, or
decorate prose Boss already saw.
For an artifact-schema-3 governed delegated-player call, the shared engine
shall instead use one semantic reconciler for both the default linked runtime
and any linked machinery of an artifact's own that adopts schema `3`.
That reconciler shall retain the validated player's exact non-empty
`finalText` as opaque presentation evidence, let the hidden adjudicator read
it only as semantic evidence, and require the adjudicator's detached
plain-JSON candidate to contain exactly `guard` plus every and only
semantic-owned payload field declared for that guard.
The candidate shall therefore contain no presentation-, effect-, or
runtime-owned payload field; `guard` shall name exactly one outcome declared
by both the live result map and `outcomeAuthority`; and every semantic-owned
field shall satisfy the result map's required-field type before any actor
output is delivered.
That type is the value shape the compiled FSM's own validator admits for the
field: the shared engine reads it once at construction by presenting each
governed outcome's accepting arm with sample values of a closed set of shapes,
a field whose shape the FSM admits as a string stays a string, a field whose
shape it does not reveal takes any JSON value for the FSM's own guard to
decide, and the judge prompt and validation error name every non-string shape
([DR-089](../specs/decisions/089-judge-replies-take-the-machines-shapes.md),
[DR-091](../specs/decisions/091-an-unrevealed-shape-is-the-machines-to-judge.md)).
The judge prompt shall render each governed outcome's description with its
meaning verbatim and its `Output shall include` clause replaced by that reply
contract — exactly `guard` plus the semantic-owned fields, each keeping its
authored placeholder or guidance, with every presentation-, effect-, or
runtime-owned field named as runtime-supplied to omit — so the judge is never asked for a
field it does not own; the artifact's description text stays unchanged.
The shared engine shall export that rendering as `renderGovernedOutcomeContract`
on `@sublang/playbook/xstate-runtime`, and linked machinery of an artifact's
own shall render its judge prompt through it rather than restate the contract.
The reconciler shall construct the complete actor output rather than accept a
cross-authority object from the judge: every presentation-owned payload field
shall receive the canonical `finalText.trim()` value; every effect-owned
field shall receive only the qualifying receipt's repository fact selected by
the accepted outcome's declared disposition — the exact new-descendant commit
OID on `one-descendant-commit`, or the matching `unchanged` receipt's
observed HEAD OID on `unchanged` — never a value keyed on the field's name;
and no authority may supply, overwrite, or contradict another authority's
field.
It shall reject an absent required field, an undeclared or extra field, a
field supplied by the wrong authority, an invalid value, or any mutually
inconsistent candidate before FSM delivery.
When no outcome matches, a governed judge may instead return exactly
`{ blocked: <nonempty explanation> }`.
The shared reconciler retains this candidate and returns `no-matching-outcome`
with its explanation as a `runtime-defect` cause; it authorizes neither a
corrective judge nor an FSM outcome.
Both shared and bespoke judge prompts shall state this alternative explicitly
instead of forcing a match when the declared results are incomplete.

For a non-deferred candidate, reconciliation shall require a complete durable
physical receipt, or the complete cumulative logical receipt of a deferred
operation, whose classification is exactly the outcome's declared
`unchanged` or `one-descendant-commit` disposition; a `one-descendant-commit`
receipt shall carry exactly the after-HEAD OID used for the arm's effect-owned
fields, and lists every new commit in `commits` where HEAD advanced by more
than one, while an `unchanged` receipt's complete validated observation
supplies its observed HEAD OID for them, and a receipt that cannot prove that
observed HEAD shall leave the envelope unresolved rather than inject a
fabricated value.
A `one-descendant-commit` outcome shall also resolve over an `unchanged`
receipt whose HEAD names a commit when no outcome of that call declares
`unchanged` and the trimmed `finalText` names that commit as a word, by its
full OID or an abbreviation of at least seven leading hex digits; its
effect-owned fields then take that HEAD OID.
A `deferred` candidate shall be admissible only for its already-validated
effect-authorized `needsBossReply` outcome and only from a complete after
observation whose HEAD equals the logical operation's original baseline HEAD
and whose classification is exactly `unchanged` or `worktree-only-change`.
It shall become deliverable only after the current host durably acknowledges
the exact checkpoint, question, continuation, and logical-operation binding
defined above; a missing checkpoint, changed HEAD, multiple or rewritten
history, detected concurrent or foreign change, or ambiguous observation
shall leave it unresolved.

The first structurally invalid schema-3 semantic reply shall make at most one
corrective hidden adjudication eligible over the identical retained
presentation evidence and declared outcome schema, with the validation error
restated.
Before starting that corrective judge, the runtime shall compare-and-swap the
boundary's `correctionBudget` from `{ limit: 1, spent: false }` to
`{ limit: 1, spent: true }` while atomically retaining its receipt, opaque
presentation, and first recoverable invalid `semanticCandidate` through
`effectLedger.writeAhead`, await the durable acknowledgement, replace its
mirror with that acknowledged ledger, and check the applicable abort signal
again.
A failed or indeterminate spend, an acknowledgement that does not contain the
exact one-way update, a previously spent budget, or an abort before the call
begins shall start no corrective judge; the spent value shall remain spent
across export, restore, adoption, and process restart.
A second structurally invalid reply shall receive no further correction.
A player abort, error, non-`ok` result, or missing non-empty `finalText` shall
start no adjudication, while an initial or corrective judge transport failure
or invalid host result shall start no corrective or third judge respectively.

Only a complete, authority-consistent semantic-and-effect envelope shall be
delivered once to the FSM, and only after its evidence and applicable
correction-budget or deferred-operation updates are durably acknowledged.
The completion path shall retain the opaque `finalText`, the latest recoverable
detached plain-JSON semantic candidate even when it is structurally invalid,
and the receipt and correction budget without parsing the presentation for a
repository fact; where a correction replaces that candidate, immutable
`initialSemanticCandidate` shall preserve the candidate that consumed the
budget, while a malformed reply from which no JSON value can be recovered may
omit both candidates.
An effect-possible envelope whose presentation, semantic, effect, or deferred
checkpoint evidence is absent, invalid, incomplete, or inconsistent shall
deliver no actor output and shall remain parked for later reconciliation;
once its matching source state is restored, reconstruction from a durable
complete envelope may perform that same reconciliation once without another
player or judge call.
The adjudicator shall use the same document-order tolerant JSON recovery as
the Boss classifier. Unlike invalid classification, a reply from which no
object can be recovered, an undeclared guard, or a missing required field is a
control-plane error for nongoverned delegated-player adjudication and
shall throw after the invocation reaches its FSM error path and ordered
emissions drain; schema-3 governed adjudication follows the bounded
reconciliation contract above instead.
Direct-Captain adjudication treats such a reply, or one carrying an undeclared
field, as a structural error: it makes exactly one corrective adjudication over
the same visible output that restates the reply and its validation error, and
a second structural error routes the invocation to its FSM failure state as a
recoverable `judge-failed` failure rather than a control-plane error
([DR-089](../specs/decisions/089-judge-replies-take-the-machines-shapes.md)).

Two default adjudication strategies, in selection order:

- **LLM-judge** (default): construct a fresh prompt for `callJudge` that
  names the source item's actor (and delegated player where applicable),
  includes the actor's verbatim output,
  lists the `result` keys with their descriptions, and demands a JSON
  answer keyed to exactly one of the declared guards: a nongoverned player uses
  `{ guard, …structuralPayloadFields }`, while a governed schema-3 player uses
  `{ guard, …semanticOwnedPayloadFields }` and explicitly forbids every other
  payload field. The governed form also permits the blocked report above when no outcome matches.
  Both forms exclude the runtime-injected direct-Captain
  `question` and `response` fields above. A direct-Captain prompt keeps each
  description and states under it the exact reply that key takes — `guard`
  plus the structural fields its `Output shall include` clause names, each with
  its authored placeholder — naming `question` and `response` as
  runtime-supplied. The prompt shall identify hidden control work,
  prohibit tool use, file inspection, and external evidence, direct the judge
  to decide only from the supplied actor output and declared outcomes, and
  require exactly one JSON object with no prose. The judge prompt shall not
  interpret the player's output, paraphrase it, or alter the FSM's `result`
  text — it carries the description verbatim, except that a governed
  schema-3 outcome's `Output shall include` clause is rendered as the
  authority-derived reply contract of §Captain adjudication.
- **Marker-parse** (delegated-player alternative): a deterministic parser that
  scans the player output for a terminal control line such as
  `FSM-RESULT: { "guard": "...", ... }`. Useful when player adapters can
  be steered to emit structured trailers and the operator wants to avoid
  the extra LLM call.

The linker may select different strategies per delegated-player state; the
default is **LLM-judge for every state**. Direct-Captain states shall use the
LLM judge so their visible prose remains human-readable and carries no marker
or control JSON. Their adjudicator call uses purpose
`captain-output-adjudication` and remains hidden at the host adapter.

When the direct Captain result selects a terminal `response`, the exact
already-visible `CaptainResult.finalText` is the machine response and Boss
presentation. The linked
runtime shall not make a second visible Captain call or expose the hidden
structured adjudication merely to present the same response.

That visible-call presentation — visible Captain prose as the Boss
presentation, a separate hidden adjudicator that never authors the
`question`/`response` fields, and runtime injection of the visible
`finalText` — stays scoped to a working playbook whose FSM declares a visible
direct-Captain state. For a controller playbook, whose FSM declares the controller
decision-state class of [gears2fsm "Setup"](gears2fsm.md#setup), the
Captain-call presentation admits the hidden controller form instead
(DR-029): the decision and closing-reply Captain calls run
`{ visibility: 'hidden' }` on the host's durable conversation, whose resume
token the host pins and rotates (DR-029), and the decision call's reply
is the `{ action, … }` control JSON itself — validated by the linked runtime
against the declared decision-state contract rather than adjudicated through
a separate judge call, with exactly one corrective re-ask appending the
rejection reason and the restated reply contract (the DR-025 corrective
pattern). Because the host owns that conversation, the `resume` member the
runtime is required to pass on a controller call carries no continuity
meaning: the runtime passes `resume: false` because it holds no token, and
the host's pinned durable selection overrides it — a controller call shall
never be read as a request for a fresh conversation.

The validated selection is not itself an effect. The linked runtime shall
submit it through the host-supplied controller port the linker exposed as an
option member (§PlaybookRuntime contract) and shall take the returned
settlement as the only evidence of what happened. That settlement, carried
beside the selected action as the guard discriminant, is the decision
invocation's own result — the actor output the decision state's `onDone` arms
select on and its evidence action records — so the effect reports through the
same invocation that decided it, with no second boundary and no host-sent
event. A controller prose state (a parse-resolved `respond` reply, an acting
turn's closing reply) settles on its declared single outcome and returns no
prose to the machine at all.

That reply is control data, never Boss presentation: the runtime
shall not inject the `question` or `response` presentation fields into a
controller result — no visible Captain call exists to own them. Controller
prose reaches the Boss only as host-validated captain speech surfaced
through the host's presentation seam, cligent `CaptainContext.emitReply`
(DR-029). Because no prose returns to the machine and no presentation
field is injected, the host's own `callCaptain` implementation is that seam:
it already holds the `CaptainResult` of the call it just served, and it
identifies which call that is from the paired `captain.call.started` boundary
the runtime emits before invoking the port, whose identity carries the
invoking `stateId` and `sourceItem` (§Playbook trace). No prose therefore
needs a return path through the machine, and none exists.
The visible-call `question`/`response` injection rule above and
the `{ visibility: 'visible', resume: false }` workflow-call selection
(§PlaybookPorts contract, §Captain prompt composition) stay the
visible-presentation shape for non-controller playbooks.

The nongoverned player adjudicator and every direct-Captain adjudicator shall fail loudly on:

- A guard the state does not declare,
- A missing payload field the state's `result` description requires,
- An empty / malformed response.

These cases shall remain distinguishable in the thrown error: malformed JSON
recovery shall identify the missing JSON object, an unknown selection shall
identify an undeclared guard, and an incomplete selection shall identify the
missing required field. A generic “no declared guard selected” error for all
three cases is nonconformant.

Those adjudicator failures are control-plane errors.
The runtime shall propagate them by throwing out of `handleBossInput` after attempting cleanup.
The host adapter surfaces the throw on its control-plane channel (cligent surfaces such throws as `runtime_error` per [TMUX-025](https://github.com/sublang-ai/cligent/blob/main/specs/user/tmux-play.md#tmux-025)).
The host's player-result channels (`player_finished` and equivalents) are reserved for failures the player itself produced; the host emits them when `callPlayer` resolves with `status !== 'ok'`.
Direct-Captain host-result failures stay on the Captain actor boundary and
shall not be reported as player failures; they follow the recoverable FSM
failure path specified above. Captain transport, result-shape, trace-sink, and
adjudication failures remain control-plane errors unless the transport failure
is causally identical to the active abort signal.
Because XState still needs the invoked promise to settle, the linked runtime
shall latch a nongoverned delegated-player or direct-Captain adjudicator failure, actor-output JSON-validation, or nested-boundary
control error outside machine context, allow the invocation's `onError` path to
reach quiescence, drain all emissions, and then reject the public runtime
method with that original error. It shall not return such a failure as a
recoverable `{ outcome: 'failed' }` workflow result.
An artifact-schema-3 governed-player adjudicator shall instead use the bounded structural correction, authority reconciliation, and unresolved parking contract above.
The first latched non-abort control error takes precedence over a coincident
boundary-signal abort. Read and clear the latch only in the public boundary's
`finally` cleanup after XState and emissions have settled, so it cannot leak
into a later Boss turn or be erased before rejection.
An `AbortError`-named transport, validation, or trace-sink failure is still a
non-abort control error unless it is causally identical to the applicable
signal reason. Error names shall never change original-error or first-latch
precedence.
When a host port or structured-result validator fails after a call-start
boundary, latch that original error before attempting the required finish
trace. If the finish sink records the event and then rejects, do not emit a
second finish and do not let the sink failure replace the earlier control
error returned by the public boundary; retain the sink failure only as
independent cleanup evidence.

## Script execution

Where the FSM declares the typed `script` actor from
[gears2fsm "Setup"](gears2fsm.md#setup), a factory-backed linked runtime shall
provide its implementation through the shared factory (§Output); the linker
shall not regenerate a script executor inside a factory-backed emitted module.
A script invocation is the one actor kind that runs without any agent:
it makes no `callPlayer`, `callCaptain`, or `callJudge` call and needs no
adjudication.

The provided actor shall:

- Execute `input.command` verbatim through the platform's POSIX shell
  (`sh -c`), with the working directory taken from the emitted
  `PlaybookRuntimeOptions.cwd` when the caller supplies it, else the process
  working directory. The linker shall declare the optional `cwd` option on the
  emitted options interface whenever the FSM contains a script state; the
  validated option reaches the shared script actor through the spec.
- Resolve deterministically from the child's exit status: status zero resolves
  `{ guard: <first declared guard>, exitStatus: 0 }`; any nonzero status
  resolves the second declared guard with that status. Guard selection is
  mechanical; the runtime shall not route script output through the judge.
- Reject when the command cannot be spawned at all, routing through the
  state's ordinary `onError` path. Beyond spawn failure, the invocation
  rejects only per the abort bullet below or when one of its own script
  emissions rejects; a completed command's exit status itself never rejects.
- Honor the active turn's abort signal per §Abort: the actor shall reject
  without spawning when the combined signal is already aborted; shall run the
  shell detached as its own process-group leader; and on abort — whenever it
  lands before the invocation settles, including only after the shell's own
  exit — shall deliver
  `SIGTERM` to the entire group, escalate to `SIGKILL` after a bounded grace,
  and settle only after the shell process itself has exited and the group has
  stopped being signalable, confirmed by an `ESRCH` liveness probe, rejecting
  with the signal's reason. The same
  bounded grace caps the post-`SIGKILL` wait for kernel teardown, so an
  unreaped member outside the runtime's control cannot stall settlement. If
  the group remains signalable through that bound, or confirmation fails
  without `ESRCH`, the boundary rejects with a distinct teardown control error
  rather than reporting a clean abort over unconfirmed cleanup. The kill is
  always posted before the actor settles. Abort ownership — the
  listener and its escalation — spans the whole invocation, not the
  spawn-to-exit window
  ([DR-036](../specs/decisions/036-coherent-abort-settlement.md)). An abort
  observed only after the shell's exit shall additionally reject before guard
  resolution and before starting any script emission not already in flight; an
  emission already started when the abort lands completes through the
  ordinary serialized channel and the rejection follows it. A
  descendant that leaves the process group is beyond the runtime's kill
  scope.
- Emit, after the child settles and before the invocation resolves, one status
  line `Executed script for <stateId> (exit <status>).` and one telemetry
  event under topic `playbook.script` with payload
  `{ stateId, sourceItem, exitStatus }`, through the ordinary serialized
  emission channel.

Script execution emits no `*.call.*` trace pair: the surrounding FSM
transition trace and the `playbook.script` telemetry are its record, so trace
schema consumers see no new event types.
Script stdout and stderr are not workflow data: the runtime shall not place
them in machine context, prompts, or trace payloads.

## Nested playbook bridge

Where the FSM declares the typed `playbook` actor from
[gears2fsm](gears2fsm.md#nested-playbook-calls), the linked runtime shall provide
it with the shared `createNestedPlaybookBridge(...).actorLogic` — wired by the
shared factory per §Output — and shall not regenerate a second pending-call,
identity-validation, or abort-cleanup substrate inside each linked artifact.
Instantiate the generic bridge with the FSM-exported `PlaybookInput` type so
XState `.provide(...)` receives the exact declared actor input rather than a
structurally similar local type.
Construct one bridge per runtime and wire every integration hook: allocate ids
with `nextCallId`; return the currently active public-boundary signal from
`getBoundarySignal`; capture an immutable cancellation classifier for the
invocation's signal identities; compose `resumePlaybookCall.signal` into that
classifier through `bindResumeSignal`; pass the applicable classifier through
`emitStarted`, `emitFinished`, and `drain`; bind it to the root transition
caused by child settlement through `bindActorSettlement`; and pass it through
`onControlPlaneError` and `onBackgroundError`. Each receiving latch shall drop
only a failure the supplied classifier identifies as exact cancellation and
shall retain every distinct cleanup or observer failure for the owning public
boundary, the next drain, or disposal rejection as applicable. A stored
distinct failure shall never be reclassified against a later boundary. The
runtime shall not leave these optional API hooks unwired merely because their
TypeScript properties are optional for simpler bridge consumers.
On invocation the bridge allocates a runtime-local call id, traces the start,
and calls `PlaybookPorts.callPlaybook` with the composed target/text and the
bridge signal combined from the XState invocation lifetime, the active public
boundary, and the bridge's own disposal controller.

For a literal invocation, target and text retain their existing static/composed
values. For a dynamic invocation, the bridge shall use the evaluated
`PlaybookInput.playbookId` and `PlaybookInput.text` values, require both to be
strings with non-empty target and text, and preserve the exact resolved values in the
request and trace. The linker shall preserve the FSM's static
`playbookIdContext` and `textContext` metadata for conformance; it shall not
parse function source, treat either metadata name as the runtime value, or
freeze a dynamic call to the value observed during artifact inspection.

If the port returns `state: 'settled'`, the bridge validates the result,
emits and drains `playbook.call.finished`, then resolves successful output or
rejects an aborted/error result.
If the port returns `state: 'suspended'`, the bridge records one pending call
and awaits a runtime-owned deferred result.
Only after that pending record exists may the drive boundary treat the call
state's `playbook.suspended` tag as quiescent.
One runtime supports at most one pending child call; a second shall reject.
The pending record shall also retain the call-start `turnId`. A resumed finish
and every parent transition, Captain reassessment, and status caused by that
return shall use this retained id, not an absent or newly allocated
current-turn value. The finish callback shall receive or close over that stored
id rather than read a mutable global turn id at resume time.
The bridge shall strictly validate the start discriminant, non-empty suspended
child session id, settled target identity, optional state descriptor,
normalized error, and JSON-safe output. A malformed start, malformed result,
identity mismatch, or non-JSON value is a control-plane error. Once a start
trace exists, every thrown port, validation failure, immediate result,
suspension resume, invocation abort, and disposal path shall emit and drain
exactly one matching finish trace; malformed data shall neither create a
pending identity nor be reassessed as ordinary child evidence.
The bridge shall detach and recursively freeze a validated start/result before
tracing it or delivering it to the FSM, so caller mutation after port
resolution cannot alter identity, evidence, or trace payloads. A non-abort
`callPlaybook` throw/rejection is a control-plane failure: pair its finish,
latch and rethrow the original error, and take the FSM fallback error path. A
rejection caused by the combined abort signal remains an authored `aborted`
child result.
The optional output field may be absent from an otherwise valid successful
child result. Generated event and trace descriptors shall omit an absent or
`undefined` output instead of attempting to snapshot it as a JSON value.
When cancellation wins while the host's opening promise is still pending, the
shared bridge shall retain and drain that exact promise before emitting the
matching finish boundary. It shall ignore an abort-reason rejection from that
opening promise, surface any other late rejection as a control-plane cleanup
failure, and recover a child session identity from a late resolved start when
available. Generated runtimes shall pass the host port directly to the shared
bridge rather than recreate this opening-promise drainage locally.
In particular, aborting a public turn during that opening promise shall abort
the combined bridge signal, wait for opening cleanup and the paired finish,
let the promise actor reach its `onError` quiescent state, and only then return
an aborted run result. It shall neither hang waiting for a child-resume path
that was never registered nor return while the opening promise or finish
emission remains live.
The pending record shall retain a one-shot invocation-signal listener. If the
call state is stopped, that listener shall settle and clear the deferred call
as an aborted `NestedPlaybookCallError`, drain the matching finish boundary after
host abort cleanup, and make a later nested invocation possible; it shall not
leave a permanently pending record merely because XState stopped observing the
promise actor.

`resumePlaybookCall` shall accept only the matching pending call id, target
playbook id, and child session id; bind its new turn signal for work resumed in
the parent; emit and drain the call-finish trace; settle the bridge deferred;
and use XState `waitFor` to drive the parent to its next
quiescent, suspended, failed, aborted, or terminal result.
An `ok` result whose `terminal.kind` is `success`, and an `ok` result carrying
no `terminal` record at all, resolve the actor and reach `invoke.onDone`;
`aborted` and `error` results, and an `ok` result whose `terminal.kind` is
`failure`, reject it and reach `invoke.onError`.
The rejection shall be an `Error` whose public readonly `result` property is
the exact normalized `PlaybookCallResult`; throwing the result object directly
or discarding its status prevents the FSM from distinguishing abort from
failure during recovery.
A completed child's `ok` result carries `terminal` exactly when the child's
artifact declares its reached final state's kind: the runtime reads
`meta.playbook.terminal` and that state's authored description from the
artifact, never from an agent reply, and a declared value other than `success`
or `failure` is a control-plane error rather than a child outcome.
`onDone` proves successful bridge delivery without a declared child failure;
it does not establish every caller-owned domain condition. The caller shall
enforce its own explicit Source-authored acceptance or relay predicates on
the delivered output before continuing, without inventing predicates from
callee implementation details or overriding the child's compiled terminal
kind with output fields.
Unknown, duplicate, or stale call ids reject without changing actor state.
The finish trace shall therefore precede any parent FSM transition caused by
the child return.
The host independently validates every evaluated target against its enabled
registry; linker-time metadata is not authorization to call a target.

Disposal shall settle an outstanding call as aborted and drain its finish
trace before `session.disposed`.
If registered child abort cleanup rejects with a failure distinct from every
applicable abort reason, the bridge shall emit the paired finish with an error
result and reject `abortPending` or disposal with that original cleanup error,
or with an aggregate containing every distinct failure when more than one
remains;
an exact abort-reason rejection is cancellation evidence and shall not be
retained as a control failure. Parent disposal shall still drain, emit its one
`session.disposed` boundary, and clear the bound session before rejecting with
any preserved distinct cleanup error.
Child output and errors must be JSON-safe; a non-JSON-safe result is a
control-plane error.

## Session lifecycle

The `PlaybookRuntime` shall:

- Reject use before `init`, a second active turn or resume, and re-initializing
  a live session. `handleBossInput` and `resumePlaybookCall` share one active
  turn sentinel; neither may overlap the other, and disposal shall not race a
  live boundary. A dispose request made during an active public boundary shall
  reject without beginning teardown. Idle concurrent dispose requests shall
  share one disposal promise; later calls after disposal shall return that
  settled disposal outcome without emitting another boundary. Once disposal
  begins, no new turn or resume may start.
  Disposal requested during initialization shall retain one teardown promise,
  wait for initialization's success or failure cleanup, and emit at most one
  `session.disposed` boundary. Disposal before initialization is terminal and
  coalesced: later initialization rejects and every later disposal call
  returns the first retained promise.
  Represent in-flight initialization with a cleanup-complete latch resolved by
  `init`'s outer `finally`, after either successful startup or the complete
  failed-start cleanup. Do not expose the fallible inner startup promise as
  that latch: it rejects before the outer cleanup and lets concurrent disposal
  race the cleanup's own `session.disposed` attempt.
  Put session validation and snapshotting, bridge/actor construction, initial
  state reads, and startup emissions inside that guarded outer `try`; none may
  throw before the cleanup-complete latch's `finally` can resolve. A rejected
  session identity must not leave later disposal waiting forever.
  The generated `dispose` method shall not be declared `async`, because an
  async wrapper returns a distinct promise and breaks identity coalescing; it
  shall return the retained teardown promise directly and use
  `Promise.reject(...)` for precondition failures.

- In `init`, bind the immutable `PlaybookSession`, emit
  `session.started` with the initial normalized state descriptor, and
  construct the XState actor with FSM `input` derived
  from `options`. The actor is session-scoped, not turn-scoped. Use XState v5's
  public actor inspection `@xstate.snapshot` event for the root actor so each
  transition's triggering event and snapshot can be surfaced via `emitStatus`
  and `emitTelemetry` before the next event fires; do not consult private actor
  nodes or infer the event later from context. Filter inspection events by
  `inspectionEvent.actorRef === rootActor`, not merely by the actor-system root
  id, so promise-child snapshots are not emitted as root FSM transitions. The
  inspection callback shall only validate and synchronously enqueue emission
  work, catching validation/enqueue failures into the control/background-error
  latch; it shall not let an exception escape or call an async port directly.
  Its transition `event` field shall be a detached JSON-safe descriptor, never
  the raw XState inspection event. Preserve the string `type` (or use
  `unknown` when absent); copy only declared Boss-union payload fields and a
  validated actor `output`, and normalize an `error` member before inclusion.
  Omit `input`, `actorId`, system/ref data, and every other XState-internal
  field even when it happens to be JSON-safe, so `xstate.init.input` cannot
  leak the host catalog into transition telemetry. In particular, do not call
  `snapshotJsonValue(event)` on an `xstate.error.actor.*` event that contains a
  raw `Error`.
  Construct the actor without starting it, read its public initial snapshot,
  emit and drain `session.started`, and only then call `actor.start()`. The
  initial inspection-driven transition/status emissions shall not precede the
  session-start trace. Have any actor-construction helper return the actor and
  assign it at the call site; TypeScript does not narrow a captured optional
  actor variable from assignment hidden inside a helper. Retain a non-optional
  local actor reference across terminal reconstruction and event sending.
  An actor-construction helper may read the already-bound immutable session
  directly for machine input such as `session.playbookId`, but it shall not
  call a lifecycle assertion that also requires the actor to exist. The actor
  does not exist until that helper returns, so coupling session access to actor
  availability makes every valid `init` fail before construction completes.
  Generated code shall pass the repository's full strict `tsc` build with no
  unused helper or destructured parameter, not only a transpile-only or
  target-local syntax check.
  For the default Captain runtime, the initial quiescent `ready` snapshot may
  emit the ordinary structured transition trace and telemetry, but it is not a
  Boss-relevant transition and shall emit no human status. Any initial
  transition-trace or telemetry sink failure is part of `init`: initialization
  shall reject, stop the actor, and perform the failed-start cleanup below
  rather than swallowing it as a later background error.
  A root-actor error observed during startup — an initial entry action or a
  synchronously failing initial invocation — is equally part of `init` and
  `restore`: the boundary shall reject with that original error after the
  failed-start cleanup, and shall never resolve leaving the errored actor as
  later background state
  ([DR-036](../specs/decisions/036-coherent-abort-settlement.md)).
  Where the FSM input declares `selfPlaybookId`, seed it from the immutable
  `session.playbookId`; do not expose a caller option or reuse a working leaf's
  `stateId` as the self-call identity.
- If initialization fails after attempting `session.started`, stop the actor,
  abort/drain nested and host work, and make one best-effort
  `session.disposed` attempt before clearing the bound session. Preserve the
  original initialization error if cleanup or disposal emission also fails.
  Suppress root inspection emissions before stopping the failed actor because
  XState emits a stop snapshot; that teardown snapshot shall not retry a
  transition/status sink that already failed initialization. Reset the
  inspection gate, queues, error latches, prior state, and all per-session
  sequence counters so a permitted retry starts with trace sequence `1`.
- Per `handleBossInput`:
  1. Allocate a runtime-local turn id and trace the exact Boss text.
  2. Map `turn.text` through the Boss-event mapping, using deterministic exact
     entry where applicable and classification otherwise.
     If mapping produces no event, return after draining any port emissions.
     If the classifier port rejects, emit and drain the Boss-settled error
     boundary, send no event, leave the actor unchanged (including a terminal
     actor), and reject the original error. If that rejection is caused by the
     active Boss abort signal, return and trace the same structured `aborted`
     result instead of tracing `no-action`. If the port resolves but its reply
     cannot be recovered or validated, emit the one recovery status required
     by §Boss-event mapping, send no event, leave the actor unchanged, and
     return `no-action` after the ordinary settled boundary drains.
  3. Only after classification produces a valid initial entry event, if the actor is in a
     `final` state, dispose and reconstruct it — `final` is terminal and cannot
     accept new events. `NO_ACTION`, classifier rejection, invalid initial guards, and malformed
     classification shall leave a terminal actor untouched.
  4. Bind the active public-boundary signal and send the classified event to
     the actor.
  5. **Drive to quiescence**: provide each invoked actor according to its
     declared kind. For `player`, build a player prompt, call `callPlayer`,
     adjudicate, and resolve the invoke. For `captain`, build a direct Captain
     prompt, call `callCaptain` visibly, adjudicate through the shared hidden
     judge path, and resolve the invoke. For `playbook`, use §Nested playbook
     bridge. For `script`, use §Script execution — no port call and no
     adjudication. Parallel regions may run distinct resolved players independently;
     Captain and judge work remains serialized by the shared host queue. Use
     XState `waitFor` over public tags/status until no `playbook.busy` state is
     active, a registered child call is suspended, or the actor is
     terminal/error. Pass `pendingCalls: nestedBridge` so a suspended tag is
     quiescent only after its child identity exists. Under natural rejection,
     do not pass the already-aborted public turn signal as wait cancellation:
     it has already been combined into the invoked boundary, and the runtime
     must now wait for XState's `onError` transition and quiescence.
  6. Return a structured `PlaybookRunResult` after all in-flight calls and
     ordered emissions caused by the turn drain.
- Per `resumePlaybookCall`, follow §Nested playbook bridge and return the same
  structured run-result boundary without classifying new Boss text. Drain the
  transition/status/telemetry queue before returning, just as
  `handleBossInput` does. A resume shall not allocate a new Boss-input
  `turnId`; retain the original call-start turn id for its matching finish and
  for the parent continuation caused by that return.
  A resume whose signal is already aborted after identity and result
  validation shall deliver nothing: bind no resume signal, settle no deferred,
  emit no call finish, and preserve the pending call — the boundary settles
  `{ outcome: 'aborted' }` with the signal's reason while the suspended state
  and pending identity survive, so a later resume with the same call id and a
  fresh signal still delivers
  ([DR-036](../specs/decisions/036-coherent-abort-settlement.md)). Every success and
  exceptional path shall drain ordered emissions, select the first latched
  non-abort control error before considering abort, and clear its boundary
  latches in `finally`, so a failed resume cannot leak an emission error into a
  later turn.
  A resume is not a Boss-input turn and shall emit neither
  `boss.input.received` nor `boss.input.settled`; the structured result is the
  method return. Reusing the originating turn id on the child finish and
  continuation emissions does not create a second Boss trace pair.
  This quiescence and drain path is mandatory even when
  `nestedBridge.resume(...)` rejects: capture that operation error, allow the
  promise actor's `onError` transition to settle, and select the first latched
  control error only after all ordered emissions have drained.
- In `dispose`, capture the final public state and stop the root actor before
  settling or aborting a suspended nested bridge, so the bridge rejection
  cannot reenter the FSM and start new actor work during disposal. Then drain
  pending port emissions and every in-flight Captain/player/judge/child opening, emit
  `session.disposed` with the final descriptor, and discard player resume
  tokens. Host child abort cleanup and child `session.disposed` shall drain
  before the parent call finish, which shall drain before parent
  `session.disposed`. Use cleanup/finally structure so a bridge or emission
  failure cannot skip the parent disposal boundary or leave the runtime bound.

The actor's `lastError` field shall be surfaced via `emitStatus` when the machine enters its `failed` state.
Presence of linker-emitted `roleStates` selects the canonical factory-backed status profile.
That profile shall emit the selected Boss event type
before sending that event; exactly `→ <acceptedOutcome>` (with no payload-count or tally
rider) only from a confirmed accepted-outcome marker; and
`⤷ <Role>: <label>` only when the entered state appears in the linked module's `roleStates` metadata.
It shall emit no raw state-id fallback for any other state.
`roleStates` shall be a complete map of the FSM states
that invoke the typed `player` actor; each value carries the exact
local role from that state's source-derived `meta.playbook.role` and the state's exact FSM description as `{ role, label }`.
The factory shall reject an
incomplete entry, a non-player state, or a role or label that differs from the FSM metadata.
Artifact schema `1` and a missing compatibility declaration
shall reject before interpretation because their legacy `player` values may
encode bindings or aliases rather than canonical local roles.
For artifact schema `3`, an accepted-outcome marker is a root-machine XState action with exact type `playbook.acceptedOutcome` and exact plain-data params `{ source, target, acceptedOutcome }` naming a declared governed outcome.
The runtime shall observe that action only through the public root `@xstate.action` inspection event, retain it privately until the corresponding next public root `@xstate.snapshot` confirms `source` active in the prior snapshot and `target` active in the new snapshot, then emit one trace-schema-4 `outcome.accepted` event with those exact params before its canonical status and before public settlement; markers confirmed together shall retain their XState execution order.
A valid unmarked transition, including an unexecuted guarded arm or rejected-guard fallback, shall settle normally with neither accepted-outcome evidence nor claimed-outcome status.
An executed marker that is malformed, undeclared, or unconfirmed by those adjacent snapshots, or a batch that instruments one governed source more than once regardless of target or outcome, shall clear the entire pending marker batch and fail the current public boundary after retaining the ordinary transitioned state but before settlement, accepted-outcome evidence, or claimed-outcome status.
For the default Captain runtime, an initial `ready` state and a terminal `done`
state shall not emit human status. The terminal response is already visible
Captain prose; a synthetic “entered done” message would present it twice.
Structured transition trace and telemetry still apply to both states.
Every provided actor boundary shall first drain the queued state-entry
transition/status/telemetry caused by entering its working leaf, so a call's
`*.started` trace cannot overtake the transition that explains it. Every public
runtime method shall drain that queue before it resolves or rejects.
This initial `await drain()` is required inside each provided `fromPromise`
body: XState may begin that body before publishing the root snapshot, and the
await yields so the synchronous inspection callback can enqueue the entering
transition first.

If a `*.call.started` trace records and then its sink rejects, no host call may
begin. The runtime shall still enqueue exactly one synthetic paired
`*.call.finished` trace — with `status: 'error'`, or `status: 'aborted'` when
the sink rejection is causally identical to the applicable signal reason, in
which case nothing is latched and the turn follows abort settlement
([DR-036](../specs/decisions/036-coherent-abort-settlement.md)) — preserving
the original call
id, turn id, actor visibility, state/source identity, and prompt or request
metadata from the start boundary. A distinct rejection shall then follow the
same latched
control-error, FSM settlement, and ordered-drain path as any other call-start
failure; the synthetic finish must not replace the original sink error.

## Parked-session snapshot (optional)

A linked runtime may implement the optional durable-session capability of
`@sublang/playbook/runtime` — `exportSnapshot()` and
`restore(session, snapshot)` — so a host can persist a parked session and
rehydrate it in a later process (DR-014). A runtime that implements either
member shall implement both. When generated for a runtime whose host needs
durability, the pair shall behave as follows.

A shared runtime may also receive the internal step-start snapshot for its current invocation or `exportSnapshot({child})` for a bridge-owned child during startup; these capture stopped positions without execution.
Ordinary `exportSnapshot()` shall return `undefined` unless the runtime is at a safe
capture point: initialized, not disposing or disposed, no active
`handleBossInput`/`resumePlaybookCall` boundary, and the root actor at a
quiescent state with actor status `active`.
At a safe capture point it shall return a JSON-safe
`PlaybookRuntimeSnapshot` carrying:

- `schemaVersion`: literal `4`.
- `playbookId`: the bound session's playbook id.
- `machine`: the root actor's `getPersistedSnapshot()` result, passed
  through the shared JSON detachment with any raw `Error` context value
  (for example FSM `lastError`) normalized to `{ name, message, stack? }`
  first. The value is opaque to hosts.
- `effectLedger`: the detached immutable schema-version-1 mirror most recently
  acknowledged by the current host's atomic ledger channel; a linked workflow
  runtime carries the complete current-host mirror, while the internal compiled
  Captain runtime carries the exact empty ledger.
- `roleResumeTokens`: the local-role resume-token projection as a plain object
  (§PlaybookPorts contract).
- `sequences`: the live `trace`, `turn`, `judgeCall`, `playerCall`, and
  `playbookCall` counters, plus `captainCall` when the runtime supports direct
  Captain calls.
  A direct-Captain-capable runtime shall persist it in every schema-version-4 export.
- `state`: the current normalized state descriptor.
- `pendingBossQuestions`: the pending Boss question(s) from FSM context as
  a list of `{ questionId, asker, question, sourceItem? }`, where `asker` is
  `{ kind: 'captain' }` or `{ kind: 'role', roleId }`, empty when the
  parked state awaits no reply. This list exists so hosts can surface the
  question without parsing status lines or telemetry.
- `bossExchanges`: omitted when the run has heard no Boss reply; otherwise
  every `{ question, reply }` exchange of the run so far, in order, which
  `restore` and adoption take back.
- `suspendedCall`: omitted when no nested call is pending; otherwise the
  shared nested bridge's complete `callId`, source `stateId`, target
  `playbookId`, exact handed-off `text`, and `childSessionId`, enriched with
  the call-to-turn map's optional `turnId`.

A pending nested call is exportable only when the bridge's pending identity
and complete descriptor agree and the call-to-turn map owns that exact call
id, including ownership whose value is absent. A bridge descriptor that
already carries a turn id shall equal that map value. Any missing or
inconsistent bridge, descriptor, or turn-ownership record makes the capture
unsafe and returns `undefined`.

`restore(session, snapshot)` is an alternative to `init` under the same
lifecycle guards (§Session lifecycle): it shall reject when already
initialized, disposing, or disposed, and shall validate
schema version `4`, the complete effect-ledger mirror, and that `snapshot.playbookId` equals `session.playbookId` before touching state.
Runtime snapshot schemas `1` and `2` shall reject before state binding because their token and pending-question fields conflate local roles, concrete players, and Captain identity; schema `3` shall reject because it cannot prove an effect ledger.
The host supplies the same immutable `PlaybookSession` identity the
snapshot was exported under and recreates the runtime through the same
factory with equivalent options; the runtime does not diff options, and
module identity — that the factory constructing this runtime still
belongs to the snapshot's playbook — is likewise the host's check to
make before calling `restore`.
Before actor or source-state restoration, a linked workflow runtime shall require
the snapshot ledger to equal the detached synchronous mirror exposed by its
current-host capability; the internal Captain runtime shall require its mirror
to be empty.
`restore` shall bind the session and its current detached role bindings, restore the local-role token projection, the
sequence counters, and the
prior-state descriptor from the snapshot,
prepare the shared nested bridge with the suspended-call descriptor or its
explicit absence, restore a descriptor's call-to-turn map entry, construct
the actor with the persisted `machine` snapshot, and start it
with root inspection emissions suppressed so rehydration emits no
`session.started` trace, no transition trace, and no human status — the
session already started, and the next public boundary continues the
contiguous trace sequence. After start, the runtime shall normalize the
actual actor state with the prepared suspended call as its pending identity
and require it to equal the detached persisted state exactly, including
active status. It shall drain suppressed startup work and invoke the bridge's
`confirmRestore` as the final fallible restore step, publishing the pending
identity only after every other validation succeeds. A missing, extra, or
mismatched reconstructed invocation, an actual/persisted state mismatch, or
any other failed validation shall fail `restore` through the same
failed-start cleanup path as `init`, rolling back provisional bridge and turn
ownership without a child-host call or duplicate start/finish boundary.
A restore failure shall leave the runtime unbound so `dispose` remains
callable and terminal.

## Retained-snapshot adoption (optional)

A linked runtime may implement the optional adoption capability of
`@sublang/playbook/runtime` — `adopt(session, snapshot, context)` — as a third
initialization path distinct from `init` and same-engagement `restore`.
Adoption may bind a retained generation to a fresh valid `PlaybookSession`
identity. Every runtime the shared `createXStatePlaybookRuntime` factory
constructs for a flat machine implements `adopt`, regardless of whether the
artifact supplies retained-generation classification metadata; one it
constructs for a machine that declares a parallel state omits it, as linked
machinery of an artifact's own may, and hosts feature-detect the capability
by member presence.

Before actor construction or any player-session-store, port, trace, status,
or telemetry effect, `adopt` shall validate and detach the target session, the
snapshot, and an exact closed-schema `PlaybookAdoptionContext` whose nonempty
`sourceSessionId` names the retained frame's source runtime session, whose
nonempty `sourceGenerationId` names the retained stack root's source
`rootSessionId`, and whose optional nonempty `targetChildSessionId` is present
exactly when the snapshot carries a suspended call. The source session and
generation ids shall coincide exactly for a root frame. The target session and
root ids shall each differ from their source counterparts, and a supplied
target child id shall differ from every source and target identity visible to
that frame. Accessors, unknown or missing members, empty identities, and an
inconsistent child mapping shall reject during preflight.

That preflight shall also validate the part of the exact structural envelope
visible to the runtime: snapshot schema version `4`, target playbook id, the
factory's already-validated artifact contract, and any supplied local-role
binding set against the artifact's declared roles. The adopting host
owns the working-directory and complete catalog-entry comparison — registry
module identity, manifest command, options, and role set — plus every retained
frame's artifact-schema comparison, and shall perform them before calling the
runtime capability (DR-038 §3).
The preflight shall apply the same exact full-mirror rule as restore: a linked
workflow target receives a current-host mirror equal to the retained ledger,
while the internal Captain target requires the retained ledger to be empty.

Adoption shall not restore any source counter. The fresh target trace, turn,
judge-call, player-call, supported direct-Captain-call, playbook-call, and
apply-call counter spaces shall start at zero. Before its session-start trace,
a descriptor-free adoption leaves the playbook-call counter at zero. A
suspended adoption instead consumes `playbook-1` as the fresh target call id,
replaces the descriptor's source child id with `targetChildSessionId`, omits the
source `turnId`, and sets the target playbook-call counter to one; it changes no
opaque persisted machine value and makes no child-host call.

After preflight, adoption shall construct the persisted actor and prepare the
nested bridge through the same transaction as restore, using the rebased
descriptor or an explicit absence. Before actor startup it shall emit exactly
one `session.started` as target trace sequence `1`, carrying the adopted
top-level `state` and optional `stateId` plus an exact `adoption` object:

- without a suspended call, `{ sourceSessionId, sourceGenerationId }`;
- with a suspended call, `{ sourceSessionId, sourceGenerationId,
  sourceCallId, sourceChildSessionId, targetCallId: 'playbook-1',
  targetChildSessionId }`, while the event also carries top-level
  `callId: 'playbook-1'` and no `turnId`.

The runtime shall then start the actor with inspection effects suppressed,
claim the rebased descriptor, require the reconstructed active normalized
state to equal the retained state under that rebase, drain suppressed work,
and confirm the bridge as the final fallible step. A preflight mismatch emits
nothing. A later state or bridge mismatch makes no child-host call or
playbook-call start/finish boundary, rolls provisional ownership back, and,
because the target start was attempted, performs failed-start cleanup with one
best-effort target `session.disposed`; successful cleanup leaves the runtime
reusable. A successful adoption shall close `init`, `restore`, and `adopt`
under the ordinary one-start runtime lifecycle. Its immediate export shall
carry trace sequence `1`, zero fresh turn, judge, and player counters, zero
direct-Captain counter when supported, and playbook-call sequence zero or one
according to the suspended shape. Later target turns and calls allocate from
those fresh counters rather than continue any source id or sequence. Ordinary
same-engagement restore remains trace-silent and preserves its source
identities and counters exactly (DR-038 §5).

Adoption shall not apply the retained snapshot's `roleResumeTokens` through a
supplied player-session store's `restore` operation or seed runtime-private
continuation from them. For every later local-role invocation, any target
session `roleBindings` are the sole source of supplied player and prompt
identities, and any supplied player-session store is the sole conversation
authority. The runtime shall resolve the current binding and, when a store is
supplied, select it at the invocation boundary and pass the exact selected
token or `false`. Where
the ordinary continuation rules authorize a store mutation, that mutation
shall target the same store. It shall never fall back to the retained token
projection. A replacement binding whose current selection is `false` therefore
starts fresh under its new identities; without a supplied store, the target
runtime's private continuation starts empty (DR-038 §4).

## Retained-generation classification (optional)

A linked runtime may expose the optional read-only
`retainedGenerationMetadata` marker of `@sublang/playbook/runtime` together
with the parked-session snapshot pair and the independently feature-detected
adoption capability so a Captain can retain its safe pre-terminal generations.
Its `unfinishedFinalStateIds` array shall preserve the artifact's link-time
declaration exactly, including an explicitly empty set, and shall be immutable
and detached from that declaration. Absence means the runtime contributes no
retained generation; presence supplies only terminal classification metadata
and does not itself supply the adoption operation.
Every runtime the shared `createXStatePlaybookRuntime` factory constructs from
a supplied `unfinishedFinalStateIds` spec member shall expose the marker;
linked machinery of an artifact's own opts into classification only by
implementing the public member itself.

## Control surface (optional)

A linked runtime may implement the optional control-surface capability of
`@sublang/playbook/runtime` — `describe()` and `apply(...)` — so a host can
observe the parked machine and execute a runtime-advertised recovery or jump
action without fabricating an FSM event (DR-029). A runtime that
implements either member shall implement both; every runtime the shared
`createXStatePlaybookRuntime` factory constructs implements the pair. A
runtime lacking the pair advertises no actions, and plain text delivery is
the only verb against it. Presence is feature-detected like the
parked-session snapshot capability; the pair changes no runtime ABI and no
artifact or snapshot schema.

```typescript
type PlaybookControlStanding = 'ready' | 'no-op' | 'blocked';
type PlaybookControlActionReason = 'receipt-complete';

interface PlaybookControlAction {
  id: string;      // stable within the returned view
  label: string;   // runtime-written, Boss-appropriate
  standing?: PlaybookControlStanding;     // what running it would do (DR-063);
                                          // absent reads as `ready`
  reason?: PlaybookControlActionReason;   // why it is not `ready`
}

interface PlaybookRecoveryOffer {
  prompt: string;
  description?: string;
  preparation?: string;
  evidence?: JsonValue;
  continuation: { kind: 'reply' } | { kind: 'runtime'; actionId: string };
}

interface PlaybookControlView {
  state: PlaybookState;
  stateDescription?: string;  // runtime-published meaning of the current state
  context?: JsonValue;   // the runtime's authored projection, sanitized
  pendingQuestions: readonly PlaybookPendingBossQuestion[];
  lastError?: NormalizedError;
  actions: readonly PlaybookControlAction[];
  recovery?: PlaybookRecoveryOffer;
}

type PlaybookControlReceipt =
  | { disposition: 'rejected'; reason: string }          // before any effect
  | { disposition: 'executed'; run: PlaybookRunResult }
  | { disposition: 'failed'; error: NormalizedError; run?: PlaybookRunResult };   // effects may exist

// Optional PlaybookRuntime members — both or neither:
describe?(): PlaybookControlView;
apply?(input: { actionId: string; key: string; signal: AbortSignal }): Promise<PlaybookControlReceipt>;

// Independent optional host-only unresolved-envelope identity seam:
unresolvedEffectEnvelopes?(): readonly (
  | { readonly kind: 'boundary'; readonly boundaryId: string }
  | { readonly kind: 'logical-operation'; readonly operationId: string }
)[];
```

`describe()` shall be side-effect free — it emits no trace, status, or
telemetry and moves no machine state — and is valid at parked quiescence
outside an active `handleBossInput`/`resumePlaybookCall`/`apply` boundary;
during an active boundary, before `init`, or after disposal begins it shall
throw. The view carries the current normalized state descriptor, the state
description defined below, the authored context projection defined below, the
pending Boss questions with their stable ids, the last recorded error in
normalized form, and the currently valid actions.
The shared runtime owns the optional recovery context and invocation checkpoint; linked artifacts need no recovery-specific source, event, or actor.

`stateDescription` is the runtime's own Boss-facing statement of what its
current state means, taken from the same source state descriptions the action
labels below are written from. A controller host has no other grounding for a
status answer, and an internal state id is not text a reply may repeat, so the
runtime publishes the meaning rather than leaving the host to substitute the
identifier for it. A state whose source declares no description carries no
`stateDescription`: an id is never promoted into a description, so a host is
never handed an identifier dressed as meaning.

At that same safe control-capture point, a schema-3 runtime that retains
effect-possible outcome-unresolved work may expose
`unresolvedEffectEnvelopes()` so its host can project the authoritative effect
ledger. The method shall return only exact nonblank durable boundary or
logical-operation identities in envelope order, shall return an empty list
when no unresolved envelope remains, and shall expose no receipt, repository
observation, semantic evidence, prose, or live authority. It is side-effect
free on the same terms as `describe()`, and no returned identity or bounded
repository evidence shall enter `PlaybookRunResult`.

The view's `context` is an explicit projection the linked runtime **authors**,
never an allow-by-default serialization of the FSM context (PBRT-52).
Only the runtime knows which of its context members are safe and relevant
for a controller prompt, while the host receiving the view cannot inspect an
opaque blob for the player rosters, option values, and raw player output its
own prompts must exclude; exporting by default makes the two obligations
unsatisfiable together and gives every member added to an FSM later the wrong
default. The rules:

- The emitted module declares the projection in its `spec` as
  `controlContextFields` — the FSM context member names its view exposes, in
  the order it names them — and the factory exports those and nothing else.
- A runtime naming no member carries no `context` at all, so a member is
  private until an artifact names it and extending an FSM leaks nothing by
  omission.
- Sanitization sits on top of the projection, not in place of it: a named
  member is still normalized (raw `Error` values normalized) and dropped when
  it cannot be made JSON-safe, rather than thrown, since `describe` stays
  side-effect free and total.
- The two members the view surfaces first-class — the pending Boss question
  and the last error — cannot be named. A projection naming either is a
  construction error, failing runtime construction rather than being silently
  ignored.
- The host still composes its own prompt block from the projection rather than
  pasting the projection in, so no runtime's exported value can forge a block
  into an envelope the host owns.

Actions derive from the live snapshot, only at the same safe point the
parked-session snapshot uses (actor status `active`, quiescent, no pending
nested call); anywhere else `actions` is empty while the rest of the view
still describes the state.
While effect-possible outcome evidence remains unresolved, the view shall omit its pending Boss questions and state description and shall replace every ordinary action with exactly `reconcile:unresolved-effect` labeled `Retry unresolved effect reconciliation` and `abandon:unresolved-effect` labeled `Abandon unresolved workflow attempt`.
A valid invocation checkpoint is the only source of a retry: it retries only the stopped invocation after its effect checks, using `retry:<EVENT_TYPE>` for the same entry target or `retry:step` otherwise.
Saved-result assessment (`retry:adjudication`) never repeats the player and is not offered for an output the machine has already received (checkpoint `delivered: true`), and verified read-only restoration (`retry:restored-step`) records an exact baseline check before replay.
These retries have standing `ready`; an unsafe checkpoint grants no replay. Saved-result assessment withholds ordinary state jumps. Reconciliation and abandonment remain available whenever effects are unresolved, even alongside an eligible assessment or restoration.
Ordinary retry and jump actions use source state descriptions and require assessment and unresolved-effect fences to be absent:

- **Failure-state retry** — a valid invocation checkpoint retries that step only; a completed saved result is consumed without executing the operation again. No checkpoint means no retry. Legacy `entryEvent.contextField` metadata is ignored.
- **Jump entries** — for each registered resumable state id whose
  explicit-state-jump event (`BOSS_INTERRUPT` with that `targetId`, optional
  textual fields omitted) the live snapshot accepts, guards included, the
  runtime shall advertise `jump:<stateId>`, except that a jump out of a governed
  failure must also pass the full failed-attempt effect check above.

A candidate whose event requires a payload the runtime cannot source from
recorded state shall be excluded from `actions` — `apply` never invents free
text and never enters Boss-input classification. A candidate whose *label*
could only be an identifier is excluded on the same terms: a label never falls
back to a target id or to the replayed event type, because a controller host
names an executed or refused action by its label and never by its id, so an
identifier used as a label defeats that substitution. A jump whose target
publishes no description is therefore not advertised — borrowing another
state's description would name the wrong state — and a retry requires the
interrupted invocation's source description.

`apply({ actionId, key, signal })` shall revalidate the action against the
live state and settle `{ disposition: 'rejected', reason }` with no effect
when it is no longer advertised. It shall execute an accepted action at most
once per idempotency `key`: the receipt is recorded at acceptance, before
the settlement emissions, and a repeated key returns the recorded receipt
verbatim with no revalidation, no execution, and no new trace pair within the
runtime instance.
Only accepted receipts (`executed` or `failed`) are recorded and final for
their key. A rejection settles before acceptance and records nothing under
its key — a later call with that key revalidates afresh, traces its own
pair, and may execute once the action is advertised — and a key whose call
threw before reaching acceptance (lifecycle misuse, invalid input, a
pre-acceptance abort, a rejected start-boundary sink) likewise records
nothing, so a later call with that key may execute.
Executing a jump sends the validated event through the same actor drive as `handleBossInput` — state
transitions, player/judge boundaries, statuses, and traces flow unchanged —
and settles `executed` with the projected run result, or `failed` with the
normalized error when the run settles in the failure state, aborts, or a
post-acceptance control-plane error lands (effects may exist). `signal`
follows §Abort exactly as a Boss-turn signal does; an abort after acceptance
settles the `failed` receipt rather than rejecting. The boundary traces as
the paired `apply.started` / `apply.finished` events of §Playbook trace, and
`apply` shares the single active-boundary sentinel with `handleBossInput`
and `resumePlaybookCall`.

Executing `reconcile:unresolved-effect` shall use only the current host's authoritative effect ledger for any reconciliation refresh and shall start no player.
When an open deferred logical operation is checkpoint-restoration eligible, that action shall reacquire its exclusive repository claim and compare the current observation with the saved checkpoint; exact equality shall durably consume eligibility and return to the identical bound wait with its stable question through an ordinary nonterminal run result without a player, judge, or semantic-candidate delivery, while inequality or any other still-unresolved evidence shall return `no-action` and remain unresolved.
Executing `abandon:unresolved-effect` shall move no FSM state or start any player, judge, Captain, script, or child call and shall settle `executed` with exactly `{ outcome: 'unresolved-effect', state }`, where `state` is the current normalized nonfinal state.
That state-only run-result arm shall carry no `stateDescription`, output, pending call, error, repository receipt, effect ledger, semantic evidence, or other bounded effect fact, and shall claim neither an authored outcome nor workflow completion.

Acceptance is also the line past which `apply` does not throw, and
publication — the `apply.finished` emission — is the line past which its
receipt no longer changes. A settlement failure after acceptance but before
publication (a rejecting emission drain) settles the `failed` receipt carrying
its normalized error, replacing the one recorded at acceptance so the finish
trace, the returned receipt, and any replay of the key report one settlement.
A settlement failure at or after publication (a rejecting `apply.finished`
sink) does not: the disposition is already emitted, so no rewrite can make the
trace and the return agree, and a receipt states what happened to the effect
rather than what happened to its telemetry. The published receipt stands, is
returned and replayed verbatim, and the delivery failure travels on the
runtime's emission-failure channel to surface from the next public boundary
that drains — unless the delivery failure is causally identical to the apply
signal's own abort reason, in which case it evidences the cancellation and is
dropped, not latched
([DR-036](../specs/decisions/036-coherent-abort-settlement.md)).

Recorded control receipts are process-local. Invocation checkpoints retain the original input and accepted output across restoration; a restored runtime offers only the currently valid step controls.

The optional `PlaybookPorts.recordStep(step, position?)` lets a durable host save ordinary work without understanding machine internals.
The shared runtime records player, direct-Captain and script starts before execution and their actor results before advancing.
The runtime owns the complete stopped position, including accepted Boss input; the host joins nested frames and atomically stores starts and results; retention changes wait for settlement.
An invocation inside a parallel region records its start and result without a single-invocation recovery position, including when only its last region is resuming.
Sequential invocations after the join use ordinary checkpoints.
A custom runtime that cannot provide a position remains runnable, but a crash without a supported position returns to Captain with recorded work preserved.
Automatic recovery requires a failed or quiescent outcome produced by an operation in the same turn; resuming or adopting an older stop starts no preparation.
The store identifies the step that owns a saved position, so a consumed result cannot be attached to a later stopped snapshot.
Only internal step-start capture creates a synthetic failed position; public snapshot capture returns the actual stopped state.
Opening or reporting an interrupted run executes no work; Boss chooses the next action after checking outside effects and stopping any surviving worker.

## Abort

`handleBossInput.signal` is the abort surface.
The runtime shall honor it at every `callPlayer`/`callCaptain`/`callJudge` and
at every poll between transitions.
Each provided Captain, player, judge, or nested-playbook boundary shall receive
a signal combined from its XState invocation-lifetime signal and the currently
active `handleBossInput` or `resumePlaybookCall` signal (for example with
the shared `combineAbortSignals`). Classify a rejection as cancellation by its
causal identity with the applicable signal reason, not by an `AbortError` name
or by observing only that the signal is also aborted. Signals may carry an
ordinary `Error`, while a distinct transport or sink failure that occurs after
abort remains a non-abort control error and takes precedence. Classification
lives at each latch or report site, against the boundary signal applicable
there — the invocation-lifetime combined signal, and during a resume that
boundary's own signal — so a failure causally identical to the applicable
reason is the cancellation's own evidence: it is handled there under the phase
rules below, never mislabeled as a distinct failure and never carried to an
unrelated later boundary
([DR-036](../specs/decisions/036-coherent-abort-settlement.md)).
A failure already latched as distinct retains that ownership; a later drain
shall not reinterpret it against another boundary whose abort signal happens
to use the same object as its reason.
A public boundary settles on the machine's state at its quiescence point,
in this precedence: a suspended pending call, then a distinct actor error,
then terminal completion, then a coincident abort, then the recoverable
failure state — a completed machine settles `terminal` even when the signal
also aborted, because an `aborted` settlement over a terminal machine hides
work the next turn would silently restart.
An abort observed after the outcome is computed does not rewrite it, and a
settlement-channel rejection causally identical to the abort reason is
forgiven, so the returned result and the settlement trace state one fact.
A boundary entered with an already-aborted signal delivers nothing.
That entry refusal precedes the ordinary settlement order: a pre-aborted
resume reports `aborted` while preserving its suspended pending call rather
than reporting `suspended` for work it did not deliver.
Cancellation-coupled channel rejections obey this phase matrix:

- **Before a host call or effect starts (and before apply acceptance):** an
  identical start-channel rejection starts no host call or effect and latches
  no control error. A recorded start receives one best-effort `aborted` finish.
  An ordinary run boundary then settles by the precedence above; a
  pre-acceptance `apply` instead rejects with that exact reason, records no
  receipt, and leaves its key reusable.
- **After a host call or effect starts but before its finish or outcome is
  recorded:** an identical host, cleanup, observer, or in-flight-emission
  rejection is cancellation evidence. Invocation-owned cleanup completes, a
  started trace pair receives one `aborted` finish, and the ordinary boundary
  settles by the precedence above. A distinct rejection remains a control
  failure, produces the applicable error finish, and takes distinct-error
  precedence.
- **After a call finish is recorded but before the enclosing non-apply outcome
  is computed:** an identical finish-sink or drain rejection leaves the
  recorded finish unchanged, emits no corrective second finish, latches
  nothing, and lets the enclosing boundary settle by the precedence above.
- **After apply acceptance but before receipt publication:** every settlement
  failure, the exact apply abort reason included, is folded into the current
  `failed` receipt. Acceptance forbids throwing; the replacement receipt is
  published, returned, and replayed, and the failure is not carried as a later
  delivery error.
- **After a non-apply outcome is computed or an apply receipt is published:**
  an identical rejection is dropped without rewriting the outcome or receipt
  and without poisoning a later boundary. A distinct non-apply settlement
  rejection retains current-boundary control-error precedence; a distinct
  post-publication apply rejection retains the published receipt and travels
  on the delivery-failure channel to the next boundary that drains.
On abort, the
runtime shall not merely race the imperative
wait and return while an invocation remains live: it shall let the selected
rejection path settle and drive the actor to a quiescent state before returning
from the turn. No trace, status, state, or call completion caused by that turn
may appear after the public method returns.
Three strategies are permitted; the linker selects per FSM:

- **Natural rejection** — the runtime's Captain or player actor (e.g.,
  `fromPromise`) ends the invocation by rejecting, and the FSM routes
  the rejection through `onError` to a quiescent sink. The cancelled
  port call may _itself_ reject, or it may resolve with
  `PlayerResult` or `CaptainResult` with
  `{ status: 'aborted' | 'error' }` that the runtime
  inspects and converts into an actor rejection. Either shape
  is permitted — the contract is on the actor boundary, not on
  the port's promise behavior. Preferred when every Captain- or player-invoking
  state's `onError` lands somewhere quiescent; the FSM's own error
  wiring is the abort path.
- **Synthetic pre-emption to a quiescent target** — send the FSM's
  pre-emption event (e.g., `BOSS_INTERRUPT { targetId: <state> }`) with
  a target that is itself quiescent (typically `ready` or `failed`).
  The runtime shall not pick the active state as the target:
  `gears2fsm.md` prescribes `reenter: true` for `bossInterrupts`, so
  re-entering the active state restarts its `invoke` and spawns a
  fresh agent call.
- **Programmatic stop** — `actor.stop()` and report the turn as aborted
  via `emitStatus`. Reserved for FSMs with neither `onError` wiring nor
  a pre-emption event.

Whether the host's outer abort (e.g., SIGINT) is recoverable or terminal is the host's concern.
The runtime exits `handleBossInput` cleanly in either case; the host decides whether to call `dispose` afterward.

## Status and telemetry

The runtime shall emit, at minimum:

- One `emitStatus` per Boss-relevant transition (entering a state whose
  semantics matter to Boss — e.g., `respondToReview`, `failed`). The
  default is to emit on every transition and let the host filter; hosts
  may bind a stricter rule.
  Mark both a player-question status and its waiting marker with status data
  `{ kind: "boss-question" }`; the session Captain replaces those statuses with
  its own clear reply, using the complete pending question from the control view.
  Keep the original question in state and telemetry, and deliver Boss input unchanged.
- One `emitTelemetry` per state transition under a namespaced topic
  (recommended `playbook.fsm.state`), with structured `from`, `to`, `event`,
  `previousState`, and `state` fields. Descriptors carry the JSON-safe XState
  value, active stable ids from public state metadata, tags, status, and
  quiescence; they do not inspect private XState nodes.
  The payload shall additionally carry the exact pending Boss question or
  keyed questions selected from public snapshot context and normalize any
  transition error without retaining a raw `Error` instance.
  Do not reduce this payload to the current state: `from` and `previousState`
  are the authoritative prior descriptor, while `to` and `state` are the new
  descriptor. On the first observed transition, use the initialized state as
  both the prior and new descriptor when no earlier transition exists.
  Snapshot and recursively freeze the complete described telemetry payload
  independently from the state retained as `previousState`, so an observer
  cannot mutate a later transition's authoritative `from` state.
  Observers consume telemetry; the runtime never interprets the topic.

Player prompts and adjudicator JSON may additionally ride the host's own record channels when the host has them (cligent's `captain_*` / `player_*`).
The `playbook.trace` copies are the host-agnostic runtime-boundary record required by §Playbook trace.

## Output

The link compiler emits one TypeScript module per playbook.
Every linked artifact shall emit an `unfinishedFinalStateIds` set beside its resumable-state registry as mechanical link-time metadata.
The set shall contain exactly the stable ids of root `type: 'final'` states whose terminal outcomes leave the procedure unfinished, and shall be explicitly empty when no terminal outcome does.
The linker shall not infer the set from a state description, opaque output, or procedure prose.
The linker shall reject a declared id that does not name a root final state, and the shared factory shall independently reject it at construction before runtime effects.
For a factory-backed artifact the set is a `spec` member; linked machinery of an artifact's own shall retain equivalent linked metadata, and the artifact declaration is not itself the public runtime retention marker or an adoption capability.
For every FSM [gears2fsm.md](gears2fsm.md) produces — flat under its
one-state-per-item mapping, or carrying root parallel groups of its
[Parallel groups](gears2fsm.md#parallel-groups) shape — the linker shall
emit the thin shared-factory module defined below.
The shared factory interprets such a parallel group through its parallel
profile under [DR-067](../specs/decisions/067-parallel-proposals-through-the-shared-factory.md), deriving the regions, their leaves, and the
cohort of working leaves from the FSM and its exported `concurrentRoleSets`,
so the emitted module declares nothing further for it; bespoke linked
machinery is no longer the prescribed output for any such FSM.
Linked machinery of an artifact's own that satisfies this document's runtime
contract remains a valid implementation for an artifact outside this package
and declares the `bespoke` registry profile below, so hosts keep accepting it.
The FSM-interpreter machinery — actor wiring, boundary tracing, Boss-event
mapping, adjudication, script execution, nested-playbook bridging, session
lifecycle, abort handling, and the optional parked-session snapshot and
retained-snapshot adoption capabilities — is not regenerated for a
factory-backed artifact: it ships once
as the shared `createXStatePlaybookRuntime(machine, spec)` factory exported by
`@sublang/playbook/xstate-runtime`, and the emitted module hands its FSM and
a small per-playbook `spec` to that factory. Every behavioral section of
this definition still binds the emitted module's runtime; the shared factory
is how the emitted module satisfies them, so a runtime fix ships as a
package release instead of a re-link of every artifact.

The thin emitted module:

- Imports the FSM artifact by relative path with an extension-bearing
  runtime specifier. When the linked TypeScript is part of a package that
  compiles and ships JavaScript siblings, the source shall use the
  NodeNext-compatible `.js` specifier (for example `./code.fsm.js`), never a
  `.ts` specifier that the package's supported Node versions cannot load.
  An explicitly source-only host may instead retain `.ts` only when that
  host supports direct TypeScript loading and no JavaScript build is shipped.
- Restricts itself to erasable TypeScript syntax — type annotations
  that strip cleanly, no constructor parameter properties, `enum`s, or
  namespaces — so a host running under type stripping loads it
  directly.
- Imports `createXStatePlaybookRuntime` (plus any shared strategy defaults
  its `_internal` surface re-exports) from the shared engine module through
  its bare package specifier `@sublang/playbook/xstate-runtime`, and the
  contract types through `@sublang/playbook/runtime`. It shall not copy,
  inline, or re-derive interpreter machinery — actor bridges, trace
  emission, judge-JSON recovery, lifecycle guards — beside the factory
  call, and shall not import `xstate`, `p-queue`, or `node:child_process`
  itself; those are the shared engine's dependencies.
- Declares and exports the typed `PlaybookRuntimeOptions` interface for that
  playbook, derived from every required FSM input field that is not supplied
  by `PlaybookSession` or another linker-owned source (§PlaybookRuntime
  contract), plus the optional `cwd` option whenever the FSM contains a
  `script` state (§Script execution).
- Exports the public `validateOptions` function specified above and supplies
  it as the spec's identical `snapshotOptions` callback: validate and JSON-snapshot the
  caller's options, rejecting undeclared keys and non-conforming values, so
  the factory binds an immutable options record before constructing any
  actor.
- Supplies in `spec` only what the factory cannot read from the FSM
  artifact's own data: the deterministic textual entry event where
  §Boss-event mapping prescribes deterministic entry, naming with it the FSM
  context member that event's own transition action copies the exact Boss
  text into wherever the machine keeps one, so the failure-state retry of
  §Control surface survives a restore; compact `bossEvents`
  metadata for each additional Boss-union arm whose exact required/optional
  judge fields, runtime-owned text fields, or closed string values disappear
  under TypeScript erasure; `placeholderFields` only for authored token/field
  exceptions not covered by the canonical kebab-token-to-camel-field mapping
  and the canonical `<#>` → `irNumber` special case; the
  transition-event payload fields the FSM's Boss union declares; the
  complete `roleStates` status map derived from every FSM state that invokes
  the typed `player` actor, with each `role` copied from that state's
  source-derived `meta.playbook.role` (an empty map when there is no such
  state); the exact schema-3 `outcomeAuthority` map derived
  from every such state's `invoke.input.result` contract and its linked field
  authorities and repository dispositions (an explicit empty governed map
  when there is no such state); the
  `verbatimPayloadFields` set derived from annotated result fields above; the
  explicitly empty or populated `unfinishedFinalStateIds` set declared above;
  the `controlContextFields` projection of §Control surface; and any
  per-playbook strategy override (classifier, prompt composers,
  required-field extraction, status formatting) an earlier section of this
  definition requires for that playbook.
  `controlContextFields` is authored, not derived: the linker names the FSM
  context members the playbook's controller view exposes and no others, in the
  order the view should render them, omitting the member entirely where the
  playbook exposes no context. It is the one spec member whose default is
  *nothing* rather than everything — the factory exports no context for a
  module that supplies none — so a module emitted without it advertises a
  playbook with no Boss-visible context rather than one whose whole FSM
  context is Boss-visible. The linker shall not name a member the view
  surfaces first-class (the pending Boss question, the last error), which is a
  construction error, and shall not name a member carrying a resolved player
  roster, an option value, or player-authored text, which a controller host's
  prompts are required to exclude or to fence. The metadata shall keep the shared
  classifier's reply contract exactly flat `{ type, ...declaredFields }` and
  distinguish judge-authored routing fields from exact-text fields the
  runtime attaches itself. Everything else — player/script/captain/nested actor
  provisioning, prompt composition, classification, adjudication, statuses,
  resumable-state derivation — comes from the factory's generic defaults,
  which implement the behavioral sections of this definition.

  ```ts
  interface XStateBossEventFieldSpec {
    source: 'judge' | 'text';
    required?: boolean;
    values?: readonly string[];
  }

  interface XStateBossEventSpec {
    type: string;
    fields?: Readonly<Record<string, XStateBossEventFieldSpec>>;
  }

  interface XStateRoleStateStatus {
    role: string;
    label: string;
  }

  bossEvents?: readonly XStateBossEventSpec[];
  roleStates?: Readonly<Record<string, XStateRoleStateStatus>>;
  placeholderFields?: Readonly<Record<string, string>>;
  ```

  Supplied `bossEvents` metadata shall merge with, and shall not replace or
  weaken, runtime-derived entry text ownership or closed interrupt targets.
  A conflicting duplicate field contract is a linker/runtime construction
  error.
  `NO_ACTION` and `BOSS_REPLY` are runtime-owned event types the factory
  supplies itself — `NO_ACTION` as exactly `{ type: 'NO_ACTION' }`, and
  `BOSS_REPLY` as a judge-selected `questionId` — optional while one question
  is pending and required, from the pending ids, while several are — plus the
  exact-text `answer` the runtime attaches. `bossEvents` shall carry no entry for either
  type; supplying one is a construction error, so a linker that judges a
  runtime-owned arm to have lost payload detail under erasure shall report
  that gap rather than emit the entry.
- Supplies `spec.compat` with the compatibility values current at link time:
  `{ artifactSchema: 3, runtimeAbi }`, where `runtimeAbi` is the installed shared engine's
  `RUNTIME_ABI` self-report.
  The linker shall verify that the installed engine lists the emitted
  schema in `SUPPORTED_ARTIFACT_SCHEMAS` and treat its absence as a
  link-time error; it shall not stamp a different member (such as the
  highest) merely because that engine also supports a newer artifact
  format — the declaration names the format of the emitted module, not
  the capability of the emitting engine. The factory checks the
  declaration against the engine instance that actually loads the emitted
  module and fails construction on a mismatch, so an artifact linked under
  one engine cannot run silently skewed under another. Modules emitted
  before this contract carry no `compat` member and shall reject before interpretation.
- Requires the containing public registry manifest to advertise the identical
  `artifactSchema` and an exact implementation `runtimeProfile`. A shared
  factory profile is `{ kind: 'shared-factory', compat }`, where `compat` is
  the immutable compatibility record captured by that actual factory from
  its validated `spec.compat`; a bespoke profile is
  `{ kind: 'bespoke', artifactSchema }`, with schema `3` declared directly by
  that implementation and no `runtimeAbi` claim. A registry factory accepts configured options and current
  host capabilities separately and composes the linked runtime's exact
  `{ configuredOptions, hostCapabilities }` input. The Captain host shall
  capture the imported manifest fields once, require capabilities for every
  and only enabled artifact id, validate each capability's artifact, role,
  cohort, and canonical-worktree authority, and reject a missing, extra,
  malformed, or mismatched capability before runtime construction.
- Default-exports the factory call as `createPlaybookRuntime`, typed as
  `XStatePlaybookRuntimeFactory<XStatePlaybookRuntimeConstruction<PlaybookRuntimeOptions, HostCapabilities>, 3>`
  with the artifact's declared live capability type. A registry module loads
  dynamically inside the host's caught boundary, so its eager module-scope
  factory call fails fast there. The compiled session Captain module is the
  exception: the shell and both CLI front ends import it statically, so it
  shall defer its factory call to the first runtime request — an eager call
  would turn a future `spec.compat` rejection into an uncaught module-load
  error that takes even `--help` down, instead of the caught
  host-construction boundary's setup diagnostic.
- Exposes, under an `_internal` export, the pure helpers verification
  needs — at least the prompt composers its own machine uses, which may
  re-export the shared defaults when the spec does not override composition,
  and the `VERBATIM_PAYLOAD_FIELDS` and `UNFINISHED_FINAL_STATE_IDS` sets the
  spec declares, which the linked-ownership check reads back — so
  compilation-correctness tests can exercise composition and ownership
  without a host.
  A playbook that calls players exposes `composePlayerPrompt`; a playbook
  whose states make direct-Captain calls exposes `composeCaptainPrompt`. A
  controller playbook that calls no players exposes no player composer:
  there is no composition to verify, and a stub under that name would
  describe work the module cannot do. `_internal` is not a public API — the
  leading underscore says so — and nothing in it is semver-stable; a helper
  a host is meant to call is a top-level export and is governed as one.
- Holds no host-specific types and no host primitive calls. The runtime
  speaks only `PlaybookPorts` for every agent and host concern; the
  `node:child_process` dependency of §Script execution lives in the shared
  factory, not in the emitted module.
- Records the linker inputs (FSM path and strategies) in a
  top-of-file header comment so the file is reproducible from the same
  inputs.
- Sources the contract types (`PlayerResult`, `PlayerCallOptions`,
  `PlayerSessionStore`,
  `CaptainResult`, `CaptainCallOptions`, `PlaybookPorts`, `PlaybookSession`,
  `PlaybookTraceEvent`,
  `PlaybookCallRequest`, `PlaybookCallResult`, `PlaybookCallStart`,
  `PlaybookStateValue`, `PlaybookState`, `PlaybookRunResult`,
  `PlaybookRuntime`, `PlaybookRuntimeFactory`) from the single shared
  type-only module instead of redefining them, and re-exports the names
  its consumers import, so every linked playbook shares one contract
  definition. The shared modules import no FSM or host types, so the
  dependency runs one way — from each linked module to the shared
  engine and contract, never the reverse.

Both output profiles remain subject to the behavioral sections above and the
verification requirements below.

When a co-located integration test for the linked runtime already exists, the
link compiler shall run it before reporting success and treat any failure as a
generation failure. It shall not delete, skip, or weaken that suite to make a
new artifact pass; the suite is executable evidence for lifecycle, ordering,
error-propagation, and host-boundary requirements that static artifact checks
cannot establish.

Internal trace/status helpers may accept `unknown`, validate it with the same
JSON-safety rules as the public boundary, and only then emit a `JsonValue`.
They shall not require nominally typed public interfaces such as
`NormalizedError`, `PlaybookState`, `PlaybookCallRequest`, or
`PlaybookCallResult` to satisfy a `JsonValue` index signature at compile time,
and they shall not silence that mismatch with an unchecked cast.
Prompt placeholder substitution shall make one callback-based pass over the
original template. Replacement strings are literal: placeholder-looking text
inside Boss/catalog/plan/result values and JavaScript replacement tokens such
as `$&`, `$$`, dollar-backtick, and `$'` shall not be interpreted or
substituted again.
A quoted relay line `> <placeholder>` whose value is empty shall be omitted
from the composed text rather than left as an empty quoted line, a multi-line
value shall be quoted line by line so every continuation line keeps its `>`
marker, and the composer shall insert no empty quoted line of its own.

## Host adaptation (informative, not normative)

A host integrates with playbooks via a small adapter that:

1. Accepts a path to a `PlaybookRuntime` module (either as a direct
   import in a playbook-specific adapter, or via the host's config
   surface in a generic adapter).
2. Imports the module and constructs the runtime with options forwarded
   verbatim from the host config.
3. Implements `PlaybookPorts` by wrapping the host's own primitives —
   for cligent/tmux-play this is `callPlayer ← context.callPlayer`, visible
   `callCaptain ← context.callCaptain`, hidden
   `callJudge ← context.callCaptain`, nested `callPlaybook ←` the Captain
   session stack, and `emitStatus`/`emitTelemetry` ←
   `session.emitStatus`/`session.emitTelemetry`. The two Captain-backed ports
   share one abort-aware concurrency-one queue.
4. Generates a unique playbook-session id, calls
   `runtime.init({ sessionId, rootSessionId: sessionId, depth: 0,
playbookId, ports })` once at session start, forwards each Boss turn to
   `runtime.handleBossInput`, and calls
   `runtime.dispose()` at session end.

Its location is a project-organization choice:

- **Playbook repo** — simplest when the playbook author owns the integration; keeps host primitives a lower-layer dependency.
- **Host repo** — when the host author wants to ship an opt-in playbook Captain.
- **Third package** — otherwise.

This spec is silent on the choice; the contract is the same in any location.

## Out of scope

- Defining player prompts, result keys, or guard semantics — those
  belong in the GEARS source and the FSM artifact.
- Host adapter implementations, host configuration, presentation
  layouts — where these live is a per-project decision (see
  §Host adaptation); this spec only constrains the `PlaybookPorts`
  contract they satisfy.
- Trace persistence, multiple Boss-selected root engagements, recursive
  playbook calls, multi-Boss orchestration, or visualizer rendering —
  separate hosts/observers may add them without changing this spec. A host
  may persist the emitted trace, but the runtime does not rehydrate a
  disposed actor from it. Parked-session durability is in scope only
  through the optional snapshot surface of §Parked-session snapshot
  (DR-014); everything beyond it remains out of scope.

New behavior in any of these areas requires a separate slc spec.

## Compiled execution

This section governs compiled execution of this phase; the rules above remain the transformation's normative content for both execution paths.

Where the phase host supplies `<definition>` as the exact bytes of the definition file the request names, when a transformation request names an `fsm` Source (`.ts`) and a `playbook` Target (`.ts`), Captain shall carry out the FSM-to-runtime linking as specified:

> Follow the definition relayed between the `--- DEFINITION ---` and `--- END DEFINITION ---` lines exactly, adding no rules of your own: read the named Source and write the named Target as the definition specifies.
> If the Source cannot be transformed under the definition, do not guess: leave the Target unwritten and report the concrete reason.
> --- DEFINITION ---
> \<definition\>
> --- END DEFINITION ---

Results:
- `compiled`: Captain wrote the named Target as the relayed definition specifies.
- `rejected`: Captain reported that the Source cannot be transformed under the relayed definition and left the Target unwritten.

## References

[1]: text2gears.md "First phase: text → GEARS spec items."
[2]: gears2fsm.md "Second phase: GEARS items → FSM artifact."
[3]: https://stately.ai/docs/actors "XState actors — `createActor`, snapshots, abort signal handling."
[4]: https://github.com/sindresorhus/p-queue#readme "p-queue concurrency and AbortSignal support."
