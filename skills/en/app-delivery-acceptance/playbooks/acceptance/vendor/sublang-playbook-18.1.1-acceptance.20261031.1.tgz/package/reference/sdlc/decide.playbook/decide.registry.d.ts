import { type PlaybookHostCapabilities, type PlaybookRuntime } from './decide.playbook.js';
import type { PlaybookHostConstructionCapabilities } from '../code.playbook/playbook-captain.js';
export interface PlaybookSummaryPolicy {
    stateCountLabels: Readonly<Record<string, string>>;
    copyPasteGuardNames: readonly string[];
    savedCountsLine(counts: {
        interruptions: number;
        copyPastes: number;
    }, rounds: number): string;
}
export type DecideOptions = Readonly<Record<string, never>>;
export interface DecidePlaybookRegistryEntry {
    id: 'decide';
    command: 'decide';
    intent: string;
    artifactSchema: 3;
    runtimeProfile: {
        readonly kind: 'shared-factory';
        readonly compat: {
            readonly artifactSchema: 3;
            readonly runtimeAbi: number;
        };
    };
    requiredRoleIds: readonly ['coder', 'reviewer'];
    concurrentRoleSets: readonly [readonly ['coder', 'reviewer']];
    summaryPolicy: PlaybookSummaryPolicy;
    validateOptions(optionSlice: unknown): DecideOptions;
    createRuntime(options: DecideOptions, hostCapabilities: PlaybookHostConstructionCapabilities & PlaybookHostCapabilities): PlaybookRuntime;
}
export declare const decideStateCountLabels: {
    readonly independentProposals: "proposal round";
};
export declare const decideCopyPasteGuardNames: readonly ["proposed"];
export declare function decideSavedCountsLine(counts: {
    interruptions: number;
    copyPastes: number;
}, rounds: number): string;
export declare const decideSummaryPolicy: PlaybookSummaryPolicy;
export declare function validateDecideOptions(optionSlice: unknown): DecideOptions;
export declare const decidePlaybookRegistryEntry: DecidePlaybookRegistryEntry;
export default decidePlaybookRegistryEntry;
