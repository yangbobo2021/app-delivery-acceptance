<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: 2026 SubLang International <https://sublang.ai> -->

# cligent guide

For per-call file attachments and invoking configured browser or desktop tools,
see [Media and computer use](media-and-computer-use.md).

## Install

```bash
npm install @sublang/cligent
```

Each adapter that uses an SDK has an optional peer dependency. Install only the ones you need:

```bash
npm install "@anthropic-ai/claude-agent-sdk@>=0.3.284"   # Claude Code
npm install "@openai/codex-sdk@>=0.156.1"                 # Codex CLI
npm install "@opencode-ai/sdk@>=1.18.29"                  # OpenCode
# Gemini CLI uses a child process — no SDK required
# Kimi Code uses an external CLI — no Kimi-specific SDK required
```

A peer SDK has to land in the tree the running cligent resolves packages
from, so add `-g` to these commands when cligent itself was installed with
`npm install -g` — as the [`tmux-play`](tmux-play.md) app is. The CLIs an
adapter spawns (`gemini`, `kimi`, `opencode`) are always global, since they
are found on `PATH` rather than in `node_modules`:

```bash
npm install -g @google/gemini-cli            # Gemini CLI
npm install -g opencode-ai                    # OpenCode server
```

For Kimi, install the maintained Kimi Code CLI at Cligent's exact conformance
target. The external Kimi CLI itself requires Node.js 22.19 or newer to install
and run, even though Cligent and its other adapter surfaces support Node.js
18.3:

```bash
npm install -g @moonshot-ai/kimi-code@2.1.1
kimi --version
kimi login
```

`kimi login` performs the one-time Kimi Code OAuth flow, which is the
simplest way to satisfy the exact 2.1.1 ACP target's session gate. That gate
accepts stored OAuth material resolved from the default model or reported by
any logged-in provider, including after `kimi login`; a [model/provider
configuration](https://www.kimi.com/code/docs/en/kimi-code-cli/configuration/providers.html)
whose default-model alias resolves to non-OAuth credentials; or the
`KIMI_MODEL_NAME` plus `KIMI_MODEL_API_KEY` environment overlay, which
synthesizes that default model for the running process only. A bare
`MOONSHOT_API_KEY` satisfies none of them, because it names no default model.
The adapter inherits the CLI's configuration and credentials; Cligent neither
stores credentials nor launches login for you.

## Quick start

```ts
import { Cligent } from '@sublang/cligent';
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';

// Cligent — the primary API surface. Wraps an adapter with role identity,
// session continuity, option merging, and protocol hardening.
const agent = new Cligent(new ClaudeCodeAdapter(), {
  role: 'coder',
  model: 'claude-opus-5-5',
});

// agent.run(prompt, overrides?) → AsyncGenerator<CligentEvent>
// CligentEvent extends AgentEvent with an optional `role` field.
// Each event has a discriminated `type` field and a typed `payload`.
for await (const event of agent.run('Fix the login bug')) {
  switch (event.type) {
    case 'text_delta':
      // Streaming token — concatenate deltas to build the full response.
      process.stdout.write(event.payload.delta);
      break;
    case 'tool_use':
      // The agent is invoking a tool (e.g. Bash, Read, Edit).
      console.log(`Tool: ${event.payload.toolName}`);
      break;
    case 'done':
      // Terminal event — always the last event in the stream.
      // status: 'success' | 'error' | 'interrupted' | 'max_turns' | 'max_budget'
      console.log(`\nFinished: ${event.payload.status}`);
      break;
  }
}
```

## Cligent class

`Cligent` is the recommended way to interact with adapters. It provides:

- **Role identity** — when configured, tag every event with a task-level role (e.g. `'coder'`, `'reviewer'`)
- **Session continuity** — automatically resume previous sessions via `resumeToken`
- **Option merging** — set defaults in the constructor, override per-call
- **Single-flight guard** — prevents concurrent `run()` calls on the same instance
- **Protocol hardening** — guarantees exactly one `done` event per call, synthesizes error/done on adapter failures, handles abort racing

```ts
import { Cligent } from '@sublang/cligent';
import type { CligentOptions, RunOptions } from '@sublang/cligent';

// Constructor: Cligent(adapter, options?)
// CligentOptions — instance-level defaults (no abortSignal, no resume).
const agent = new Cligent(adapter, {
  role: 'coder', // injected into every event as event.role
  model: 'claude-opus-5-5',
  permissions: { fileWrite: 'allow', shellExecute: 'ask' },
  maxTurns: 10,
});

// run(prompt, overrides?) → AsyncGenerator<CligentEvent>
// RunOptions extends CligentOptions with abortSignal and resume.
// Per-call overrides win for scalars; permissions are merged by field;
// allowedTools/disallowedTools arrays are replaced entirely.
for await (const event of agent.run('Fix the bug', {
  model: 'claude-sonnet-5-5', // overrides the default
  abortSignal: controller.signal,
})) {
  // event.role === 'coder' (always from constructor defaults)
}
```

## Adapters

Pass an adapter to the `Cligent` constructor (or to the lower-level
`runAgent` helper).

**Claude Code**

```ts
// SDK adapter — wraps @anthropic-ai/claude-agent-sdk.
// Normalises SDKMessage objects into the Unified Event Stream.
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';
const agent = new Cligent(new ClaudeCodeAdapter());
```

**Codex CLI**

```ts
// SDK adapter — wraps @openai/codex-sdk.
import { CodexAdapter } from '@sublang/cligent/adapters/codex';
const agent = new Cligent(new CodexAdapter());
```

**Gemini CLI**

```ts
// Child-process adapter — spawns the gemini CLI and parses its NDJSON stream.
// No SDK peer dependency required.
import { GeminiAdapter } from '@sublang/cligent/adapters/gemini';
const agent = new Cligent(new GeminiAdapter());
```

**OpenCode**

```ts
// SDK adapter — wraps @opencode-ai/sdk.
import { OpenCodeAdapter } from '@sublang/cligent/adapters/opencode';
const agent = new Cligent(new OpenCodeAdapter());
```

The default managed mode owns a server process for the call. External mode
connects to the caller's server and leaves its workspace instance running
when the call closes; cancellation still targets the call's native session.

**Kimi Code**

```ts
// ACP adapter — spawns one short-lived `kimi acp` child for each run.
import { KimiAdapter } from '@sublang/cligent/adapters/kimi';
const agent = new Cligent(new KimiAdapter(), {
  effort: 'on',
  permissions: { mode: 'auto' },
});
```

Cligent uses Kimi Code's structured ACP mode rather than print mode, a
persistent server, or a Kimi-specific SDK. The maintained product exposes ACP
as a public integration surface, while the published Kimi agent SDK targets
the retired Python CLI and the successor's Node SDK is not public. ACP preserves
structured text, tool lifecycle, permission requests, cancellation, and the
backend session ID without keeping a resident service.

A fresh run creates an ACP session with `session/new`. A non-empty `resume`
token uses `session/resume`; Cligent does not replay Kimi history as new output.
The backend session ID becomes `DonePayload.resumeToken`, so the next run on the
same `Cligent` instance resumes automatically. Raw Kimi thought chunks are not
included in the Unified Event Stream.

## Effort

Set `effort` in constructor defaults or in a `run()` override. The portable
ladder, from least to greatest reasoning depth, is `minimal`, `low`, `medium`,
`high`, `xhigh`, and `max`. Provider-native values remain adapter-scoped:
Claude Code additionally accepts `ultracode`, while Codex additionally accepts
`ultra`. Gemini and OpenCode accept only the portable ladder. Kimi instead
accepts its provider-native binary values `off` and `on`; those values are not
aliases for portable depth tiers. The TypeScript API preserves this
correlation, including heterogeneous parallel calls, so an adapter-specific
value is not accepted for a different adapter.

```ts
import { Cligent } from '@sublang/cligent';
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';
import { CodexAdapter } from '@sublang/cligent/adapters/codex';

const claude = new Cligent(new ClaudeCodeAdapter(), {
  effort: 'ultracode',
});
const codex = new Cligent(new CodexAdapter(), {
  effort: 'ultra',
});

// The same adapter-specific vocabulary is available per call.
for await (const event of claude.run('Review this change', {
  effort: 'high',
})) {
  // ...
}
```

The mappings have a few important qualifications:

- **Claude Code:** `ultracode` maps to SDK `effort: 'xhigh'` plus
  `settings.ultracode: true`. Every explicit portable value sets
  `settings.ultracode: false`, so a run can downgrade inherited ultracode
  configuration. `minimal` maps to Claude's lowest native tier, `low`.
  Ultracode requires compatible workflow support and an xhigh-capable model,
  account, and installed runtime. Its delegated workflow can increase token
  use, latency, cost, concurrency, and tool activity.
- **Codex:** `minimal` through `xhigh` use the SDK thread effort field. `max`
  and `ultra` pass through unchanged as `model_reasoning_effort` constructor
  configuration; `ultra` enables automatic delegation. Availability still
  depends on the selected model, account, and installed runtime, and delegation
  can increase token use, latency, cost, concurrency, and tool activity.
- **Gemini:** Effort is applied only for concrete `gemini-3*` or `gemini-2.5*`
  model IDs. Gemini 3 collapses `high`, `xhigh`, and `max` to `HIGH`; Gemini
  2.5 Flash and Flash Lite collapse `xhigh` and `max` to the same maximum
  budget. If the model is omitted, is a CLI alias such as `auto` or `flash`,
  or does not match those model families, the adapter preserves ordinary model
  forwarding and applies no effort override. The adapter delivers effort as a
  model alias in a private per-run Gemini home (`GEMINI_CLI_HOME`) whose
  settings are your user settings plus that alias; every other file there
  links to your real home, so credentials, sessions, and trust state stay
  shared, and files the run replaces are reconciled back when it ends. A run
  whose working directory is the Gemini home, whose environment names no
  home, or that Gemini would sandbox, gets the concrete model with no effort
  override.
- **OpenCode:** Effort selects the prompt `variant` the chosen model
  advertises in the server's provider catalog for the run's directory, or else
  its nearest advertised effort variant, the higher on a tie: GPT-6 Sol's
  `max` reaches `max`, and its `minimal` reaches `low`. A model listed without
  effort variants receives none. Only when the catalog cannot be read within
  10 seconds or does not list the model does a lossy provider table apply:
  Anthropic collapses `minimal` through `high` to `high` and `xhigh`/`max` to
  `max`; OpenAI collapses `max` to `xhigh`; Google collapses `minimal` through
  `medium` to `low` and `high` through `max` to `high`, and any other provider
  receives no variant override. A malformed or omitted model never receives
  one.
- **Kimi:** `off` and `on` pass directly to ACP's `thinking` configuration
  option. `on` enables the selected model's native default thinking behavior;
  it does not select a portable Cligent effort tier. When both `model` and
  `effort` are provided, the model is selected before thinking is toggled. A
  model that always thinks, such as `kimi-code/k3`, offers no `off`: the run
  then stops before the prompt with `KIMI_EFFORT_UNAVAILABLE`, naming the
  thinking values the model does offer.

Omitting `effort` sets no effort, orchestration, generated alias, or variant
override and leaves applicable adapter, model, account, and user-configuration
defaults in control.

Use the deeply frozen `EFFORT_SUPPORT` metadata to build selectors or inspect
each built-in adapter's accepted `values`, provider-native
`orchestrationValues`, `modelDependent` flag, and explanatory `notes`.
`getEffortSupport`, `supportedEffortValues`, `isEffortSupported`, and
`assertSupportedEffort` provide matching lookup and validation helpers (`claude`
is accepted as an alias for `claude-code`):

```ts
import { EFFORT_SUPPORT, assertSupportedEffort } from '@sublang/cligent';

console.log(EFFORT_SUPPORT.codex.values);
const requestedEffort: unknown = process.env.CLIGENT_EFFORT;
assertSupportedEffort('codex', requestedEffort, 'effort');
```

This metadata describes values that Cligent can route; it does not guarantee
that a selected model, account, or installed provider runtime supports a value.
If the backend rejects a metadata-accepted value, Cligent surfaces that upstream
failure without substituting a different effort.

The former public option name `reasoningEffort` has been replaced by `effort`.
Programmatic callers must update the property name. Valid legacy tmux-play YAML
is accepted in memory only after the complete document validates. The loader
then makes a bounded best-effort update of direct legacy key tokens when the
source still matches. If the source changes or the write fails, the run keeps
the validated in-memory value and the launcher warns you to rename
`reasoningEffort` to `effort` manually. Conflicting keys, invalid legacy values,
or any other config error reject without writing.

## Fast mode

`fastMode` requests a provider's lower-latency serving mode independently of
reasoning `effort`. Claude Code and Codex accept the option. Gemini, OpenCode,
and Kimi expose no native fast-mode request surface, so their adapter-bound
TypeScript options admit no value and dynamic calls reject a defined value
before provider work starts.

- `true` requests the provider's native fast mode.
- `false` explicitly requests its native standard or off mode and overrides a
  constructor default of `true`.
- Omission adds no Cligent override and leaves provider configuration in
  control.

```ts
import { Cligent } from '@sublang/cligent';
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';

const claude = new Cligent(new ClaudeCodeAdapter(), { fastMode: true });

// Explicit false is retained as a per-run scalar override.
for await (const event of claude.run('Use standard serving for this turn', {
  fastMode: false,
})) {
  // ...
}
```

Fast-mode support means Cligent can deliver the request, not that the selected
model, account, provider, organization policy, billing state, network, or
installed runtime will honor it. A supported backend refusal follows the
ordinary error path; Cligent does not retry at another speed or claim that
fast serving occurred.

Use `FAST_MODE_SUPPORT` and its helpers to build an adapter selector. The
metadata is deeply frozen and separates request support from authentic
observation support. `claude` is accepted as an alias for `claude-code`.

```ts
import {
  FAST_MODE_SUPPORT,
  assertFastModeSupported,
  getFastModeSupport,
  isFastModeSupported,
} from '@sublang/cligent';

console.log(FAST_MODE_SUPPORT['claude-code'].observation); // 'init-and-done'
console.log(getFastModeSupport('codex')?.requestSupported); // true
console.log(isFastModeSupported('gemini')); // false
assertFastModeSupported('codex');
```

Claude may attach authentic `fastMode` observations to `init` and `done`
payloads. Those observations can report `state` (`off`, `cooldown`, or `on`)
and a `disabledReason`; a `done` observation may additionally report the
completed response's `responseSpeed` (`standard` or `fast`). Missing or
unrecognized upstream data stays absent. Codex accepts requests but exposes no
effective-tier event through its public SDK, so its events carry no fast-mode
observation and never echo the requested boolean as one.

## Subagent model and effort

`subagentModel` names the model every subagent of a run uses, separately from
the run's own `model`, and `subagentEffort` names the effort they run at. They
let a strong main agent keep the reasoning and design work while it hands
well-defined, fine-grained tasks to subagents on a cheaper or faster model,
without those subagents silently inheriting the main agent's effort. Only
Claude Code accepts the options. Codex, Gemini, Kimi, and OpenCode expose no
per-run subagent surface, so their adapter-bound TypeScript options admit no
value and dynamic calls reject any defined value before provider work starts.

- `subagentModel` is a model ID or alias string, passed verbatim, or the
  literal `inherit` for the run's own model. It must contain a non-whitespace
  character.
- `subagentEffort` is a Claude effort value other than `ultracode`: `minimal`,
  `low`, `medium`, `high`, `xhigh`, or `max`. It requires `subagentModel`;
  omitted beside it, the agent chooses an effort for each task. Without
  `subagentModel`, outside that vocabulary, or on another adapter it is
  rejected before provider work.
- A per-run value of either overrides a constructor default.
- Omitting `subagentModel` adds no Cligent subagent configuration and leaves
  the runtime's own order in force.

```ts
import { Cligent } from '@sublang/cligent';
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';

const claude = new Cligent(new ClaudeCodeAdapter(), {
  model: 'claude-opus-5-5',
  effort: 'ultracode',
  subagentModel: 'claude-haiku-4-5',
  subagentEffort: 'medium',
});

for await (const event of claude.run('Refactor the parser module')) {
  // ...
}
```

When a run carries `subagentModel`, the Claude adapter does three things:

- It sets `CLAUDE_CODE_SUBAGENT_MODEL_FORCE` to `1` in the run's own copy of
  the process environment, with `CLAUDE_CODE_SUBAGENT_MODEL` set to a named
  model or, for `inherit`, removed. The force flag makes that model — or, alone,
  the run's own — bind every subagent, including the built-in ones whose
  definitions name a model and any model the main agent would pass for one
  call. Your process environment is not changed.
- It registers subagent definitions on that model, which the Agent tool lists
  with their descriptions — "Runs on {model} at {effort} effort.", or "Runs on
  your model at {effort} effort." for `inherit` — and one short delegate prompt:
  - With `subagentEffort`, one definition named `delegate` at that effort.
  - Without it, one definition per effort Claude accepts for a definition —
    `delegate-low`, `delegate-medium`, `delegate-high`, `delegate-xhigh`, and
    `delegate-max` — so the agent's choice of effort is a choice of definition
    the Agent tool enforces.
  - In both, one definition named `general-purpose` that replaces the built-in
    of that name, with the delegate prompt in place of the built-in's own and
    no model of its own, so the forced model applies. Claude Code 2.1.284 runs
    a subagent started without a type as `general-purpose` and honours a
    definition registered under a built-in's name, so no subagent inherits the
    main agent's effort by omission. With `subagentEffort` it runs at that
    effort — "General-purpose agent for research, code search and multi-step
    tasks, on {model} at {effort} effort." Without it, it runs at `medium`, the
    level a session runs at when none is set, and points to the delegates —
    "General-purpose agent for research, code search and multi-step tasks, on
    {model} at medium effort; start a delegate-\<effort\> subagent for another
    effort." Both read "on your model" for `inherit`.
  - The built-in `Explore` and `Plan` are never replaced, because a
    replacement would cost them their read-only tool restrictions and their
    own prompts: they keep their definitions and run at the main agent's
    effort, the one place neither option reaches.
  - `minimal` maps to `low`, as it does for the run's own effort, and is named
    `low` in the definitions and the directive.
- It passes a custom, unsnapshotted system prompt whose last part is the
  delegation directive. Its first sentence follows the two options:

  | `subagentModel` | `subagentEffort` | First sentence                                                                    |
  | --------------- | ---------------- | --------------------------------------------------------------------------------- |
  | `inherit`       | omitted          | Your subagents run on your own model; give each one the effort its task warrants. |
  | a model         | omitted          | Your subagents run on {model}; give each one the effort its task warrants.        |
  | `inherit`       | an effort        | Your subagents run on your own model at {effort} effort.                          |
  | a model         | an effort        | Your subagents run on {model} at {effort} effort.                                 |

  The rest is the same in all four:

  > Offload to them the work you can specify completely and bound tightly —
  > well-defined, fine-grained tasks a subagent can implement well — and keep
  > the deep thinking, reasoning, and design work yourself. Offloading must
  > never lower the quality of what you deliver: brief each subagent fully, and
  > verify its result before you build on it.

Without `subagentModel` the adapter sets neither variable, registers no
definition, and passes no system prompt, so the query is exactly what it would
be without the feature. The options change which model and effort subagents
use, never whether the agent may start them: a run whose `allowedTools` omits
`Agent` still has no subagents. Cligent checks that a model is present, not
that it exists; a model the runtime cannot serve is refused through the
ordinary error path.

The adapter module exports `subagentDirective(selection)`, which returns the
directive for `{ model, effort? }` (a bare model string reads as `{ model }`),
and `composeClaudeSystemPrompt(parts)`, which joins ordered parts with a blank
line into the system prompt the adapter sends. The package exports the
`ClaudeSubagentEffort` type for the accepted efforts.

Use `SUBAGENT_MODEL_SUPPORT` and its helpers to decide where to offer both
options. The metadata is deeply frozen, and `claude` is accepted as an alias for
`claude-code`.

| Adapter       | `requestSupported` |
| ------------- | ------------------ |
| `claude-code` | `true`             |
| `codex`       | `false`            |
| `gemini`      | `false`            |
| `opencode`    | `false`            |
| `kimi`        | `false`            |

```ts
import {
  SUBAGENT_MODEL_SUPPORT,
  assertSubagentModelSupported,
  getSubagentModelSupport,
  isSubagentModelSupported,
} from '@sublang/cligent';

console.log(SUBAGENT_MODEL_SUPPORT['claude-code'].requestSupported); // true
console.log(getSubagentModelSupport('codex')?.notes);
console.log(isSubagentModelSupported('claude')); // true
assertSubagentModelSupported('claude-code');
```

To offer model choices, reuse the adapter's catalog from
[model discovery](../README.md#model-discovery), and offer efforts from
`EFFORT_SUPPORT['claude-code']` less its `orchestrationValues`.

## Skills

`skills` hands a run's runtime [Agent Skills](https://agentskills.io/specification)
directories without committing them to the repository or changing the
runtime's own configuration. On Claude, Gemini, and OpenCode the run's copy is
private to the run. On Codex it is a plugin in the Codex home plugin cache for
the run. On Kimi it is a workspace directory the process shares: concurrent
Kimi runs and other Kimi processes see it until the process's last Kimi run
with skills ends. Each entry names a skill directory, or the `SKILL.md` file it
holds, by path; a relative entry resolves against the run's `cwd`, otherwise
the process working directory. A per-run list replaces the constructor
default, and an empty one runs without skills. Omitting the option adds no
Cligent skill configuration and leaves each runtime's own skill discovery in
force.

```ts
import { Cligent } from '@sublang/cligent';
import { CodexAdapter } from '@sublang/cligent/adapters/codex';

const codex = new Cligent(new CodexAdapter(), {
  cwd: '/path/to/project',
  skills: ['tools/skills/release-notes', 'tools/skills/changelog/SKILL.md'],
});

for await (const event of codex.run('Draft the release notes')) {
  // ...
}

// A per-run list replaces the default; an empty one runs without skills.
for await (const event of codex.run('Answer briefly', { skills: [] })) {
  // ...
}
```

Before any provider work, each built-in adapter checks the whole list and
rejects it, naming the adapter and the entry's index, unless every skill keeps
to the portable subset of the convention:

- The directory holds a regular `SKILL.md` that opens with a `---` YAML
  frontmatter block mapping `name` and `description` to strings.
- `name` matches `^[a-z0-9]+(-[a-z0-9]+)*$`, has at most 64 characters, and
  equals the directory's name as given, before any symbolic link is resolved.
- `description` is non-empty once trimmed and has at most 1024 characters.
- No other `SKILL.md` lies below the directory, following links to
  directories, and no symbolic link inside it is dangling or resolves outside
  it.
- Every entry below the directory is a regular file, a directory, or a
  symbolic link; a FIFO, socket, or device file is rejected.
- No two entries share a `name`.

Cligent rejects a skill rather than rewriting it and does not translate
runtime-specific frontmatter: `allowed-tools` and `hooks`, for example, act
only on Claude.

Each run gets a snapshot. The adapter copies every skill into a carrier its
runtime discovers for that run, keeping file modes and relative links and
turning an absolute link inside the skill into a relative one, and writes each
copy under a temporary name before renaming it into place.

| Adapter       | Carrier                                                                  | The model sees                                                  | Checked before the first turn                                 |
| ------------- | ------------------------------------------------------------------------ | --------------------------------------------------------------- | ------------------------------------------------------------- |
| `claude-code` | a run-private local plugin named `cligent`                               | `cligent:<name>`; the bare name resolves while unique           | initialization lists the plugin and every skill               |
| `codex`       | a run-private plugin named `cligent` in the Codex home plugin cache      | `cligent:<name>`; a `$cligent:<name>` mention injects the skill | no                                                            |
| `gemini`      | user-tier skills in the per-run settings home                            | `<name>`                                                        | no                                                            |
| `kimi`        | a process-shared directory under `.kimi-code/skills` at the project root | `<name>`                                                        | the ACP command list names every skill with its description   |
| `opencode`    | inline configuration skill paths for the managed server                  | `<name>`                                                        | the server's skill list shows every skill at its run location |

A failed check ends the run as a setup failure naming each missing or
shadowed skill. Codex and Gemini give no evidence before the first model turn,
so a skill their runtime drops is silently absent. A same-named skill the
runtime discovers elsewhere can shadow a run skill on Gemini, Kimi, and
OpenCode; on Claude and Codex the names collide with another enabled plugin
named `cligent`.

Claude and Gemini need their skill tool left available:

- On Claude, an empty `allowedTools`, an `allowedTools` without `Skill`, or a
  `disallowedTools` naming `Skill`, or carrying a `Skill(cligent:<name>)` or `Skill(cligent:*)` deny rule while other `Skill(…)` rules are accepted, rejects a skills run. The adapter adds a
  `Skill(cligent:<name>)` allow rule for each run skill, so a headless run
  never waits on the `Skill` ask, and a run skill's `allowed-tools` widens the
  run's permissions while it is active. Managed settings keep their authority:
  `disableSideloadFlags` makes the run fail at start, and under
  `allowManagedPermissionRulesOnly` a skill that sets `allowed-tools`,
  `disallowed-tools`, or `hooks` asks and is denied unless the permission mode
  or an approver admits the ask.
- On Gemini, an `allowedTools` without `activate_skill` or a `disallowedTools`
  naming it rejects a skills run; otherwise the adapter allows
  `activate_skill` in the per-run policy, which Gemini's headless policy would
  deny. Gemini also rejects a skills run whose working directory is your real
  home, whose environment names no home, that would enable the native
  sandbox, whose user settings turn
  `skills.enabled` off, or whose settings the adapter cannot read the
  way Gemini will: on Windows a system settings or system-defaults file, whose
  ownership check the adapter does not run, or in any file a boolean spelled
  as a string, which Gemini coerces only where the whole file validates, where
  the possible readings would change the run's sandbox or policy sources.
- Codex, Kimi, and OpenCode invoke skills under their native defaults.

Kimi Code takes no per-run skill location, so the Kimi adapter writes into the
workspace: one `cligent-<host>-<pid>-<suffix>` directory per process under
`.kimi-code/skills` at the project root, the nearest `.git` ancestor of the
working directory or that directory itself. While it lasts, the directory is
visible to version control and to other Kimi processes in that project, and
every concurrent Kimi run of the process sees every run's skills there,
whatever its own list. It is removed when the process's last Kimi run with
skills under that root ends; one left by an abnormal exit is swept by a later
run of another process on the same host. Kimi rejects a project root that is
the operating-system home, a `.kimi-code/skills` resolving into your user skill
directories, a run skill containing that directory, and a run supplying a
different directory under a name already present.

OpenCode delivers skills only to the server it manages. External mode rejects
a non-empty list, because that server's configuration and skill cache are
fixed outside the run. For the run, the managed server's inline configuration
replaces any `skills.paths` from your configuration files.

A resumed session keeps transcript references to the previous run's carrier
paths, so pass the same `skills` on every call of a session that should keep
them; a Kimi session resumed from another working directory fails its delivery
check.

The adapter removes its carrier when the run ends, or for Kimi when the
process's last Kimi run with skills under that root ends: after the native
process exits, or before the terminal where no process started. A removal failure
before the terminal of an otherwise successful run yields one non-recoverable
`error` with code `SKILL_CARRIER_CLEANUP_FAILED` naming the path, then `done`
with `status: 'error'` that keeps the result, resume token, and usage. A run
that already failed keeps its own error, with the unremoved paths appended to
its message. A failure after the terminal, or after you abort, leaves the path
behind and is reported through the adapter's cleanup reporter where it has
one, such as Kimi's `reportCleanupFailure`, and is otherwise suppressed.

Use `SKILL_SUPPORT` and `getSkillSupport` to see where an adapter carries
skills. The metadata is deeply frozen and gives each adapter's `carrier`
(`'run-private'`, or `'workspace'` for Kimi), the `namespace` the model sees
where the runtime adds one (`'cligent'` on Claude and Codex), and `notes` on
its limits. It describes transport delivery, not whether a model selects a
skill or a runtime policy admits it. `claude` is accepted as an alias for
`claude-code`. A custom adapter receives `skills` unchanged and owns its skill
contract, so `getSkillSupport` returns `undefined` for it.

```ts
import { SKILL_SUPPORT, getSkillSupport } from '@sublang/cligent';

console.log(SKILL_SUPPORT.kimi.carrier); // 'workspace'
console.log(getSkillSupport('claude')?.namespace); // 'cligent'
console.log(getSkillSupport('my-agent')); // undefined
```

### Native skills

Each runtime also discovers skills by itself: from folders in the project and
in your home, and from plugins, extensions, or skills it ships with.
`skills: []` clears only the run's own skills. To keep a call's decisions
independent of the skills installed around it, such as a routing or judging
call, or a call whose inputs must be recorded, set `nativeSkills: false`. The
runtime then offers the run's `skills` and, as far as each adapter can reach,
nothing else. `true` or omitting the option leaves native discovery as the
runtime configures it, and a per-run value replaces the constructor default.

```ts
import { Cligent } from '@sublang/cligent';
import { CodexAdapter } from '@sublang/cligent/adapters/codex';

const judge = new Cligent(new CodexAdapter(), {
  cwd: '/path/to/project',
  nativeSkills: false,
});

for await (const event of judge.run('Pick the better patch')) {
  // ...
}
```

| Adapter       | How native discovery goes off                                                                                                                                                                                                                                    | What stays                                                                                                                                                                                                                         |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `claude-code` | a parent policy blocking `.claude/skills` and `~/.claude/skills`, which also leaves out any plugin placed there with its agents, hooks, MCP servers, and commands, bundled skills and workflows off, and the main thread filtered to the run's `cligent:` skills | subagents still list enabled marketplace plugins' skills and managed policy skills, and the project and user skills where an admin policy tier drops parent policy                                                                 |
| `codex`       | bundled skills off, and every native `SKILL.md` found before the run disabled by its path                                                                                                                                                                        | skills of plugins your user configuration enables, which loads only without a permission policy, and of account-installed plugins                                                                                                  |
| `gemini`      | the per-run home without your user skills or `~/.agents`, and every workspace skill other than a run skill's disabled by name                                                                                                                                    | extension and built-in skills; a workspace skill with a run skill's exact name still shadows it, and one whose name differs only in letter case stays listed beside it                                                             |
| `kimi`        | rejected: `kimi acp` offers no per-run lever                                                                                                                                                                                                                     | —                                                                                                                                                                                                                                  |
| `opencode`    | managed server only: `OPENCODE_DISABLE_EXTERNAL_SKILLS=1`, and inline skill paths and URLs that replace those of your configuration files                                                                                                                        | skill folders in every configuration directory (the global one such as `~/.config/opencode`, `OPENCODE_CONFIG_DIR`, and each `.opencode`), skill paths and URLs from organization or managed configuration, and the built-in skill |

A value other than a boolean is rejected before any provider work. Codex
rejects the switch where a native skill folder cannot be read or the disabled
paths would exceed the process-argument limit. Gemini rejects it where the
child's environment names no home, the working directory resolves to your real
home, the native sandbox would be on, or a settings layer's reading cannot be
established; where its workspace skills cannot be read; where your user
settings hold `skills` or `skills.disabled` in a shape that cannot take more
names; and where a workspace skill's name would change under Gemini's `$VAR`
settings expansion. OpenCode's external mode rejects it. No runtime reports
what the model is offered before the first model turn, so the switch has no
delivery check; a disabled skill's files stay readable through file tools.

A resumed session keeps the native skill listings and skill bodies already in
its history, so for an isolated call pass `resume: false`, or resume only a
session every turn of which used `nativeSkills: false`.

`NATIVE_SKILL_SUPPORT` and `getNativeSkillSupport` give, for each adapter,
the `folders` where a skill installed persistently is discovered — `project`
relative to the working directory and `user` relative to your home under the
runtime's default environment — whether `disableSupported`, and `notes` on
what `nativeSkills: false` leaves, what else it removes, and which runs reject
it. A host that installs skills for a runtime can read the folder from there
instead of hard-coding it.

```ts
import { NATIVE_SKILL_SUPPORT, getNativeSkillSupport } from '@sublang/cligent';

console.log(NATIVE_SKILL_SUPPORT['claude-code'].folders.project); // '.claude/skills'
console.log(getNativeSkillSupport('codex')?.folders.user); // '~/.agents/skills'
console.log(getNativeSkillSupport('kimi')?.disableSupported); // false
```

## Session continuity

When an adapter's `done` event includes a `resumeToken`, `Cligent` stores it
and automatically injects it as the `resume` option on the next `run()` call.

```ts
// First run — adapter returns a resumeToken in the done payload.
for await (const event of agent.run('Refactor the auth module')) {
  // ...
}
console.log(agent.resumeToken); // e.g. 'session-abc-123'

// Second run — Cligent auto-injects resume: 'session-abc-123'.
// The agent picks up where it left off.
for await (const event of agent.run('Now add tests for it')) {
  // ...
}

// Override resume behavior per-call via RunOptions:
agent.run('Start fresh', { resume: false }); // force a new session
agent.run('Use this', { resume: 'other-token' }); // explicit token
```

## Token usage

Every `done` event carries `usage.toolUses`, the number of normalized tool calls
Cligent observed. Authentic token accounting is optional at `usage.tokens`.
Absence means the agent exposed no trustworthy report; a present zero is a
measurement, never a placeholder.

```ts
for await (const event of agent.run('Summarize the README')) {
  if (event.type !== 'done') continue;

  const { usage } = event.payload as DonePayload;
  if (!usage.tokens) {
    console.log('token usage unavailable for this turn');
    continue;
  }

  const { input, output } = usage.tokens.totals;
  console.log(input.total, output.total, usage.tokens.coverage);
}
```

`input.total` includes every cache tier, and `output.total` includes reasoning
or thinking. The details are exact subsets:

| Field              | Meaning                                        |
| ------------------ | ---------------------------------------------- |
| `input.uncached`   | input neither read from nor written to cache   |
| `input.cacheRead`  | input served from the prompt cache             |
| `input.cacheWrite` | input written into the prompt cache            |
| `output.visible`   | generated output excluding reasoning           |
| `output.reasoning` | reasoning or thinking included in output total |

```ts
const report = usage.tokens;
if (report?.totals.input.cacheRead !== undefined) {
  console.log(`${report.totals.input.cacheRead} tokens were cache hits`);
}
```

An absent detail is unreported, not zero. When every detail on one side is
present, those details add up exactly to its total. `coverage: 'complete'`
means all model requests caused by this invocation, including subagents, are
represented. `'partial'` means the numbers are exact but the runtime surface
may omit work. A calculation on a partial report covers only reported work
and cannot establish the full run's cost.

### Which rate card applies

A component split still cannot be priced without knowing _what_ was billed at
_which_ rate. `usage.tokens.records` answers that: each entry is one billable
group of the report.

```ts
for (const record of usage.tokens?.records ?? []) {
  console.log(record.model, record.tokens, record.requests, record.cost);
}
```

| Field         | Meaning                                                                                                                                                                                        |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `model`       | the identifier the agent prices against — **absent when the agent never names it**                                                                                                             |
| `provider`    | the reported rate-card family, including a billing/authentication route where the runtime distinguishes one                                                                                    |
| `tokens`      | this group's inclusive totals and exact subsets                                                                                                                                                |
| `requests`    | how many API requests the group covers; `1` means a context-length tier follows from this record's own token counts, more than `1` means it does not, and absent means the count is unreported |
| `cost`        | upstream amount, USD currency, and provenance; never a Cligent calculation                                                                                                                     |
| `pricedUnits` | separately priced non-token quantities such as reported search requests                                                                                                                        |

Records add up to the report totals and every aggregate detail it publishes.
If that identity cannot hold, records are omitted rather than guessed.

`usage.cost` is independent of tokens. Claude Code and OpenCode can report
client-side cost estimates, which Cligent labels `agent-estimate`; that is not
an invoice. Adapter accounting never fills this field from a Cligent calculation.

### What each agent reports

| Agent         | Coverage                                                                                                                                                      | Records                                            | Direct cost    | Important limitation                                                                                                                                                                                                                                  |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------- | -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `claude-code` | complete                                                                                                                                                      | per model                                          | agent estimate | request count and cache-write TTL are not exposed                                                                                                                                                                                                     |
| `codex`       | partial                                                                                                                                                       | per turn only when the effective model is observed | none           | exec omits descendant threads and often the effective model                                                                                                                                                                                           |
| `gemini`      | complete after telemetry reconciliation; partial after failed-request evidence                                                                                | per response with authentication route             | none           | failed-request tokens, subscription tier, storage duration, grounding, modality, and service-tier dimensions may be absent                                                                                                                            |
| `opencode`    | complete only when the live server matches the tested version and the title and pinned causal boundaries prove the settled task tree; exact partial where an attributable observed subset remains; omitted where no run-owned prompt boundary can be proved | per request                                        | agent estimate | missing or mismatched server proof, reused task sessions, causal/unattributed retries, overflow replay, unproved internal prompts, or unsettled background work prevent complete coverage; the estimate follows OpenCode's price catalog, not billing |
| `kimi`        | unavailable                                                                                                                                                   | none                                               | none           | Kimi 2.1.1 exposes session context occupancy over ACP, not invocation token or cost accounting                                                                                                                                                        |

Token records are enough to calculate ordinary text-token list price only when
the model, request tier, cache details, and service-specific modifiers are all
known. Tool fees, cache storage time, subscriptions, account credits, regions,
modalities, and rate changes can still prevent an exact invoice calculation.

### Codex resume accounting diagnostics

Codex's exec stream reports cumulative root-thread counters. Cligent retains
the previous snapshot on the adapter and subtracts it to report one invocation.
A new adapter resuming an existing thread has no such baseline: its first
valid native usage snapshot omits tokens and establishes a baseline for the next turn.

If execution was requested and a run ends without native terminal usage
(for example, after an interrupt), Cligent discards the old baseline.
Failures before execution was requested preserve it. The next valid resumed
snapshot after a discard omits tokens and establishes a new baseline. This
prevents unobserved work from the interrupted run being charged to a later
invocation. Tool counts remain independently available.

Each native completion or failure emits `codex:usage` before `done`. Its payload
contains `status`, an exact `reason`, `resumed`, the known `threadId`, and available
numerically valid `snapshot`, `baseline`, and `delta` counters. Reasons include missing or
invalid usage, missing baseline, changed counter shape, decreased counters, and
invalid token subsets. These diagnostics preserve absent optional counters and
exclude raw provider payloads. A diagnostic delta can fail subset validation;
only `status: 'reported'` confirms a valid token report. Capture diagnostics alongside `done` when investigating
missing tokens; a successful turn alone does not prove attributable usage.

The [resume accounting investigation](https://github.com/sublang-ai/cligent/pull/51) documents the
reproduction and the limits of the original dogfooding evidence.

### Optional cost estimates

Use `estimateCost` after a run when an approximate text-token cost is useful.
It returns a separate result and leaves runtime-reported `usage.cost` unchanged.
No pricing request happens during adapter execution.

```ts
import { estimateCost, getDefaultPricingCachePath } from '@sublang/cligent';

// Supply authoritative USD rates per million tokens; this bypasses all I/O.
const custom = await estimateCost(usage, {
  prices: { input: 2, output: 10, cacheRead: 0.2, cacheWrite: 2.5 },
});

// Otherwise select the models.dev identities for your billing route.
// This Codex example supplies both because native usage often omits them.
const estimate = await estimateCost(usage, {
  provider: 'openai',
  model: 'gpt-6-luna',
});

if (estimate.status === 'estimated') {
  console.log(estimate.amount, estimate.currency, estimate.coverage);
  console.log(estimate.source, estimate.records, estimate.assumptions);
} else {
  console.log(estimate.reason, estimate.message);
}

console.log(getDefaultPricingCachePath()); // Delete this file to refresh next time.
```

Without caller prices, native model/provider records select exact entries from
[models.dev](https://models.dev). The `model` option fills only missing model
identity; `provider` explicitly selects the catalog provider for every record,
including when a native authentication-family name differs. Both choices are
reported as assumptions. No built-in provider alias or price table is maintained.
Claude Code often omits its provider, and Gemini reports an authentication type
rather than a catalog key. Supply the provider matching your intended prices:
`provider: 'anthropic'` for direct Anthropic rates or `provider: 'google'` for
Google Gemini rates, for example. Choose the corresponding catalog provider
when using a different billing route; these options express pricing assumptions.
One supplied `prices` card applies uniformly across models while preserving known
per-record token details and ignores the catalog-only `model`, `provider`,
`cachePath`, and `timeoutMs` options.

Catalog prices are cached on disk for 24 hours. A missing or expired cache
triggers retrieval; deleting it forces retrieval on the next catalog-based call.
If refresh fails, a valid older snapshot can still be used with `source.stale`
and its original `fetchedAt`. Without usable prices, the result is `unavailable`.
You can override `cachePath` and the retrieval `timeoutMs` (default 5,000).
`getDefaultPricingCachePath()` identifies the platform's Cligent cache file and
can throw if the operating system cannot resolve its location. Catch that error
when calling the accessor directly; `estimateCost` returns `catalog-unavailable`
for the same failure. An explicit `cachePath` avoids default-path lookup.

Estimates preserve complete or partial token coverage and return the exact rates
used for reproducibility. Cache and reasoning subsets replace ordinary rates
without being counted twice. Positive reported cache quantities require their
own rates; missing cache quantities are priced at ordinary input rates with a
disclosed assumption. A distinct reasoning price needs a reported reasoning count.
Context tiers use each record's input only when it represents exactly one request;
aggregated or unknown request counts use standard prices with an assumption.

These are text-token estimates at the selected rates, not actual charges.
Catalog calculations assume standard service mode. Subscriptions, tool fees,
regional rates, fast/priority modes, and other adjustments require caller choices
or are outside this calculation. Missing tokens or unknown model prices remain
unavailable; a partial report remains partial.

## Permissions

> Assumes imports from [Quick start](#quick-start).

Control what the agent is allowed to do with `PermissionPolicy`:

```ts
import { Cligent } from '@sublang/cligent';
import type { PermissionPolicy } from '@sublang/cligent';
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';
import { CodexAdapter } from '@sublang/cligent/adapters/codex';

// PermissionPolicy controls approval posture, broad capabilities, and
// additional workspace-relative writable paths.
//
// mode accepts 'auto' | 'bypass'.
// fileWrite / shellExecute / networkAccess each accept
// 'allow' | 'ask' | 'deny' (default: 'ask' when a policy is provided).
// writablePaths grants extra writable workspace subpaths where the adapter
// has a filesystem sandbox, or is satisfied by ambient workspace access
// otherwise. It is not a command allowlist or network grant.
//
// Adapters translate these to vendor-specific controls:
//   Claude Code  → SDK permissionMode, plus a canUseTool callback
//                  for mixed allow/deny policies
//   Codex        → default_permissions + approval_policy
//                  (+ SDK config.approvals_reviewer for mode: 'auto')
//                  (+ generated profile rules for writablePaths)
//                  (lossy: networkAccess 'allow' grants network only when
//                   the policy selects :danger-full-access)
//   Gemini       → Policy Engine rules via --policy + --approval-mode
//   Kimi         → ACP mode configuration (native default or auto only)
//   OpenCode     → permission map
const permissions: PermissionPolicy = {
  fileWrite: 'ask', // prompt the user before creating or modifying files
  shellExecute: 'deny', // block all shell command execution
  networkAccess: 'allow', // allow HTTP requests without prompting
};

// For a Codex-backed agent that should keep protected auto-mode but still
// run git commands that write metadata, grant the .git subtree explicitly.
const codexGitPermissions: PermissionPolicy = {
  mode: 'auto',
  writablePaths: ['.git'],
};

const codexAgent = new Cligent(new CodexAdapter(), {
  model: 'gpt-6-sol',
  permissions: codexGitPermissions,
});

// Set permissions as defaults, or override per-call.
const agent = new Cligent(new ClaudeCodeAdapter(), {
  model: 'claude-opus-5-5',
  permissions,
});

for await (const event of agent.run('Refactor auth module')) {
  // ...
}

// Per-call permissions are merged by field with constructor defaults, except
// writablePaths arrays replace the default array rather than merging items.
// This keeps mode: 'auto' but replaces ['.git'] with ['dist'] for this run.
for await (const event of codexAgent.run('Build release artifacts', {
  permissions: { writablePaths: ['dist'] },
})) {
  // ...
}
```

OpenCode `mode: 'auto'` preserves configured permission rules and answers only
the asks that survive them. After a successful automated `once` reply, the
event stream includes an `opencode:permission_decision` audit event with the
native request, permission scope, and tool correlation. It remains distinct
from live `approval_request` events. Legacy `permission_request` is historical telemetry from a request the adapter declined; it is not answerable.

OpenCode does not support explicit `allowedTools` or `disallowedTools`,
including empty arrays. In OpenCode 1.18.33 the prompt `tools` field is merged
into persistent session permission rules rather than applied as an independent
per-call tool registry; an enabled tool can therefore override a native or
explicit deny and affect later resumed calls. Cligent rejects either option
before loading the OpenCode SDK. Omit both options or choose an adapter with
exact tool filtering.

OpenCode also rejects an explicit `maxTurns`, including zero, before loading
the SDK. OpenCode 1.18.33 exposes turn ceilings only through persistent agent
configuration, not an exact per-run control, so Cligent neither leaves a
requested limit silently unenforced nor mutates shared agent state. Omit
`maxTurns` or choose an adapter with an exact per-run turn limit.

Kimi has a deliberately narrower headless permission surface:

- Omit `permissions` to preserve the Kimi CLI's native configured rules.
- Use `permissions: { mode: 'auto' }` to select Kimi's native `auto` mode.
  Valid `writablePaths` may accompany `auto`, but the adapter reports them as
  ambient access; it does not enforce them with a filesystem sandbox or turn
  them into additional grants.
- Kimi rejects `mode: 'bypass'` because the CLI's `yolo` mode is not equivalent
  to Cligent's unchecked bypass contract. It also rejects any supplied policy
  without `mode`, including an empty policy or per-capability fields, because
  ACP cannot deterministically replace Kimi's earlier native rule decisions.
- Explicit `allowedTools` or `disallowedTools` values are unsupported and fail
  before spawn, including empty arrays. `maxTurns` and `maxBudgetUsd` likewise
  fail before spawn because Kimi ACP has no matching per-run controls.

Without a per-call handler, a remaining Kimi ACP permission request produces
historical `permission_request` telemetry and is rejected.

### Live host tool approvals

Pass `approvalHandler` to one `run()` call when your application can present a
native tool request and return the user's decision. The callback is not a
constructor default, saved permission policy, or setting carried into the next
resumed turn. Claude, Kimi, and OpenCode's current pending-permission transport
support this route. Codex's exec SDK and Gemini's NDJSON transport do not;
passing a handler still allows their ordinary work to run.

```ts
import type { ApprovalHandler } from '@sublang/cligent';

// requestApproval is your host's UI/broker: show native tool/input/details,
// render only request.choices, and close the prompt when signal aborts.
const approvalHandler: ApprovalHandler = (request, { signal }) =>
  requestApproval(request, { signal });

for await (const event of agent.run('Perform the requested change', {
  approvalHandler,
})) {
  // Persist approval_request and approval_response with other visible events.
  // Only tool results establish whether an allowed action actually executed.
}
```

`ApprovalRequest` has an opaque invocation-specific `id`, native `agent`,
`sessionId`, `toolUseId`, `toolName`, detached `input`, optional native `details`
and `reason`, exact supported `choices`, and epoch-millisecond `createdAt` and
`expiresAt`. Display the actual action scope, including paths, diffs, native
permission patterns, or other details when supplied. Treat native descriptions
as untrusted display content and default the decision UI to denial, without an
automatic Allow selection or a one-key approval shortcut.

The only decisions are `allow_once` and `deny`; a provider that cannot express a
unique one-time grant offers only denial. Native allows, hard denials, automatic
permission modes, and caller-admitted MCP tools keep their existing precedence.
The callback receives only an unresolved native ask. An `ask` policy is not a
promise that every tool invokes your callback, and an allowance cannot override
native policy or isolation.

Every admitted ask emits `approval_request` with the complete request as its
payload. Its single `approval_response` carries `requestId`, `decision`, and
`source` (`host`, `timeout`, `cancelled`, or `error`). The ten-minute deadline,
caller/native cancellation, invocation teardown, malformed answer, and handler
failure all deny unresolved requests. Late answers have no effect. Timeout or
cancellation aborts the handler's context signal so the host can remove stale
controls. A callback rejection is recorded as `error`; exception names do not
confer a different permission outcome.

Capability discovery returns optional `capabilities.approvals`, using
`supported`, `unsupported` with code `unsupported-transport`, or `unknown`.
Absent facts from a custom adapter are unknown. These facts describe transport
support, not native authorization, account readiness, or automatic human consent.
The callback is independent of tool and application names, so a native consent
tool can use the same route as any other unresolved tool permission.
Structured questions such as Claude `AskUserQuestion`, MCP form or URL
elicitation, and persistent “always allow” grants are outside this boolean
tool-decision API. A later prompt cannot answer a native callback already
waiting inside the current call; those interactions need their own typed
response transport. Operating-system and controlling-application grants must
be completed in the system that owns them.

OpenCode refuses unsupported questions only after proving ownership: a root
question must link to the exact prompt identifier dispatched by that call;
explicitly owned descendants can also be declined on its managed server.
Shared external-server descendants lack an authoritative per-prompt link and
remain untouched, as do root questions after an internally inserted prompt
without a proven link to the dispatched prompt. Unproved and unrelated asks
receive no answer. These runs retain normal inactivity recovery and caller
cancellation. The inactivity limit is not an absolute question deadline: real
session activity can extend it; global server heartbeats cannot. No question
is converted into an allow-once decision or answered with invented text.

## Parallel execution

Run multiple `Cligent` instances side-by-side with `Cligent.parallel`:

```ts
import { Cligent } from '@sublang/cligent';
import { ClaudeCodeAdapter } from '@sublang/cligent/adapters/claude-code';
import { CodexAdapter } from '@sublang/cligent/adapters/codex';

const coder = new Cligent(new ClaudeCodeAdapter(), {
  role: 'coder',
  model: 'claude-opus-5-5',
});
const reviewer = new Cligent(new CodexAdapter(), {
  role: 'reviewer',
  model: 'gpt-6-sol',
});

// Cligent.parallel(tasks) → AsyncGenerator<CligentEvent>
// Each task's run() is fully hardened (error isolation, abort, exactly-one-done).
// Events are interleaved as they arrive. Use event.agent to identify the
// backend and event.role to identify the task.
for await (const event of Cligent.parallel([
  { agent: coder, prompt: 'Write unit tests' },
  { agent: reviewer, prompt: 'Review the auth module' },
])) {
  console.log(`[${event.role}/${event.agent}] ${event.type}`);
}
```

Each task can have its own `abortSignal` via `overrides`. A shared signal
aborts all tasks; per-task signals abort only that task.

### Low-level parallel (runParallel)

For adapter-level parallel execution without `Cligent` wrapping, use `runParallel`:

```ts
import { runParallel } from '@sublang/cligent';

for await (const event of runParallel([
  {
    adapter: new ClaudeCodeAdapter(),
    prompt: 'Write unit tests',
    options: { model: 'claude-opus-5-5', effort: 'ultracode' },
  },
  {
    adapter: new CodexAdapter(),
    prompt: 'Write integration tests',
    options: { model: 'gpt-6-sol', effort: 'ultra' },
  },
])) {
  console.log(`[${event.agent}] ${event.type}`);
}
```

## Abort

> Assumes imports from [Quick start](#quick-start).

Cancel a running agent with a standard `AbortController`:

```ts
// Pass an AbortSignal via RunOptions for cooperative cancellation.
const ac = new AbortController();
setTimeout(() => ac.abort(), 30_000); // cancel after 30 s

for await (const event of agent.run('Fix the login bug', {
  abortSignal: ac.signal,
})) {
  // On abort the generator emits a final 'done' event with
  // status 'interrupted', then ends.
}
```

## Event types

`Cligent.run()` yields `CligentEvent` values, which extend `AgentEvent` with an optional `role` field. Every event carries a typed `payload`:

- `type` — discriminant tag (see table below, or a namespaced string like `'codex:file_change'`)
- `agent` — which adapter emitted the event (`'claude-code'`, `'codex'`, `'gemini'`, `'kimi'`, `'opencode'`, …)
- `role` — task-level identity from `CligentOptions.role` (undefined when not set)
- `timestamp` — Unix epoch milliseconds
- `sessionId` — groups all events within one `run()` call

| Type                           | Payload                                                                              | Description                                                              |
| ------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------ |
| `init`                         | `model`, `reportedModel?`, `cwd`, `tools`, `fastMode?`                               | Session started; `reportedModel` and fast-mode state only when reported  |
| `text`                         | `content`                                                                            | Complete text response                                                   |
| `text_delta`                   | `delta`                                                                              | Streaming text chunk                                                     |
| `thinking`                     | `summary`                                                                            | Agent reasoning                                                          |
| `tool_use`                     | `toolName`, `toolUseId`, `input`                                                     | Tool invocation                                                          |
| `tool_result`                  | `toolUseId`, `status`, `output`                                                      | Tool outcome                                                             |
| `permission_request`           | `toolName`, `toolUseId`, `input`                                                     | Historical fail-closed permission telemetry                                                |
| `approval_request` | complete `ApprovalRequest` | Live native tool ask being handled by this call's host callback |
| `approval_response` | `requestId`, `decision`, `source` | Host decision or fail-closed lifecycle outcome; not proof of execution |
| `opencode:permission_decision` | `requestId`, `permission`, `patterns`, `toolUseId`, `decision`, `automated`, `input` | Successful OpenCode auto approval audit                                  |
| `codex:usage`                  | `status`, `reason`, `resumed`, `threadId?`, `snapshot?`, `baseline?`, `delta?` | Native terminal token-accounting decision |
| `error`                        | `code`, `message`, `recoverable`                                                     | Error                                                                    |
| `done`                         | `status`, `resumeToken?`, `usage`, `durationMs`, `fastMode?`                         | Terminal event — always last; Claude may report state and response speed |
